package org.ascension.addg.gcp.transformation;

public class ewter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String h = "llLdfdf";
		String l = "l";
		
		if(h.toLowerCase().contains(l)) {
			System.out.println("sdgs");
		}
	}

}
