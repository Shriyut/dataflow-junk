package org.ascension.addg.gcp.mdstaff;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class relation {

public static void main(String[] args) {
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		String q = "{\r\n"
				+ "\"query\": \"\"\"WITH\r\n"
				+ "  temp_nest AS (\r\n"
				+ "  SELECT\r\n"
				+ "    (\r\n"
				+ "    SELECT\r\n"
				+ "      crosswalks.value\r\n"
				+ "    FROM\r\n"
				+ "      UNNEST(crosswalks) crosswalks ) AS addr_nest_key,\r\n"
				+ "    address_types.*\r\n"
				+ "  FROM\r\n"
				+ "    `asc-ahnat-apdh-sbx.apdh_test_dataset.relation_sort_final`,\r\n"
				+ "    UNNEST(address_types) address_types\r\n"
				+ "  WHERE\r\n"
				+ "    type = 'configuration/relationTypes/HasAddress'\r\n"
				+ "    AND parent_type = 'HCO'),\r\n"
				+ "  temp_nest_phn AS (\r\n"
				+ "  SELECT\r\n"
				+ "    (\r\n"
				+ "    SELECT\r\n"
				+ "      crosswalks.value\r\n"
				+ "    FROM\r\n"
				+ "      UNNEST(crosswalks) crosswalks ) AS phn_nest_key,\r\n"
				+ "    phone.*\r\n"
				+ "  FROM\r\n"
				+ "    `asc-ahnat-apdh-sbx.apdh_test_dataset.relation_sort_final`,\r\n"
				+ "    UNNEST(phone) phone\r\n"
				+ "  WHERE\r\n"
				+ "    type = 'configuration/relationTypes/HasAddress'\r\n"
				+ "    AND parent_type = 'HCO' ),\r\n"
				+ "  bridge_nest AS (\r\n"
				+ "  SELECT\r\n"
				+ "    addr_nest_key as nest_key,\r\n"
				+ "    ARRAY_AGG (STRUCT(STRUCT ([STRUCT( address_type AS value)] AS AddressType,\r\n"
				+ "          [STRUCT( Publish_To_External_Directory_Flag AS value)] AS PublishToExternalDirectoryFlag,\r\n"
				+ "          [STRUCT( Publish_To_External_Directory_Primary_Flag AS value)] AS PublishToExternalDirectoryPrimaryFlag,\r\n"
				+ "          [STRUCT( Practice_Rank AS value)] AS PracticeRank,\r\n"
				+ "          [STRUCT( status AS value)] AS Status,\r\n"
				+ "          [STRUCT( begin_date AS value)] AS BeginDate,\r\n"
				+ "          [STRUCT( end_date AS value)] AS EndDate) AS value )) AS AddressTypes,\r\n"
				+ "    ARRAY_AGG (STRUCT(STRUCT ([STRUCT( phone_type AS value)] AS PhoneType,\r\n"
				+ "          [STRUCT( phone_Number AS value)] AS Number,\r\n"
				+ "          [STRUCT( phone_Extension AS value)] AS Extension,\r\n"
				+ "          [STRUCT( phone_Rank AS value)] AS Rank) AS value )) AS Phone\r\n"
				+ "  FROM\r\n"
				+ "    temp_nest left outer join temp_nest_phn on addr_nest_key=phn_nest_key\r\n"
				+ "  GROUP BY\r\n"
				+ "    nest_key ),\r\n"
				+ "  temp_column AS (\r\n"
				+ "  SELECT\r\n"
				+ "    record_indicator,\r\n"
				+ "    'MD Staff' AS SourceSystemName,\r\n"
				+ "    meta_src_system_name,\r\n"
				+ "    type,\r\n"
				+ "    STRUCT([STRUCT ( (\r\n"
				+ "        SELECT\r\n"
				+ "          crosswalks.type\r\n"
				+ "        FROM\r\n"
				+ "          UNNEST(crosswalks) crosswalks ) AS type,\r\n"
				+ "        parent_id AS value )] AS crosswalks) AS startObject,\r\n"
				+ "    STRUCT([STRUCT ( (\r\n"
				+ "        SELECT\r\n"
				+ "          crosswalks.type\r\n"
				+ "        FROM\r\n"
				+ "          UNNEST(crosswalks) crosswalks ) AS type,\r\n"
				+ "        child_id AS value )] AS crosswalks) AS endObject,\r\n"
				+ "    [STRUCT ( (\r\n"
				+ "      SELECT\r\n"
				+ "        crosswalks.type\r\n"
				+ "      FROM\r\n"
				+ "        UNNEST(crosswalks) crosswalks ) AS type,\r\n"
				+ "      (\r\n"
				+ "      SELECT\r\n"
				+ "        crosswalks.value\r\n"
				+ "      FROM\r\n"
				+ "        UNNEST(crosswalks) crosswalks ) AS value )] AS crosswalks,\r\n"
				+ "    [STRUCT ( status AS value)] AS Status,\r\n"
				+ "    [STRUCT ( medical_staff_status AS value)] AS MedicalStaffCategory,\r\n"
				+ "    [STRUCT ( on_staff_flag AS value)] AS OnStaffFlag,\r\n"
				+ "    [STRUCT ( Archived_Flag AS value)] AS ArchivedFlag,\r\n"
				+ "    [STRUCT ( Exclude_Directory_Flag AS value)] AS ExcludeDirectoryFlag,\r\n"
				+ "    [STRUCT ( Organizational_Relationship AS value)] AS OrganizationalRelationship,\r\n"
				+ "    [STRUCT ( Employee_Class AS value)] AS EmployeeClass,\r\n"
				+ "    [STRUCT ( Employee_Class AS value)] AS EmployeeClassDescription,\r\n"
				+ "    [STRUCT ( Employment_Status AS value)] AS EmploymentStatus,\r\n"
				+ "    [STRUCT ( Job_Code AS value)] AS JobCode,\r\n"
				+ "    [STRUCT ( Job_Description AS value)] AS JobDescription,\r\n"
				+ "    [STRUCT ( Job_Entry_Date AS value)] AS JobEntryDate,\r\n"
				+ "    [STRUCT ( Job_Description AS value)] AS JobIndicator,\r\n"
				+ "    [STRUCT ( Position_Number AS value)] AS PositionNumber,\r\n"
				+ "    [STRUCT ( Position_Description AS value)] AS PositionDescription,\r\n"
				+ "    [STRUCT ( Position_Entry_Date AS value)] AS PositionEntryDate,\r\n"
				+ "    [STRUCT ( Business_Unit AS value)] AS BusinessUnit,\r\n"
				+ "    [STRUCT ( Business_Unit_Description AS value)] AS BusinessUnitDescription,\r\n"
				+ "    [STRUCT ( Department_Identifier AS value)] AS DepartmentIdentifier,\r\n"
				+ "    [STRUCT ( Department_Description AS value)] AS DepartmentDescription,\r\n"
				+ "    [STRUCT ( Department_Entry_Date AS value)] AS DepartmentEntryDate,\r\n"
				+ "    [STRUCT ( Hire_Date AS value)] AS HireDate,\r\n"
				+ "    [STRUCT ( Last_Hire_Date AS value)] AS LastHireDate,\r\n"
				+ "    [STRUCT ( Termination_Date AS value)] AS TerminationDate,\r\n"
				+ "    [STRUCT ( Contract_Identifier AS value)] AS ContractIdentifier,\r\n"
				+ "    [STRUCT ( Contract_Group AS value)] AS ContractGroup,\r\n"
				+ "    [STRUCT ( Contract_Type AS value)] AS ContractType,\r\n"
				+ "    [STRUCT ( Contract_Status AS value)] AS ContractStatus,\r\n"
				+ "    [STRUCT ( Network_Order AS value)] AS NetworkOrder,\r\n"
				+ "    [STRUCT ( Network_Name AS value)] AS NetworkName,\r\n"
				+ "    [STRUCT ( \"Not Avaliable\" AS value)] AS LocationOfCare,\r\n"
				+ "    [STRUCT ( SystemIdentifier_Type AS value)] AS SystemIdentifierType,\r\n"
				+ "    [STRUCT ( SystemIdentifier_Value AS value)] AS SystemIdentifierValue,\r\n"
				+ "    [STRUCT ( \"Not Avaliable\" AS value)] AS SpecialtyRank,\r\n"
				+ "    [STRUCT ( \"Not Avaliable\" AS value)] AS ClinicalExpertiseRank,\r\n"
				+ "    (\r\n"
				+ "    SELECT\r\n"
				+ "      crosswalks.value\r\n"
				+ "    FROM\r\n"
				+ "      UNNEST(crosswalks) crosswalks ) AS root_key\r\n"
				+ "  FROM\r\n"
				+ "    `asc-ahnat-apdh-sbx.apdh_test_dataset.relation_sort_final`\r\n"
				+ "  WHERE\r\n"
				+ "    type = 'configuration/relationTypes/HasAddress'\r\n"
				+ "    AND parent_type = 'HCO')\r\n"
				+ "SELECT\r\n"
				+ "  record_indicator,\r\n"
				+ "  'MD Staff' AS SourceSystemName,\r\n"
				+ "  meta_src_system_name,\r\n"
				+ "  type,\r\n"
				+ "  startObject,\r\n"
				+ "  endObject,\r\n"
				+ "  crosswalks,\r\n"
				+ "  STRUCT(Status,\r\n"
				+ "    MedicalStaffCategory,\r\n"
				+ "    OnStaffFlag,\r\n"
				+ "    ArchivedFlag,\r\n"
				+ "    ExcludeDirectoryFlag,\r\n"
				+ "    OrganizationalRelationship,\r\n"
				+ "    EmployeeClass,\r\n"
				+ "    EmployeeClassDescription,\r\n"
				+ "    EmploymentStatus,\r\n"
				+ "    JobCode,\r\n"
				+ "    JobDescription,\r\n"
				+ "    JobEntryDate,\r\n"
				+ "    JobIndicator,\r\n"
				+ "    PositionNumber,\r\n"
				+ "    PositionDescription,\r\n"
				+ "    PositionEntryDate,\r\n"
				+ "    BusinessUnit,\r\n"
				+ "    BusinessUnitDescription,\r\n"
				+ "    DepartmentIdentifier,\r\n"
				+ "    DepartmentDescription,\r\n"
				+ "    DepartmentEntryDate,\r\n"
				+ "    HireDate,\r\n"
				+ "    LastHireDate,\r\n"
				+ "    TerminationDate,\r\n"
				+ "    ContractIdentifier,\r\n"
				+ "    ContractGroup,\r\n"
				+ "    ContractType,\r\n"
				+ "    ContractStatus,\r\n"
				+ "    NetworkOrder,\r\n"
				+ "    NetworkName,\r\n"
				+ "    AddressTypes,\r\n"
				+ "    Phone,\r\n"
				+ "    LocationOfCare,\r\n"
				+ "    SystemIdentifierType,\r\n"
				+ "    SystemIdentifierValue,\r\n"
				+ "    SpecialtyRank,\r\n"
				+ "    ClinicalExpertiseRank ) AS attributes\r\n"
				+ "FROM\r\n"
				+ "  bridge_nest\r\n"
				+ "JOIN\r\n"
				+ "  temp_column\r\n"
				+ "ON\r\n"
				+ "  nest_key=root_key\"\"\"\r\n"
				+ "\r\n"
				+ "}";
		
		Config conf = ConfigFactory.parseString(q).resolve();
		PCollection<TableRow> in = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery(conf.getString("query")).usingStandardSql());
		PCollection<PubsubMessage> msg = in.apply(ParDo.of(new newConvertFn()));
		msg.apply(PubsubIO.writeMessages().to("projects/asc-ahnat-apdh-sbx/topics/APDH_CANONICAL")); 
		pipeline.run().waitUntilFinish();
	}

	public static class newConvertFn extends DoFn<TableRow, PubsubMessage>{
		
		
		@ProcessElement
		public void ProcessElement(ProcessContext ctx) {
			TableRow obj = ctx.element().clone();
			JSONObject finalObj = new  JSONObject();
			JSONArray finalarr = new JSONArray();
			
			obj.keySet().forEach((k)->{
				System.out.println("keyfirst "+k+" classname "+obj.get(k).getClass());
				if(k.equals("attributes")) {
					TableRow attributes = (TableRow) obj.get(k);
					JSONObject attrObj = new JSONObject();
					attributes.keySet().forEach((key)->{
						Object o = attributes.get(key);
						// intially everything is present inside arraylist
						//if(key.equals("ManagedIdentifier"))
						
						if(o instanceof ArrayList) {
							ArrayList valueList = (ArrayList) o;
							if(valueList.get(0) instanceof String) {
								System.out.println("string "+ key + String.valueOf(valueList.get(0)));
							}else if(valueList.get(0) instanceof TableRow) {
								System.out.println("attributes "+key+" "+String.valueOf(o)+" classval "+o.getClass());
								TableRow valueTr = (TableRow) valueList.get(0);
								//if(key.equals("ManagedIdentifier")) {
								//	System.out.println("managed "+o.getClass()+ String.valueOf(o));
								//}
								//TableRow value = (TableRow) valueTr.get("value");
								//value for some is tablerow and for some string
								if(valueList.size()==1) {
									
									//for relationships empty values are not found because value key is not present in tablerow
									Object data = valueTr.get("value");
									if(data instanceof String) {
										System.out.println("attribute1 "+key+" "+String.valueOf(o)+" classval "+o.getClass());
										System.out.println("attributedata "+key+" "+String.valueOf(data)+" classval "+data.getClass());
										if(String.valueOf(data).equals("Not Available") || String.valueOf(data).equals("Not Avaliable")) {
											
										}else {
											if(String.valueOf(createValFromString((String)data)).equals("[{\"value\":\"\"}]")) {
												System.out.println("nullvalfound "+key);
											}else {
												attrObj.put(key, createValFromString((String)data));
											}
										}
									}else if(data instanceof TableRow) {
										if(key.equals("AddressTypes") || key.equals("Phone")) {
											System.out.println(key+" foundintablerow "+" "+o.getClass()+" "+ String.valueOf(o));
											System.out.println(key+" foundintablerow "+" "+data.getClass()+" "+ String.valueOf(data));
											
											TableRow value = (TableRow) data;
											JSONObject tmpobj = new JSONObject();
											JSONArray tmparr = new JSONArray();
											JSONObject newtmpobj = new JSONObject();
											value.keySet().forEach((ki)->{
												JSONObject newobj = new JSONObject();
												JSONArray newarr = new JSONArray();
												System.out.println("insidekeyset "+String.valueOf(value.get(ki))+" key "+ki);
												String nestedData = String.valueOf(value.get(ki));
												if(!(nestedData.equals("[GenericData{classInfo=[f], {}}]") || nestedData.equals("[GenericData{classInfo=[f], {value=null}}]")
														|| nestedData.equals("[GenericData{classInfo=[f], {value=}}]"))
														) {
													ArrayList val = (ArrayList) value.get(ki);
													TableRow t = (TableRow) val.get(0);
													String data1 = String.valueOf(t.get("value"));
													newobj.put("value", data1);
													System.out.println("classname "+value.get(ki).getClass());
													newarr.put(newobj);
												}
												if(!(String.valueOf(newarr)).equals("[]")) {
													tmpobj.put(ki, newarr);
												}
											});
											newtmpobj.put("value", tmpobj);
											tmparr.put(newtmpobj);
											if(!(String.valueOf(tmparr)).equals("[{\"value\":{}}]")) {
												attrObj.put(key, tmparr);
											}
											
											System.out.println("trattr "+tmparr);
										}else {
											System.out.println("normaltablerow "+key);
											TableRow add = (TableRow) data;
											
											
											TableRow value = (TableRow) valueTr.get("value");
											System.out.println("tablerowvalue "+key+" "+String.valueOf(value));
											JSONObject tmpobj = new JSONObject();
											tmpobj.put("value", createJSONArray(value));
											JSONArray tmparr = new JSONArray();
											tmparr.put(tmpobj);
											attrObj.put(key, tmparr);
										}
									}else if(data instanceof ArrayList) {
										
										System.out.println("attributekey "+key+" "+String.valueOf(o)+" classval "+o.getClass());
									}
									else {
										
											System.out.println("newdata "+key+" class "+o.getClass());
										
									}
								}else {
									System.out.println("attribute2 "+key+" "+String.valueOf(o)+" classval "+o.getClass());
									//each key has size 7 
									//query returns null values where the count of elements is less than 7
									
									JSONObject sysobj = new JSONObject(); //parent
									JSONArray sysarr = new JSONArray();
									Object val = attributes.get(key);
									ArrayList ins = (ArrayList) val;
									TableRow value = (TableRow) ins.get(0);
									TableRow data = (TableRow) value.get("value");
									System.out.println("large "+key+" size "+ins.size());
									System.out.println("nested "+key+" "+String.valueOf(ins));
									//System.out.println();
									//if(key.equals("LanguageSpoken")) {
										JSONArray tmparr = new JSONArray();
										JSONObject okj = new JSONObject();
										for(int i=0;i<ins.size();i++) {
											TableRow tru = (TableRow) ins.get(i);
											TableRow insideVal = (TableRow) tru.get("value");
											System.out.println("langs "+String.valueOf(insideVal));
											JSONObject childsysobj = new JSONObject();
											
											insideVal.keySet().forEach((io)->{
												ArrayList dataKey = (ArrayList) insideVal.get(io);
												TableRow dataValue = (TableRow) dataKey.get(0);
												String content = String.valueOf(dataValue.get("value"));
												System.out.println("content "+io+" "+content);
												
												if(content.equals("null") || content.equals("")) {
													
												}else {
													childsysobj.put(io, createValFromString(content));
												}

											});
											sysobj.accumulate("value", childsysobj);
											System.out.println("sysobj "+sysobj);
										}
										if(sysobj.get("value") instanceof JSONArray) {
											JSONArray newarr = sysobj.getJSONArray("value");
											System.out.println("sysobj"+sysobj.get("value").getClass());
											
											for(int l1=0;l1<newarr.length();l1++) {
												JSONObject temp = new JSONObject();
												System.out.println("newaarr "+newarr.getJSONObject(l1));
												temp.put("value", newarr.getJSONObject(l1));
												sysarr.put(temp);
												
											}
											}else {
												
												JSONObject temp = new JSONObject();
												temp.put("value", sysobj.getJSONObject("value"));
												sysarr.put(temp);
											}
										JSONArray nestedarr = new JSONArray();
										for(int h=0;h<sysarr.length();h++) {
											if(!String.valueOf(sysarr.get(h)).equals("{\"value\":{}}")) {
												nestedarr.put(sysarr.get(h));
											}
										}
										attrObj.put(key, nestedarr);
									//}
									System.out.println("sysarr "+sysarr);
									
								}
							}else {
								System.out.println("newval "+key+" "+o.getClass());
							}
							
							
						}
					});
					if(!(String.valueOf(attrObj).equals("{}"))){
						finalObj.put(k, attrObj);
					}
					
					System.out.println("attrObj "+String.valueOf(attrObj));
				}else if(k.equals("crosswalks")) {
					System.out.println("crosswalks "+obj.get(k).getClass()+" "+String.valueOf(obj.get(k)));
					JSONArray tmparr = new JSONArray();
					JSONObject obj1 = new JSONObject();
					if(obj.get(k) instanceof TableRow) {
						TableRow tryq = (TableRow) obj.get(k);
						tryq.keySet().forEach((q)->{
							if("crosswalks_type".equals(q)) {
								obj1.put("type", String.valueOf(tryq.get(q)));
							}else if("crosswalks_value".equals(q)) {
								obj1.put("value", String.valueOf(tryq.get(q)));
							}else {
								obj1.put(q, String.valueOf(tryq.get(q)));
							}
							
							
						});
						tmparr.put(obj1);
						finalObj.put(k, tmparr);
					}else if(obj.get(k) instanceof ArrayList) {
						System.out.println("crosswalkin arraylist");
						ArrayList al = (ArrayList) obj.get(k);
						TableRow crosswalk = (TableRow) al.get(0);
						JSONObject tmpobj = new JSONObject();
						JSONArray tmparr1 = new JSONArray();
						crosswalk.keySet().forEach((ki)->{
							if("crosswalks_type".equals(ki)) {
								tmpobj.put("type", String.valueOf(crosswalk.get(ki)));
							}else if("crosswalks_value".equals(ki)) {
								tmpobj.put("value", String.valueOf(crosswalk.get(ki)));
							}else {
								tmpobj.put(ki, String.valueOf(crosswalk.get(ki)));
							}
						});
						tmparr1.put(tmpobj);
						finalObj.put(k, tmparr1);
					}
					else {
						System.out.println("crosswalktype "+obj.get(k).getClass());
					}
				}else if(k.equals("startObject") || k.equals("endObject")) {
					TableRow object = (TableRow) obj.get(k);
					ArrayList list = (ArrayList) object.get("crosswalks");
					TableRow crosswalkValue = (TableRow) list.get(0);
					JSONObject tempObj = new JSONObject();
					tempObj.put("crosswalks", createJSONArrayforCrosswalk(crosswalkValue));
					
					finalObj.put(k, tempObj);
					//TableRow crosswalk = (TableRow) object.get("crosswalks");
					//System.out.println("startobject "+String.valueOf(object));
				}else {
					finalObj.put(k, String.valueOf(obj.get(k)));
				}
				//finalObj.getString("a");
			});
			finalarr.put(finalObj);
			HashMap<String, String> mapData = new HashMap<String, String>();
			byte[] data = String.valueOf(finalarr).getBytes();
			PubsubMessage msg = new PubsubMessage(data, mapData);
			ctx.output(msg);
			
			System.out.println("finalobj "+finalObj);
		}
		
		public static JSONArray createValFromString(String input) {
			JSONArray tmpArray = new JSONArray();
			JSONObject obj = new JSONObject();
			
			obj.put("value", input);
			tmpArray.put(obj);
			return tmpArray;
		}
	}
	
		public static JSONArray createJSONArray(TableRow tr) {
			JSONObject temp = new JSONObject();
			
			tr.keySet().forEach((key)->{
				if(tr.get(key) instanceof String) {
					temp.put(key, String.valueOf(tr.get(key)));
				}else if(tr.get(key) instanceof ArrayList) {
					ArrayList j = (ArrayList) tr.get(key);
					TableRow tr1 = new TableRow();
					if(String.valueOf(tr1.get("value")).equals("null")) {
						temp.put(key, "");
					}else {
						temp.put(key, String.valueOf(tr1.get("value")));
					}
					
				}
			});
			
			JSONArray returnArray = new JSONArray();
			returnArray.put(temp);
			
			return returnArray;
		}
		
		public static JSONArray createJSONArrayforCrosswalk(TableRow input) {
			JSONArray finalArray = new JSONArray();
			JSONObject valueObject = new JSONObject();
			
			input.keySet().forEach((k)->{
				if("crosswalks_type".equals(k)) {
					valueObject.put("type", String.valueOf(input.get(k)));
				}else if("crosswalk_value".equals(k)) {
					valueObject.put("value", String.valueOf(input.get(k)));
				}else {
					valueObject.put(k, String.valueOf(input.get(k)));
				}
			});
			
			finalArray.put(valueObject);
			return finalArray;
		}


}
