package org.ascension.addg.gcp.mdstaff;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class hcp {

public static void main(String[] args) {
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		String q = "{\r\n"
				+ "\"query\": \"\"\"WITH\r\n"
				+ "temp_unnest1 AS (\r\n"
				+ "SELECT\r\n"
				+ "CASE\r\n"
				+ "WHEN crosswalks.value='null' THEN NULL\r\n"
				+ "ELSE\r\n"
				+ "crosswalks.value\r\n"
				+ "END\r\n"
				+ "AS value,\r\n"
				+ "managedidentifier.*,\r\n"
				+ "LANGUAGE.*,\r\n"
				+ "credential.*,\r\n"
				+ "phone.*,\r\n"
				+ "BoardCertification.*\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.clinical_practitioner_hcp_sort`,\r\n"
				+ "UNNEST(managedidentifier) managedidentifier\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos1\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(language_spoken)\r\n"
				+ "LANGUAGE\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos2\r\n"
				+ "ON\r\n"
				+ "pos1=pos2\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(credential) credential\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos3\r\n"
				+ "ON\r\n"
				+ "pos1=pos3\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(email) email\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos4\r\n"
				+ "ON\r\n"
				+ "pos1=pos4\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(phone) phone\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos5\r\n"
				+ "ON\r\n"
				+ "pos1=pos5\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(Board_Certification) BoardCertification\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos6\r\n"
				+ "ON\r\n"
				+ "pos1=pos6),\r\n"
				+ "temp_unnest2 AS (\r\n"
				+ "SELECT\r\n"
				+ "CASE\r\n"
				+ "WHEN crosswalks.value='null' THEN NULL\r\n"
				+ "ELSE\r\n"
				+ "crosswalks.value\r\n"
				+ "END\r\n"
				+ "AS value,\r\n"
				+ "managedidentifier.*,\r\n"
				+ "alias.*,\r\n"
				+ "education.*,\r\n"
				+ "email.*\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.clinical_practitioner_hcp_sort`,\r\n"
				+ "UNNEST(managedidentifier) managedidentifier\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos1\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(education) Education\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos2\r\n"
				+ "ON\r\n"
				+ "pos1=pos2\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(alias) alias\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos3\r\n"
				+ "ON\r\n"
				+ "pos1=pos3\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(email) email\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos4\r\n"
				+ "ON\r\n"
				+ "pos1=pos4\r\n"
				+ "),\r\n"
				+ "bridge_unnest1 AS (\r\n"
				+ "SELECT\r\n"
				+ "value AS key_1,\r\n"
				+ "ARRAY_AGG(STRUCT(STRUCT([STRUCT(managedidentifier_type AS value) ] AS ManagedIdentifierType,\r\n"
				+ "[STRUCT (managedidentifier_value AS value) ]AS ManagedIdentifierValue,\r\n"
				+ "[STRUCT (state_profession_type_code AS value)] AS StateProfessionTypeCode,\r\n"
				+ "[STRUCT (issuing_authority AS value) ]AS IssuingAuthority,\r\n"
				+ "[STRUCT (identifier_status AS value)] AS IdentifierStatus,\r\n"
				+ "[STRUCT (Initial_Issue_Date AS value)] AS InitialIssueDate,\r\n"
				+ "[STRUCT (effective_date AS value)] AS EffectiveDate,\r\n"
				+ "[STRUCT (renewal_date AS value)] AS RenewalDate,\r\n"
				+ "[STRUCT (expiration_date AS value)] AS ExpirationDate,\r\n"
				+ "[STRUCT (state AS value)] AS State,\r\n"
				+ "[STRUCT (credential_in_use_flag AS value)] AS CredentialInUseFlag) AS value)) AS ManagedIdentifier,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( language_spoken_code AS value)] AS LanguageSpokenCode,\r\n"
				+ "[STRUCT( language_spoken_rank AS value)] AS LanguageSpokenRank) AS value )) AS LanguageSpoken,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( credential_code AS value)] AS CredentialCode,\r\n"
				+ "[STRUCT( credential_rank AS value)] AS CredentialRank) AS value )) AS Credential,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( type AS value)] AS PhoneType,\r\n"
				+ "[STRUCT( number AS value)] AS Number,\r\n"
				+ "[STRUCT( Extension AS value)] AS Extension,\r\n"
				+ "[STRUCT( rank AS value)] AS Rank) AS value )) AS Phone,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( Board_Certification_Code AS value)] AS BoardCertificationCode,\r\n"
				+ "[STRUCT( Board_Certification_Specialty_Code AS value)] AS BoardCertificationSpecialtyCode,\r\n"
				+ "[STRUCT( Board_Certification_Status_Code AS value)] AS BoardCertificationStatusCode,\r\n"
				+ "[STRUCT( Board_Certification_Number AS value)] AS BoardCertificationNumber,\r\n"
				+ "[STRUCT( Board_Certification_Lifetime_Status AS value)] AS BoardCertificationLifetimeStatus,\r\n"
				+ "[STRUCT( Board_Certification_In_Use_Flag AS value)] AS BoardCertificationInUseFlag,\r\n"
				+ "[STRUCT( Board_Certification_Initial_Date AS value)] AS BoardCertificationInitialDate,\r\n"
				+ "[STRUCT( Board_Certification_Expiration_Date AS value)] AS BoardCertificationExpirationDate,\r\n"
				+ "[STRUCT( Board_Certification_Exam_Date AS value)] AS BoardCertificationExamDate) AS value )) AS BoardCertification\r\n"
				+ "FROM\r\n"
				+ "temp_unnest1\r\n"
				+ "GROUP BY\r\n"
				+ "value ),\r\n"
				+ "bridge_unnest2 AS (\r\n"
				+ "SELECT\r\n"
				+ "value AS key_2,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( type AS value)] AS EmailType,\r\n"
				+ "[STRUCT( email AS value)] AS Email) AS value )) AS Email,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( type AS value)] AS EmailType,\r\n"
				+ "[STRUCT( alias_given_name AS value)] AS AliasGivenName,\r\n"
				+ "[STRUCT( alias_family_name AS value)] AS AliasFamilyName,\r\n"
				+ "[STRUCT( alias_middle_name AS value)] AS AliasMiddleName) AS value )) AS Alias,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( Education_Institution AS value)] AS EducationInstitution,\r\n"
				+ "[STRUCT( Education_Type_Code AS value)] AS EducationTypeCode,\r\n"
				+ "[STRUCT( Reference_Source_Archived_Flag AS value)] AS ReferenceSourceArchivedFlag,\r\n"
				+ "[STRUCT( Reference_In_Use_Flag AS value)] AS ReferenceInUseFlag,\r\n"
				+ "[STRUCT( Subject_Of_Study AS value)] AS SubjectOfStudy,\r\n"
				+ "[STRUCT( Academic_Degree_Code AS value)] AS AcademicDegreeCode,\r\n"
				+ "[STRUCT( Academic_Degree_Start_Date AS value)] AS AcademicDegreeStartDate,\r\n"
				+ "[STRUCT( Academic_Degree_End_Date AS value)] AS AcademicDegreeEndDate) AS value )) AS Education\r\n"
				+ "FROM\r\n"
				+ "temp_unnest2\r\n"
				+ " \r\n"
				+ "GROUP BY\r\n"
				+ "value),\r\n"
				+ "main_elements AS (\r\n"
				+ "SELECT\r\n"
				+ "record_indicator,\r\n"
				+ "meta_src_system_name,\r\n"
				+ "[STRUCT( given_name AS value)] AS GivenName,\r\n"
				+ "[STRUCT( family_name AS value)] AS FamilyName,\r\n"
				+ "[STRUCT( maiden_name AS value)] AS MaidenName,\r\n"
				+ "[STRUCT( middle_name AS value)] AS MiddleName,\r\n"
				+ "[STRUCT( full_name AS value)] AS FullName,\r\n"
				+ "[STRUCT( dob AS value)] AS DOB,\r\n"
				+ "[STRUCT( preferred_name AS value)] AS PreferredName,\r\n"
				+ "[STRUCT( administrative_gender_code AS value)] AS AdministrativeGenderCode,\r\n"
				+ "[STRUCT( ssn AS value)] AS SSN,\r\n"
				+ "[STRUCT( name_suffix_code AS value)] AS NameSuffixCode,\r\n"
				+ "[STRUCT( field_of_licensure_code AS value)] AS FieldofLicensureCode,\r\n"
				+ "[STRUCT(name_prefix_code AS value)] AS NamePrefixCode,\r\n"
				+ "[STRUCT( race_code AS value)] AS RaceCode,\r\n"
				+ "[STRUCT( ethnicity_code AS value)] AS EthnicityCode,\r\n"
				+ "[STRUCT( domestic_partner_name AS value)] AS DomesticPartnerName,\r\n"
				+ "[STRUCT(Marital_status_code AS value)] AS MaritalStatusCode,\r\n"
				+ "[STRUCT( Deceased_flag AS value)] AS DeceasedFlag,\r\n"
				+ "[STRUCT( Death_date AS value)] AS DeathDate,\r\n"
				+ "[STRUCT( Test_Record AS value)] AS TestRecordFlag,\r\n"
				+ "[STRUCT( Status_Code AS value)] AS StatusCode,\r\n"
				+ "[STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ProviderID'))<>0 THEN ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ProviderID')\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT \"\" AS value)\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ProviderID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='ProviderID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value)] AS SystemIdentifier,\r\n"
				+ "crosswalks,\r\n"
				+ "crosswalks.value AS root_key\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.clinical_practitioner_hcp_sort`) \r\n"
				+ "SELECT\r\n"
				+ "'configuration/entityTypes/HCP' AS type,\r\n"
				+ "record_indicator,\r\n"
				+ "meta_src_system_name AS meta_src_system_name,\r\n"
				+ "'MD Staff' AS SourceSystemName,\r\n"
				+ "STRUCT(GivenName,\r\n"
				+ "FamilyName,\r\n"
				+ "MaidenName,\r\n"
				+ "MiddleName,\r\n"
				+ "FullName,\r\n"
				+ "DOB,\r\n"
				+ "AdministrativeGenderCode,\r\n"
				+ "SSN,\r\n"
				+ "NameSuffixCode,\r\n"
				+ "FieldofLicensureCode,\r\n"
				+ "ManagedIdentifier,\r\n"
				+ "SystemIdentifier,\r\n"
				+ "Credential,\r\n"
				+ "PreferredName,\r\n"
				+ "Alias,\r\n"
				+ "LanguageSpoken,\r\n"
				+ "NamePrefixCode,\r\n"
				+ "RaceCode,\r\n"
				+ "EthnicityCode,\r\n"
				+ "DomesticPartnerName,\r\n"
				+ "MaritalStatusCode,\r\n"
				+ "DeceasedFlag,\r\n"
				+ "DeathDate,\r\n"
				+ "TestRecordFlag,\r\n"
				+ "Email,\r\n"
				+ "Phone,\r\n"
				+ "education,\r\n"
				+ "BoardCertification) AS attributes,\r\n"
				+ "crosswalks\r\n"
				+ "FROM\r\n"
				+ "main_elements\r\n"
				+ "JOIN\r\n"
				+ "bridge_unnest1\r\n"
				+ "ON\r\n"
				+ "bridge_unnest1.key_1=main_elements.root_key\r\n"
				+ "JOIN\r\n"
				+ "bridge_unnest2\r\n"
				+ "ON\r\n"
				+ "bridge_unnest2.key_2=main_elements.root_key\"\"\"\r\n"
				+ "\r\n"
				+ "}";
		
		Config conf = ConfigFactory.parseString(q).resolve();
		PCollection<TableRow> in = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery(conf.getString("query")).usingStandardSql());
		PCollection<PubsubMessage> msg = in.apply(ParDo.of(new newConvertFn()));
		msg.apply(PubsubIO.writeMessages().to("projects/asc-ahnat-apdh-sbx/topics/APDH_CANONICAL")); 
		pipeline.run().waitUntilFinish();
	}

	public static class newConvertFn extends DoFn<TableRow, PubsubMessage>{
		
		
		@ProcessElement
		public void ProcessElement(ProcessContext ctx) {
			TableRow obj = ctx.element().clone();
			JSONObject finalObj = new  JSONObject();
			JSONArray finalarr = new JSONArray();
			
			obj.keySet().forEach((k)->{
				if(k.equals("attributes")) {
					TableRow attributes = (TableRow) obj.get(k);
					JSONObject attrObj = new JSONObject();
					attributes.keySet().forEach((key)->{
						Object o = attributes.get(key);
						// intially everything is present inside arraylist
						//if(key.equals("education") || key.equals("BoardCertification") || key.equals("Alias") || key.equals("Email")) {
							//System.out.println("structif "+key+" "+o.getClass()+" "+String.valueOf(o));
						//}else {
						
						if(o instanceof ArrayList) {
							ArrayList valueList = (ArrayList) o;
							if(valueList.get(0) instanceof String) {
								System.out.println("string "+ key + String.valueOf(valueList.get(0)));
							}else if(valueList.get(0) instanceof TableRow) {
								TableRow valueTr = (TableRow) valueList.get(0);
								if(key.equals("ManagedIdentifier")) {
									System.out.println("managed "+o.getClass()+ String.valueOf(o));
								}
								//TableRow value = (TableRow) valueTr.get("value");
								//value for some is tablerow and for some string
								if(valueList.size()==1) {
									Object data = valueTr.get("value");
									if(data instanceof String) {
										String result = String.valueOf(createValFromString(String.valueOf(data)));
										if(result.equals("[{\"value\":\"\"}]")) {
											
										}else {
											attrObj.put(key, createValFromString((String)data));
										}
									}else if(data instanceof TableRow) {
										System.out.println("normaltablerow "+key);
										TableRow value = (TableRow) valueTr.get("value");
										System.out.println("tablerow "+key+" "+String.valueOf(value));
										JSONObject tmpobj = new JSONObject();
										tmpobj.put("value", createJSONArray(value));
										JSONArray tmparr = new JSONArray();
										tmparr.put(tmpobj);
										attrObj.put(key, tmparr);
									}
									else {
										try {
											System.out.println("newdata "+key+" "+data.getClass());
										}catch(NullPointerException e) {
											
										}
									}
								}else {
									
									//each key has size 7 
									//query returns null values where the count of elements is less than 7
									
									JSONObject sysobj = new JSONObject(); //parent
									JSONArray sysarr = new JSONArray();
									Object val = attributes.get(key);
									ArrayList ins = (ArrayList) val;
									TableRow value = (TableRow) ins.get(0);
									TableRow data = (TableRow) value.get("value");
									System.out.println("large "+key+" size "+ins.size());
									System.out.println("nested "+key+" "+String.valueOf(ins));
									//System.out.println();
									//if(key.equals("LanguageSpoken")) {
										JSONArray tmparr = new JSONArray();
										JSONObject okj = new JSONObject();
										for(int i=0;i<ins.size();i++) {
											TableRow tru = (TableRow) ins.get(i);
											TableRow insideVal = (TableRow) tru.get("value");
											System.out.println("langs "+String.valueOf(insideVal));
											JSONObject childsysobj = new JSONObject();
											
											insideVal.keySet().forEach((io)->{
												ArrayList dataKey = (ArrayList) insideVal.get(io);
												TableRow dataValue = (TableRow) dataKey.get(0);
												String content = String.valueOf(dataValue.get("value"));
												System.out.println("content "+io+" "+content);
												
												if(content.equals("null") || content.equals("")) {
													
												}else {
													childsysobj.put(io, createValFromString(content));
												}

											});
											sysobj.accumulate("value", childsysobj);
											System.out.println("sysobj "+sysobj);
										}
										if(sysobj.get("value") instanceof JSONArray) {
											JSONArray newarr = sysobj.getJSONArray("value");
											System.out.println("sysobj"+sysobj.get("value").getClass());
											
											for(int l1=0;l1<newarr.length();l1++) {
												JSONObject temp = new JSONObject();
												System.out.println("newaarr "+newarr.getJSONObject(l1));
												temp.put("value", newarr.getJSONObject(l1));
												sysarr.put(temp);
												
											}
											}else {
												
												JSONObject temp = new JSONObject();
												temp.put("value", sysobj.getJSONObject("value"));
												sysarr.put(temp);
											}
										//remove empty values from array 
										JSONArray nestedarr = new JSONArray();
										for(int h=0;h<sysarr.length();h++) {
											if(!String.valueOf(sysarr.get(h)).equals("{\"value\":{}}")) {
												nestedarr.put(sysarr.get(h));
											}
										}
										if(String.valueOf(nestedarr).equals("[]")) {
											
										}else {
											attrObj.put(key, nestedarr);
										}
									//}
									System.out.println("sysarr "+sysarr);
									
								}
							}else {
								System.out.println("newval "+key+" "+o.getClass());
							}
							
							
						}
					//}
					});
					finalObj.put(k, attrObj);
					System.out.println("attrObj "+String.valueOf(attrObj));
				}else if(k.equals("crosswalks")) {
					System.out.println("crosswalks "+obj.get(k).getClass()+" "+String.valueOf(obj.get(k)));
					JSONArray tmparr = new JSONArray();
					JSONObject obj1 = new JSONObject();
					TableRow tryq = (TableRow) obj.get(k);
					tryq.keySet().forEach((q)->{
						if("crosswalks_type".equals(q)) {
							obj1.put("type", String.valueOf(tryq.get(q)));
						}else if("crosswalks_value".equals(q)) {
							obj1.put("value", String.valueOf(tryq.get(q)));
						}else {
							obj1.put(q, String.valueOf(tryq.get(q)));
						}
						
						
					});
					tmparr.put(obj1);
					finalObj.put(k, tmparr);
				}else {
					finalObj.put(k, String.valueOf(obj.get(k)));
				}
			});
			finalarr.put(finalObj);
			HashMap<String, String> mapData = new HashMap<String, String>();
			byte[] data = String.valueOf(finalarr).getBytes();
			PubsubMessage msg = new PubsubMessage(data, mapData);
			ctx.output(msg);
			System.out.println("finalobj "+finalObj);
		}
		
		public static JSONArray createValFromString(String input) {
			JSONArray tmpArray = new JSONArray();
			JSONObject obj = new JSONObject();
			
			obj.put("value", input);
			tmpArray.put(obj);
			return tmpArray;
		}
	}
	
	public static JSONArray createJSONArray(TableRow tr) {
		JSONObject temp = new JSONObject();
		
		tr.keySet().forEach((key)->{
			if(tr.get(key) instanceof String) {
				temp.put(key, String.valueOf(tr.get(key)));
			}else if(tr.get(key) instanceof ArrayList) {
				ArrayList j = (ArrayList) tr.get(key);
				TableRow tr1 = new TableRow();
				if(String.valueOf(tr1.get("value")).equals("null")) {
					temp.put(key, "");
				}else {
					temp.put(key, String.valueOf(tr1.get("value")));
				}
				
			}
		});
		
		JSONArray returnArray = new JSONArray();
		returnArray.put(temp);
		
		return returnArray;
	}


}
