package org.ascension.addg.gcp.mdstaff;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.windowing.GlobalWindow;
import org.apache.beam.sdk.values.PCollection;

import org.joda.time.Instant;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class aaa {

	public static void main(String[] args) {
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		String q = "{\r\n"
				+ "\r\n"
				+ "\"query\": \"\"\"SELECT\r\n"
				+ "  'configuration/entityTypes/Specialty'AS type,\r\n"
				+ "   'MD Staff'AS SourceSystemName,\r\n"
				+ "    'MDStaff'AS meta_src_system_name,record_indicator,\r\n"
				+ "  STRUCT( ARRAY[ STRUCT(speciality_code AS value)] AS SpecialtyCode,\r\n"
				+ "   [STRUCT(STRUCT( [ STRUCT('SpecialityCode' AS value) ] AS SystemIdentifierType,\r\n"
				+ "      [ STRUCT((\r\n"
				+ "        SELECT\r\n"
				+ "          systemidentifier.systemidentifier_value\r\n"
				+ "        FROM\r\n"
				+ "          UNNEST(systemidentifier) systemidentifier) AS value) ] AS SystemIdentifierValue ) as value) ]AS SystemIdentifier ) AS attributes,\r\n"
				+ "  crosswalks\r\n"
				+ "FROM `asc-ahnat-apdh-sbx.apdh_test_dataset.specialty_sort`\r\n"
				+ "\"\"\"\r\n"
				+ "\r\n"
				+ "}";
		
		Config conf = ConfigFactory.parseString(q).resolve();
		PCollection<TableRow> in = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery(conf.getString("query")).usingStandardSql());
		PCollection<PubsubMessage> msg = in.apply(ParDo.of(new ConvertFn()));
		msg.apply(PubsubIO.writeMessages().to("projects/asc-ahnat-apdh-sbx/topics/APDH_CANONICAL")); 
		pipeline.run().waitUntilFinish();
	}
	
	public static class PrintValueFn extends DoFn<TableRow, TableRow>{
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			System.out.println(String.valueOf(c.element()));
		}
	}
	
	public static class ConvertFn extends DoFn<TableRow, PubsubMessage>{
		
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			
			
			JSONArray emptyArr = new JSONArray();
			JSONObject emptyObj = new JSONObject();
			emptyObj.put("value", "");
			
			emptyArr.put(emptyObj);
			
			TableRow obj = c.element().clone();
			JSONObject finalObj = new  JSONObject();
			JSONArray finalarr = new JSONArray();
			
			obj.keySet().forEach((k)->{
				
				//System.out.println("key "+k+" value "+obj.get(k)+" classname "+obj.get(k).getClass());
				if(k.equals("attributes")) {
					TableRow in = (TableRow) obj.get(k);
					JSONObject attrObj = new JSONObject();
					
					in.keySet().forEach((key)->{
						//array list -> normal values, tablerow -> systemidentifier
						System.out.println("attributes key"+key+" value "+in.get(key)+" classname "+in.get(key).getClass());
						Object o = in.get(key);
						if(o instanceof ArrayList) {
							ArrayList l = (ArrayList) o;
							System.out.println("arraylistinfo "+String.valueOf(o)+" classname"+l.get(0).getClass());
							TableRow trVal = (TableRow) l.get(0);
							if(String.valueOf(trVal).equals("GenericData{classInfo=[f], {}}")) {
								
								attrObj.put(key, emptyArr);
							}else if(key.equals("SystemIdentifier")) {
								JSONArray sysarr = new JSONArray();
								System.out.println("suysident"+String.valueOf(o));
								ArrayList al = (ArrayList) o;
								
								JSONObject sysobj = new JSONObject(); //parent
								
								
								for(int h =0;h<al.size();h++){
									System.out.println("Stream "+String.valueOf(h)+" "+al.get(h).getClass());
									TableRow tr = (TableRow) al.get(h);
									tr.keySet().forEach((g)->{
										// g is value
										System.out.println("second "+g+String.valueOf(tr.get(g))+" "+tr.get(g).getClass());
										TableRow m = (TableRow) tr.get(g);
										JSONObject childsysobj = new JSONObject();
										m.keySet().forEach((v)->{
											ArrayList ins = (ArrayList) m.get(v);
											System.out.println("insrt "+ins);
											TableRow hjk = (TableRow) ins.get(0);
											System.out.println("hjklop "+hjk);
											String val = String.valueOf(hjk.get("value"));
											System.out.println("valuein "+val+" keysst "+v);
											childsysobj.put(v, createFromString(val));
											System.out.println("childsysobj2 "+childsysobj);
										});
										sysobj.accumulate("value", childsysobj);
										System.out.println("sysobj "+sysobj);
										
									});
								}
								
								if(sysobj.get("value") instanceof JSONArray) {
									JSONArray newarr = sysobj.getJSONArray("value");
									System.out.println("sysobj"+sysobj.get("value").getClass());
									
									for(int l1=0;l1<newarr.length();l1++) {
										JSONObject temp = new JSONObject();
										System.out.println("newaarr "+newarr.getJSONObject(l1));
										temp.put("value", newarr.getJSONObject(l1));
										sysarr.put(temp);
										
									}
									}else {
										
										JSONObject temp = new JSONObject();
										temp.put("value", sysobj.getJSONObject("value"));
										sysarr.put(temp);
									}
								/*
								trVal.keySet().forEach((b)->{
									System.out.println("insidetrkeyset "+ " key "+b+" "+String.valueOf(trVal.get(b))+" classname "+trVal.get(b).getClass());
									//tablerow -> key [list contains tablerow] [tr]
									
									//childsysobj.put(b, createJSONArray(trVal.get(b)));
									
									TableRow insideVal = (TableRow) trVal.get(b);
									List<String> keyNames = new ArrayList<>();
									insideVal.keySet().forEach((p)->{
										System.out.println("insidetrkeyset "+ " key "+p+" "+String.valueOf(insideVal.get(p))+" classname "+insideVal.get(p).getClass());
										ArrayList v = (ArrayList) insideVal.get(p);
										TableRow t = (TableRow) v.get(0);
										
										/*
										t.keySet().forEach((q)->{
											if(t.get(q) instanceof ArrayList) {
												System.out.println("arraylistinsidetablerow "+" key "+q+" "+t.get(q).getClass()+" value "+String.valueOf(t.get(q)));
											}else {
												childsysobj.put(p, createFromString((String) t.get(q)));
												System.out.println("childsysobj "+childsysobj);
												
											}
										});
										
									});
									
									//System.out.println("insidevalsize "+insideVal.size()); 2
									
								});
								*/
								//sysobj.put("value", childsysobj);
								//sysarr.put(sysobj);
								System.out.println("sysarr "+sysarr);
								attrObj.put(key, sysarr);
							}else if(key.equals("Zip")) {
								ArrayList kmn = (ArrayList) o;
								TableRow rtz = (TableRow) kmn.get(0);
								JSONObject amn = new JSONObject();
								JSONObject parentObj = new JSONObject();
								
								JSONArray arr = new JSONArray();
								TableRow trrr = (TableRow) rtz.get("value");
								trrr.keySet().forEach((n)->{
									System.out.println(n+" "+"trrr "+String.valueOf(trrr.get(n))+" classname "+trrr.get(n).getClass());
									ArrayList al = (ArrayList) trrr.get(n);
									TableRow g = new TableRow();
									System.out.println("gggg "+g);
									String val = String.valueOf(g.get("value"));
									JSONArray tmparr = new JSONArray();
									JSONObject obj1 = new JSONObject();
									if(val.equals("null")) {
										obj1.put("value", "");
									}else {
										obj1.put("value", val);
									}
									
									tmparr.put(obj1);
									amn.put(n, tmparr);
								});
								parentObj.put("value", amn);
								arr.put(parentObj);
								attrObj.put(key, arr);
							}else {
							//System.out.println("Arraylistinfo "+key+"val "+String.valueOf(trVal));
								attrObj.put(key, createJSONArray(trVal));
							}
						}else if(o instanceof TableRow) {
							TableRow tr = (TableRow) o;
							//System.out.println("tablerowval"+tr);
							JSONObject tempObj = new JSONObject();
							JSONObject valueObject = new JSONObject();
							tr.keySet().forEach((l)->{
								System.out.println("tablerowval "+String.valueOf(l)+tr.get(l)+" classname "+tr.get(l).getClass());
								ArrayList x = (ArrayList) tr.get(l);
								tempObj.put(l, createJSONArray((TableRow)x.get(0)));
							});
							valueObject.put("value", tempObj);
							attrObj.put(key, valueObject);
						}
					});
					finalObj.put("attributes", attrObj);
				}else if(k.equals("crosswalks")) {
					System.out.println("Crosswalks"+obj.get(k).getClass());
					
					ArrayList ca = (ArrayList) obj.get(k);
					System.out.println("arraylistcrswlk "+String.valueOf(obj.get(k))+" classtype "+obj.get(k).getClass());
					/*
					JSONObject ctr = new JSONObject();
					finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
					*/
					finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
				}else {
					finalObj.put(k, String.valueOf(obj.get(k)));
				}
			});
			System.out.println("finalobject "+finalObj);
			
			//finalarray.put(finalObj);
			finalarr.put(finalObj);
			HashMap<String, String> mapData = new HashMap<String, String>();
			byte[] data = String.valueOf(finalarr).getBytes();
			PubsubMessage msg = new PubsubMessage(data, mapData);
			c.output(msg);
	}
		
		
	}
	
	public static JSONArray createJSONArray(TableRow tr) {
		JSONObject temp = new JSONObject();
		
		tr.keySet().forEach((key)->{
			if(tr.get(key) instanceof String) {
				temp.put(key, String.valueOf(tr.get(key)));
			}else if(tr.get(key) instanceof ArrayList) {
				ArrayList j = (ArrayList) tr.get(key);
				temp.put(key, String.valueOf(j.get(0)));
			}
		});
		
		JSONArray returnArray = new JSONArray();
		returnArray.put(temp);
		
		return returnArray;
	}
	
	public static JSONArray createFromString(String input) {
		
		
		JSONObject value = new JSONObject();
		JSONArray arr = new JSONArray();
		value.put("value", input);
		
		arr.put(value);
		return arr;
	}

}
