package org.ascension.addg.gcp.transformation;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;

import java.util.List;

public class ConvertBQRecord
{
    public TableRow ConvertToCustomBQFormat(TableRow original_row,TableRow transformed_row)
    {
        TableRow OutputTableRow=new TableRow();
        OutputTableRow.set("original",original_row);
        OutputTableRow.set("transformed",transformed_row);
        return OutputTableRow;
    }

    public Object GetFields(List<? extends Config> CleansingSpecificationsList, String RuleName)
    {
        Object fields = null;
        for (Config CleansingRule : CleansingSpecificationsList)
        {
            if((CleansingRule).getString("RuleName").equalsIgnoreCase(RuleName))
            {
                try
                {
                    fields=(CleansingRule).getConfigList("fields");
                }
                catch (com.typesafe.config.ConfigException e)
                {
                    fields=(CleansingRule).getStringList("fields");
                }
            }
        }
        return fields;
    }

}