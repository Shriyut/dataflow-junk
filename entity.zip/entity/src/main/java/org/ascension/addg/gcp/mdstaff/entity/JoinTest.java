package org.ascension.addg.gcp.mdstaff.entity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.channels.Channels;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.ascension.addg.gcp.mdstaff.entity.SampleIngestionOptions;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class JoinTest {

	public static void main(String[] args) throws UnsupportedEncodingException, IOException {
		SampleIngestionOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(SampleIngestionOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		
		String configUrl = options.getJoinConfig().get();
	     
	     StringBuilder dataBuilder = new StringBuilder();
	     
	     BufferedReader streamReader = new BufferedReader(new InputStreamReader(Channels.newInputStream(FileSystems.open(FileSystems.matchNewResource(configUrl, false))), "UTF-8"));
	     String line;
	     while (( line = streamReader.readLine()) != null) {
	    	 dataBuilder.append(line);
	    	 dataBuilder.append("\n");
	     }
	   
	     String fileContent = dataBuilder.toString();
	     Config config = ConfigFactory.parseString(fileContent).resolve();
	
		//PCollection<TableRow> address = pipeline.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.address_land LIMIT 100"));
		//PCollection<TableRow> site = pipeline.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.site_land LIMIT 100"));
		
		//String configUrl = options.getJoinConfig().get();
	     
	    // StringBuilder dataBuilder = new StringBuilder();
	     
	    // BufferedReader streamReader = new BufferedReader(new InputStreamReader(Channels.newInputStream(FileSystems.open(FileSystems.matchNewResource(configUrl, false))), "UTF-8"));
	    // String line;
	    // while (( line = streamReader.readLine()) != null) {
	    //	 dataBuilder.append(line);
	    //	 dataBuilder.append("\n");
	    // }
	   
	   // String fileContent = dataBuilder.toString();
	   //  Config config = ConfigFactory.parseString(fileContent).resolve();
		
		/* // loc data
	     Config locationConfig = config.getConfig("locationConfig");
	     
	     PCollection<TableRow> location = address.apply(new GenerateEntityRecord(site, "Location", locationConfig));
	     
	     List<TableFieldSchema> fields = new ArrayList<TableFieldSchema>(); 

			fields.add(new TableFieldSchema().setName("AddressLine1").setType("String").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("AddressLine2").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("City").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("StateProvince").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("Country").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("SubAdministrativeArea").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("PublishToExternalDirectoryFlag").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("PublishToExternalDirectoryPrimaryFlag").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("AddressInUse").setType("STRING").setMode("NULLABLE"));
			fields.add(new TableFieldSchema().setName("SystemIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
							Arrays.asList(new TableFieldSchema().setName("SystemIdentifierType").setType("String"),
							new TableFieldSchema().setName("SystemIdentifierValue").setType("STRING"))));
			fields.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
							Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
							new TableFieldSchema().setName("value").setType("STRING"))));
			fields.add(new TableFieldSchema().setName("Zip").setType("STRUCT").setFields(
					Arrays.asList(new TableFieldSchema().setName("PostalCode").setType("String"),
							new TableFieldSchema().setName("Zip5").setType("String"),
					new TableFieldSchema().setName("Zip4").setType("STRING"))));
							
			TableSchema schema = new TableSchema().setFields(fields);
			
			location.apply("Writing to BQ", BigQueryIO.writeTableRows()
					.to("asc-ahnat-apdh-sbx:apdh_test_dataset.aaaanew")
					.withSchema(schema)
					.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
					.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
					*/
		
		/*//Org data
		PCollection<TableRow> facility = pipeline.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.facility_land LIMIT 100"));
		PCollection<TableRow> entity = pipeline.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.entity_land LIMIT 100"));
		PCollection<TableRow> site = pipeline.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.site_land LIMIT 100"));
		
		Config hcoConfig = config.getConfig("hcoConfig");
		PCollection<TableRow> hco = entity.apply(new GenerateEntityRecord(facility, site, "HCO", hcoConfig));
		
		List<TableFieldSchema> fieldsOrg = new ArrayList<TableFieldSchema>(); 

		fieldsOrg.add(new TableFieldSchema().setName("OrganizationName").setType("String").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("OrganizationTypeCode").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("OrganizationCode").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("Status").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("EntityInUseFlag").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("SiteInUseFlag").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("FacilityArchivedFlag").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("DoingBusinessAs").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("PatientCenteredMedicalHomeFlag").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("SystemIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
						Arrays.asList(new TableFieldSchema().setName("SystemIdentifierType").setType("String"),
						new TableFieldSchema().setName("SystemIdentifierValue").setType("STRING"))));
		fieldsOrg.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
						Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
						new TableFieldSchema().setName("value").setType("STRING"))));
		fieldsOrg.add(new TableFieldSchema().setName("ManagedIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
				Arrays.asList(new TableFieldSchema().setName("ManagedIdentifierType").setType("String"),
						new TableFieldSchema().setName("ManagedIdentifierValue").setType("String"),
				new TableFieldSchema().setName("IssuingAuthority").setType("STRING"),
				new TableFieldSchema().setName("State").setType("STRING"),
				new TableFieldSchema().setName("InitialIssueDate").setType("STRING"),
				new TableFieldSchema().setName("EffectiveDate").setType("STRING"),
				new TableFieldSchema().setName("RenewalDate").setType("STRING"),
				new TableFieldSchema().setName("ExpirationDate").setType("STRING"))));
		fieldsOrg.add(new TableFieldSchema().setName("Email").setType("STRUCT").setFields(
						Arrays.asList(new TableFieldSchema().setName("EmailType").setType("String"),
						new TableFieldSchema().setName("Email").setType("STRING"))));		

						
		TableSchema schemaOrg = new TableSchema().setFields(fieldsOrg);
		
		hco.apply("Writing to BQ", BigQueryIO.writeTableRows()
				.to("asc-ahnat-apdh-sbx:apdh_test_dataset.aaOrgDataNew")
				.withSchema(schemaOrg)
				.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
				.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
		*/
		
		// clinical Expertise
		/*
		PCollection<TableRow> org = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.appointment_land"));
		
		Config ceConfig = config.getConfig("clinicalExpertiseConfig");
		PCollection<TableRow> output = org.apply(new GenerateEntityRecord(ceConfig, "ClinicalExpertise", org));
		
		List<TableFieldSchema> fields = new ArrayList<TableFieldSchema>(); 
		  
		fields.add(new TableFieldSchema().setName("ClinicalExpertise").setType("String").setMode("NULLABLE"));
		fields.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
				Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
				new TableFieldSchema().setName("value").setType("STRING"))));
		TableSchema schema = new TableSchema().setFields(fields);
		
		output.apply("Writing to BQ",
				BigQueryIO.writeTableRows().to("asc-ahnat-apdh-sbx:apdh_test_dataset.newclinical")
						.withSchema(schema)
						.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
						*/
		
		//specialty
		/*
		PCollection<TableRow> org = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.appointment_land"));
		
		Config ceConfig = config.getConfig("specialtyExpertiseConfig");
		PCollection<TableRow> output = org.apply(new GenerateEntityRecord(ceConfig, "Specialty", org));
		
		List<TableFieldSchema> fields = new ArrayList<TableFieldSchema>(); 
		  
		fields.add(new TableFieldSchema().setName("Specialty").setType("String").setMode("NULLABLE"));
		fields.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
				Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
				new TableFieldSchema().setName("value").setType("STRING"))));
		TableSchema schema = new TableSchema().setFields(fields);
		
		output.apply("Writing to BQ",
				BigQueryIO.writeTableRows().to("asc-ahnat-apdh-sbx:apdh_test_dataset.newspecialty")
						.withSchema(schema)
						.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
						
		*/
		
		//ministry
	     /*
		PCollection<TableRow> org = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.appointment_land"));
		
		Config ceConfig = config.getConfig("ministryConfig");
		PCollection<TableRow> output = org.apply(new GenerateEntityRecord(ceConfig, "Ministry"));
		
		List<TableFieldSchema> fields = new ArrayList<TableFieldSchema>(); 
		  
		fields.add(new TableFieldSchema().setName("Ministry").setType("String").setMode("NULLABLE"));
		fields.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
				Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
				new TableFieldSchema().setName("value").setType("STRING"))));
		TableSchema schema = new TableSchema().setFields(fields);
		
		output.apply("Writing to BQ",
				BigQueryIO.writeTableRows().to("asc-ahnat-apdh-sbx:apdh_test_dataset.newministry")
						.withSchema(schema)
						.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
		*/
	     
	     //individual
	     
	     PCollection<TableRow> demo = pipeline
	                .apply("read bq", BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.demographic_land").usingStandardSql());
	     PCollection<TableRow> reference = pipeline
					.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.reference_land").usingStandardSql());
			
		PCollection<TableRow> referenceSource = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.referencesource_land").usingStandardSql());
		PCollection<TableRow> alias = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.alias_land").usingStandardSql());
		
		PCollection<TableRow> credential = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.credential_land").usingStandardSql());
		
		PCollection<TableRow> board = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.boardcertification_land").usingStandardSql());
		
			Config indConfig = config.getConfig("indConfig");
	     PCollection<TableRow> outputInd = demo.apply(new GenerateEntityRecord(indConfig, credential, reference, referenceSource, alias, board, "IND"));
	     
	     List<TableFieldSchema> fieldsOrg = new ArrayList<TableFieldSchema>();
     
	     fieldsOrg.add(new TableFieldSchema().setName("ProviderID").setType("STRING").setMode("NULLABLE"));
	     fieldsOrg.add(new TableFieldSchema().setName("Status").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("NameSuffixCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("RaceCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("FieldofLicensureCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("FamilyName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("GivenName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DeceasedFlag").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("MiddleName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DeathDate").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("SSN").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("MaritalStatusCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DOB").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DomesticPartnerName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("NamePrefixCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("LastUpdated").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("FullName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("EthnicityCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("PreferredName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("AdministrativeGenderCode").setType("STRING").setMode("NULLABLE"));
		
		fieldsOrg.add(new TableFieldSchema().setName("NPI").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("MedicareNumber").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("MedicaidNumber").setType("STRING").setMode("NULLABLE"));
		fieldsOrg.add(new TableFieldSchema().setName("TaxID").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("SystemIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("SystemIdentifierType").setType("String"),
        				new TableFieldSchema().setName("SystemIdentifierValue").setType("STRING"))));
        fieldsOrg.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
        				Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
        				new TableFieldSchema().setName("value").setType("STRING"))));
        fieldsOrg.add(new TableFieldSchema().setName("ManagedIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
        		Arrays.asList(new TableFieldSchema().setName("ManagedIdentifierType").setType("String"),
        				new TableFieldSchema().setName("ManagedIdentifierValue").setType("String"),
        				new TableFieldSchema().setName("StateProfessionalLicenseTypeCode").setType("STRING"),
        				new TableFieldSchema().setName("Profession").setType("STRING"),
        		new TableFieldSchema().setName("IssuingAuthority").setType("STRING"),
        		new TableFieldSchema().setName("State").setType("STRING"),
        		new TableFieldSchema().setName("InitialIssueDate").setType("STRING"),
        		new TableFieldSchema().setName("EffectiveDate").setType("STRING"),
        		new TableFieldSchema().setName("RenewalDate").setType("STRING"),
        		new TableFieldSchema().setName("CredentialInUseFlag").setType("STRING"),
        		new TableFieldSchema().setName("ExpirationDate").setType("STRING"))));
        fieldsOrg.add(new TableFieldSchema().setName("Phone").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("PhoneType").setType("String"),
        				new TableFieldSchema().setName("Number").setType("String"),
        				new TableFieldSchema().setName("Extension").setType("String"),
        				new TableFieldSchema().setName("Rank").setType("STRING"))));	
        fieldsOrg.add(new TableFieldSchema().setName("Credential").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("CredentialCode").setType("String"),
        				new TableFieldSchema().setName("CredentialRank").setType("STRING"))));					
        fieldsOrg.add(new TableFieldSchema().setName("LanguageSpoken").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("LanguageSpokenCode").setType("String"),
        				new TableFieldSchema().setName("LanguageSpokenRank").setType("STRING"))));	
						
        fieldsOrg.add(new TableFieldSchema().setName("BoardCertification").setType("STRUCT").setMode("REPEATED").setFields(
				Arrays.asList(new TableFieldSchema().setName("BoardCertificationCode").setType("String"),
				new TableFieldSchema().setName("BoardCertificationSpecialtyCode").setType("String"),
				new TableFieldSchema().setName("BoardCertificationStatusCode").setType("String"),
				new TableFieldSchema().setName("BoardCertificationNumber").setType("String"),
				new TableFieldSchema().setName("BoardCertificationLifetimeStatus").setType("String"),
				new TableFieldSchema().setName("BoardCertificationInUseFlag").setType("String"),
				new TableFieldSchema().setName("BoardCertificationInitialDate").setType("String"),
				new TableFieldSchema().setName("BoardCertificationExpirationDate").setType("String"),
				new TableFieldSchema().setName("BoardCertificationExamDate").setType("STRING"))));
				
		fieldsOrg.add(new TableFieldSchema().setName("Alias").setType("STRUCT").setMode("REPEATED").setFields(
				Arrays.asList(new TableFieldSchema().setName("AliasNameTypeCode").setType("String"),
				new TableFieldSchema().setName("AliasGivenName").setType("String"),
				new TableFieldSchema().setName("AliasFamilyName").setType("String"),
				new TableFieldSchema().setName("AliasMiddleName").setType("STRING"))));
		
		fieldsOrg.add(new TableFieldSchema().setName("Education").setType("STRUCT").setMode("REPEATED").setFields(
				Arrays.asList(new TableFieldSchema().setName("EducationInstitution").setType("String"),
				new TableFieldSchema().setName("EducationTypeCode").setType("String"),
				new TableFieldSchema().setName("ReferenceSourceArchivedFlag").setType("String"),
				new TableFieldSchema().setName("ReferenceInUseFlag").setType("String"),
				new TableFieldSchema().setName("SubjectOfStudy").setType("String"),
				new TableFieldSchema().setName("AcademicDegreeCode").setType("String"),
				new TableFieldSchema().setName("AcademicDegreeStartDate").setType("String"),
				new TableFieldSchema().setName("AcademicDegreeEndDate").setType("STRING"))));
		
		 TableSchema schemaInd = new TableSchema().setFields(fieldsOrg);
		 //"asc-ahnat-apdh-sbx:apdh_test_dataset.indtestttt"
		 		 try {
		 outputInd.apply("Writing to BQ",
					BigQueryIO.writeTableRows().to("asc-ahnat-apdh-sbx:apdh_test_dataset.indtesttable")
							.withSchema(schemaInd)
							
							.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
							.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
		 }catch(Throwable e) {
			 e.printStackTrace();
		 }
    
		pipeline.run(options).waitUntilFinish();
	}

}