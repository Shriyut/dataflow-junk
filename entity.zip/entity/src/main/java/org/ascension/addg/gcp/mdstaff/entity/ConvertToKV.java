package org.ascension.addg.gcp.mdstaff.entity;

import com.google.api.services.bigquery.model.TableRow;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.values.KV;

public class ConvertToKV extends SimpleFunction<TableRow,KV<String,TableRow>> {
    private String joinkey;
    public ConvertToKV(String joinkey){
        this.joinkey=joinkey;
    }

    public KV<String,TableRow> apply(TableRow input) {
    	
		
    	return KV.of(String.valueOf(input.get(joinkey)), input);
    }
 
}
