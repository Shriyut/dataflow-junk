package org.ascension.addg.gcp.mdstaff.entity;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;

public class TransformOrganizationRecord extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{
	
	private Config config;

	public TransformOrganizationRecord(Config config) {
		this.config = config;
	}

	@Override
	public PCollection<TableRow> expand(PCollection<TableRow> input) {
		
		PCollection<TableRow> transformedRecord = input.apply(ParDo.of(new DoFn<TableRow, TableRow>(){
			@ProcessElement
			public void ProcessELement(ProcessContext ctx) {
				TableRow inputObj = ctx.element().clone();
				TableRow returnObj = new TableRow();
				
				List<String> attrList = (List<String>) config.getObject(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS).keySet().stream().collect(Collectors.toList());
				Config values = config.getConfig(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS);
				
				attrList.stream().forEach((attr)->{
					String recordName = values.getString(attr);
					if(recordName.equals(RecordGenerationConstants.NO_RECORD)) {
						returnObj.set(attr, "");
					}else if(attr.equals("OrganizationTypeCode")) {
						if(recordName.equals("site_type_code")) {
							returnObj.set(attr, String.valueOf(inputObj.get(recordName)));
						}else {
							returnObj.set(attr, recordName);
						}
					}else {
						returnObj.set(attr, String.valueOf(inputObj.get(recordName)));
					}
				});
				
				Config crosswalkConfig = config.getConfig(RecordGenerationConstants.CROSSWALKS);
				String crosswalkKey = crosswalkConfig.getString(RecordGenerationConstants.KEY);
				TableRow crosswalk = new TableRow();
				crosswalk.set(RecordGenerationConstants.TYPE, RecordGenerationConstants.MDSTAFF_URI);
				crosswalk.set(RecordGenerationConstants.VALUE, String.valueOf(inputObj.get(crosswalkKey))+"||hco");
				returnObj.set(RecordGenerationConstants.CROSSWALKS, crosswalk);
				
				List<String> identifierValuesList = (List<String>) config.getObject(RecordGenerationConstants.SYSTEM_IDENTIFIER).keySet().stream().collect(Collectors.toList());
				TableRow[] systemIdentifier = new TableRow[identifierValuesList.size()];
				
				for(int i=0;i<identifierValuesList.size();i++) {
					TableRow identity = new TableRow();
					identity.set(RecordGenerationConstants.SYSTEM_IDENTIFIER_TYPE, config.getConfig(RecordGenerationConstants.SYSTEM_IDENTIFIER).getString(identifierValuesList.get(i)));
					identity.set(RecordGenerationConstants.SYSTEM_IDENTIFIER_VALUE, String.valueOf(inputObj.get(identifierValuesList.get(i))));
					systemIdentifier[i] = identity;
				}
				returnObj.set(RecordGenerationConstants.SYSTEM_IDENTIFIER, systemIdentifier);
				
				Config emailConfig = config.getConfig(RecordGenerationConstants.EMAIL);
				List<String> emailKeyList = (List<String>) config.getObject(RecordGenerationConstants.EMAIL).keySet().stream().collect(Collectors.toList());
				TableRow email = new TableRow();
				emailKeyList.stream().forEach((k)->{
					if(emailConfig.getString(k).equals(RecordGenerationConstants.NO_RECORD)) {
						email.set(k, "");
					}else {
						email.set(k, String.valueOf(inputObj.get(k)));
					}
				});
				returnObj.set(RecordGenerationConstants.EMAIL, email);
				
				Config managedIdentifierConfig = config.getConfig(RecordGenerationConstants.MANAGED_IDENTIFIER_CONFIG_KEY);
				List<String> managedIdentifierList = (List<String>) config.getObject(RecordGenerationConstants.MANAGED_IDENTIFIER_CONFIG_KEY).keySet().stream().collect(Collectors.toList());
				
				TableRow[] managedIdentifier = new TableRow[managedIdentifierList.size()];
				for(int i=0;i<managedIdentifierList.size();i++) {
					TableRow identity = new TableRow();
					Config identifierProperty = managedIdentifierConfig.getConfig(managedIdentifierList.get(i));
					List<String> properties = (List<String>) managedIdentifierConfig.getObject(managedIdentifierList.get(i)).keySet().stream().collect(Collectors.toList());
					
					properties.stream().forEach((k)->{
						if(k.equals(RecordGenerationConstants.MANAGED_IDENTIFIER_TYPE)) {
							if(identifierProperty.getString(k).equals(RecordGenerationConstants.NO_RECORD)) {
								identity.set(k, "");
							}else {
								identity.set(k, identifierProperty.getString(k));
							}
						}else if(identifierProperty.getString(k).equals(RecordGenerationConstants.NO_RECORD)){
							identity.set(k, "");
						}else {
							identity.set(k, inputObj.get(identifierProperty.getString(k)));
						}
					
					});
					managedIdentifier[i] = identity;
				}
				
				returnObj.set(RecordGenerationConstants.MANAGED_IDENTIFIER, managedIdentifier);
				ctx.output(returnObj);
			}
			
		}));
		return transformedRecord;
	}
	
	

}