package org.ascension.addg.gcp.mdstaff.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;

public class AddressTest {

	public static void main(String[] args) {
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		PCollection<TableRow> address = pipeline.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.address_land"));

		PCollection<TableRow> result = address.apply(ParDo.of(new DoFn<TableRow, TableRow>(){
			@ProcessElement
			public void ProcessElement(ProcessContext c) {
				TableRow obj = c.element().clone();
				TableRow returnObj = new TableRow();
				
				String site = String.valueOf(obj.get("MedicalGroupID"));
				returnObj.set("SiteID", site);
				String addr = String.valueOf(obj.get("AddressID"));
				returnObj.set("AddressID", addr);
				
				TableRow[] num = new TableRow[3];
				List<String> vals = new ArrayList<>();
				vals.add("Telephone");
				vals.add("Backline");
				vals.add("Fax");
				
				for(int i=0;i<vals.size();i++) {
					TableRow tempNum = new TableRow();
					
					//String tempVal = String.valueOf(vals.get(i));
					tempNum.set("PhoneType", vals.get(i));
					tempNum.set("Number", String.valueOf(obj.get(vals.get(i))));
					
					num[i] = tempNum;
				}
				System.out.println(String.valueOf(returnObj));
				returnObj.set("Phone", num);
				c.output(returnObj);
			}
		}));
		
		List<TableFieldSchema> fieldsOrg = new ArrayList<TableFieldSchema>();
	     
	     fieldsOrg.add(new TableFieldSchema().setName("SiteID").setType("STRING").setMode("NULLABLE"));
	     fieldsOrg.add(new TableFieldSchema().setName("AddressID").setType("STRING").setMode("NULLABLE"));
	     
	     fieldsOrg.add(new TableFieldSchema().setName("Phone").setType("STRUCT").setMode("REPEATED").setFields(
 				Arrays.asList(new TableFieldSchema().setName("PhoneType").setType("String"),
 				new TableFieldSchema().setName("Number").setType("STRING"))));
	     TableSchema schemaInd = new TableSchema().setFields(fieldsOrg);
	     result.apply("Writing to BQ",
					BigQueryIO.writeTableRows().to("asc-ahnat-apdh-sbx:apdh_test_dataset.addresstest")
							.withSchema(schemaInd)
							
							.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
							.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
		
		
		pipeline.run().waitUntilFinish();
	}

}
