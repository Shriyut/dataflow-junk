package org.ascension.addg.gcp.mdstaff.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.PCollection;



import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class TransformIndRecord extends PTransform<PCollection<TableRow>, PCollection<TableRow>> {

	
	private Config config;
	private PCollection<TableRow> credential;
	private PCollection<TableRow> reference;
	private PCollection<TableRow> refSource;
	private PCollection<TableRow> alias;
	private PCollection<TableRow> board;
	
	public TransformIndRecord(Config config, PCollection<TableRow> credential, PCollection<TableRow> reference, PCollection<TableRow> refSource,
			PCollection<TableRow> alias, PCollection<TableRow> board) {
		this.config = config;
		this.credential = credential;
		this.reference = reference;
		this.refSource = refSource;
		this.alias = alias;
		this.board = board;
	}
	
	// input will be demographic pcollection
	@Override
	public PCollection<TableRow> expand(PCollection<TableRow> input) {
		
		
		PCollection<TableRow> refPC = reference.apply(ParDo.of(new ExtractEntityFn(config, RecordGenerationConstants.REFERENCE, RecordGenerationConstants.NOCHECK, RecordGenerationConstants.NOCHECK)));
		PCollection<TableRow> refSourcePC = refSource.apply(ParDo.of(new ExtractEntityFn(config, RecordGenerationConstants.REFERENCESOURCE, RecordGenerationConstants.NOCHECK, RecordGenerationConstants.NOCHECK)));
		
		PCollection<TableRow> refJoin = refPC.apply(new PerformJoin(refSourcePC, RecordGenerationConstants.REFERENCESOURCEID, RecordGenerationConstants.INNERJOIN));
		PCollection<TableRow> boardStruct = board.apply(ParDo.of(new CreateBoardStructFn(config.getConfig(RecordGenerationConstants.BOARDCONFIG))));
		Config eduConfig = config.getConfig(RecordGenerationConstants.EDUCONFIG);
		PCollection<TableRow> refWithEducationStruct = refJoin.apply(ParDo.of(new ReferenceFormatFn(eduConfig)));
		
		PCollection<TableRow> formattedAlias = alias.apply(ParDo.of(new ExtractAliasFn(config.getConfig(RecordGenerationConstants.ALIASCONFIG))));
		
		Config credConfig = config.getConfig(RecordGenerationConstants.CRED);
		PCollection<TableRow> spl = credential.apply(ParDo.of(new ExtractEntityFn(credConfig, RecordGenerationConstants.CREDPARAMS, RecordGenerationConstants.STATEPROFLICENSE,credConfig.getString(RecordGenerationConstants.CHECKCOL))));
		PCollection<TableRow> dea = credential.apply(ParDo.of(new ExtractEntityFn(credConfig, RecordGenerationConstants.CREDPARAMS, RecordGenerationConstants.DEA, credConfig.getString(RecordGenerationConstants.CHECKCOL))));
		PCollection<TableRow> cds = credential.apply(ParDo.of(new ExtractEntityFn(credConfig, RecordGenerationConstants.CREDPARAMS, RecordGenerationConstants.CDSCSR, credConfig.getString(RecordGenerationConstants.CHECKCOL))));
		
		Config demoConfig = config.getConfig(RecordGenerationConstants.DEMOCONFIG);
		
		PCollection<TableRow> demoVal = input.apply(ParDo.of(new DemoFn(demoConfig)));
		
		PCollection<TableRow> cdsjoin = demoVal.apply(new CredentialSpecificJoin(cds, RecordGenerationConstants.CDSCODE, credConfig));
        PCollection<TableRow> deajoin = cdsjoin.apply(new CredentialSpecificJoin(dea, RecordGenerationConstants.DEACODE, credConfig));
        PCollection<TableRow> spljoin = deajoin.apply(new CredentialSpecificJoin(spl, RecordGenerationConstants.SPLCODE, credConfig));
        
        Config managedIdentifierConfig = config.getConfig(RecordGenerationConstants.INDMANAGEDIDENTIFIERCONF);
        
        PCollection<TableRow> identifier = spljoin.apply(ParDo.of(new AddManagedIdentifierFn(7, managedIdentifierConfig)));
		
       PCollection<TableRow> educationJoin = identifier.apply(new PerformJoin(refWithEducationStruct, RecordGenerationConstants.PROVIDERID, RecordGenerationConstants.LEFTOUTERJOIN));
        PCollection<TableRow> alaisJoin = educationJoin.apply(new PerformJoin(formattedAlias, RecordGenerationConstants.PROVIDERID, RecordGenerationConstants.LEFTOUTERJOIN));
        PCollection<TableRow> finalOutput = alaisJoin.apply(new PerformJoin(boardStruct, RecordGenerationConstants.PROVIDERID, RecordGenerationConstants.LEFTOUTERJOIN));
       
		return finalOutput;
	}

	public static class ReferenceFormatFn extends DoFn<TableRow, TableRow>{
		
		private Config educationConfig;
		public ReferenceFormatFn(Config educationConfig) {
			this.educationConfig = educationConfig;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			
			TableRow finalOutput = new TableRow();
			TableRow[] education = new TableRow[1];
			TableRow temp = new TableRow();
			
			Config eduParams = educationConfig.getConfig(RecordGenerationConstants.EDUCATIONSTRUCTCONFIG);
			
			educationConfig.getObject(RecordGenerationConstants.EDUCATIONSTRUCTCONFIG).keySet().forEach((k)->{
				temp.set(k, tableRowValueFormatter(String.valueOf(obj.get(eduParams.getString(k)))));
			});
			education[0] = temp;
			finalOutput.set(RecordGenerationConstants.EDUCATION, education);
			finalOutput.set(RecordGenerationConstants.PROVIDERID, String.valueOf(obj.get(RecordGenerationConstants.PROVIDERID)));
			
			c.output(finalOutput);
		}
	}
	
	public static class ExtractEntityFn extends DoFn<TableRow, TableRow>{
		
		private Config config;
		private String entityName;
		private String checkVal;
		private String checkCol;
		public ExtractEntityFn(Config config, String entityName, String checkVal, String checkCol) {
			this.config = config;
			this.entityName = entityName;
			this.checkVal = checkVal;
			this.checkCol = checkCol;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			List<String> attributes = config.getStringList(entityName);
			TableRow obj = c.element();
			TableRow output = new TableRow();
			
			if(checkVal.equals(RecordGenerationConstants.NOCHECK)) {
				attributes.stream().forEach((k)->{
					output.set(k, tableRowValueFormatter(String.valueOf(obj.get(k))));
				});
				c.output(output);
			}else {
				if (String.valueOf(obj.get(checkCol)).equals(checkVal)) {
					attributes.stream().forEach((k)->{
						output.set(k, tableRowValueFormatter(String.valueOf(obj.get(k))));
					});
					c.output(output);
				}
			}
			
		}
	}
	
	public static class ExtractAliasFn extends DoFn<TableRow, TableRow>{
		
		
		private Config aliasConfig;

		public ExtractAliasFn(Config aliasConfig) {
			this.aliasConfig = aliasConfig;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			
			TableRow output = new TableRow();
			TableRow[] aliasStruct = new TableRow[1];
			
			List<String> codeValues = aliasConfig.getStringList(RecordGenerationConstants.ALIASCODES);
			TableRow values = new TableRow();
			
			Config cnf = aliasConfig.getConfig(RecordGenerationConstants.ALIASSTRUCTPARAMS);
			if(codeValues.contains(String.valueOf(obj.get(aliasConfig.getString(RecordGenerationConstants.CHECKPARAMS))))) {
				aliasConfig.getObject(RecordGenerationConstants.ALIASSTRUCTPARAMS).keySet().forEach((k)->{
					String val = cnf.getString(k);
					if(val.equals(RecordGenerationConstants.NO_RECORD)) {
						values.set(k, "");
					}else {
						values.set(k, tableRowValueFormatter(String.valueOf(obj.get(val))));
					}
				});
			}
			
			aliasStruct[0] = values;
			output.set(RecordGenerationConstants.ALIAS, aliasStruct);
			output.set(RecordGenerationConstants.PROVIDERID, String.valueOf(obj.get(RecordGenerationConstants.PROVIDERID)));
			c.output(output);
			
		}
	}
	
	public static class DemoFn extends DoFn<TableRow, TableRow>{
		private Config config;
		//demographic config
		public DemoFn(Config config) {
			this.config = config;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			TableRow returnObj = new TableRow();

			TableRow crosswalk = new TableRow();
			Config crosswalkConfig = config.getConfig(RecordGenerationConstants.CROSSWALKS);
			String crosswalkKey = crosswalkConfig.getString(RecordGenerationConstants.KEY);
			
			Config sysConfig = config.getConfig(RecordGenerationConstants.SYSTEM_IDENTIFIER);
			TableRow systemIdentifier = new TableRow();
			systemIdentifier.set(RecordGenerationConstants.SYSTEM_IDENTIFIER_TYPE, sysConfig.getString(RecordGenerationConstants.KEY));
			systemIdentifier.set(RecordGenerationConstants.SYSTEM_IDENTIFIER_VALUE, tableRowValueFormatter(String.valueOf(obj.get(sysConfig.getString(RecordGenerationConstants.KEY)))));
			
			TableRow[] sysStruct = new TableRow[1];
			sysStruct[0] = systemIdentifier;
			returnObj.set(RecordGenerationConstants.SYSTEM_IDENTIFIER, sysStruct);
			
			List<String> attrList = (List<String>) config.getObject(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS).keySet().stream().collect(Collectors.toList());
			Config values = config.getConfig(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS);
			
			attrList.stream().forEach((attr)->{
				String recordName = values.getString(attr);
				if(recordName.equals(RecordGenerationConstants.NO_RECORD)) {
					returnObj.set(attr, "");
				}else {
					returnObj.set(attr, tableRowValueFormatter(String.valueOf(obj.get(recordName))));
				}
			});
			
			Config cred = config.getConfig(RecordGenerationConstants.CREDENTIAL);
			List<String> credList = cred.getStringList(RecordGenerationConstants.CREDENTIALCODE);
			TableRow[] credentialTr = new TableRow[credList.size()];
			for(int i=0;i<credList.size();i++) {
				TableRow credTemp = new TableRow();
				String val = String.valueOf(obj.get(credList.get(i)));
				credTemp.set(cred.getString(RecordGenerationConstants.CODEVALUE), tableRowValueFormatter(String.valueOf(obj.get(credList.get(i)))));
				if(val.equals(RecordGenerationConstants.NULL)) {
					credTemp.set(cred.getString(RecordGenerationConstants.RANK), "");
				}else {
					credTemp.set(cred.getString(RecordGenerationConstants.RANK), String.valueOf(i+1));
				}
				credentialTr[i] = credTemp;
			}
			returnObj.set(RecordGenerationConstants.CREDENTIAL, credentialTr);
			
			Config lang = config.getConfig(RecordGenerationConstants.LANGUAGESPOKEN);
			List<String> langList = lang.getStringList(RecordGenerationConstants.LANGUAGESPOKENCODE);
			TableRow[] langTr = new TableRow[langList.size()];
			for(int i=0;i<langList.size();i++) {
				TableRow credTemp = new TableRow();
				String val = String.valueOf(obj.get(langList.get(i)));
				credTemp.set(lang.getString(RecordGenerationConstants.CODEVALUE), tableRowValueFormatter(String.valueOf(obj.get(langList.get(i)))));
				if(val.equals(RecordGenerationConstants.NULL)) {
					
					credTemp.set(lang.getString(RecordGenerationConstants.RANK), "");
				}else {
					credTemp.set(lang.getString(RecordGenerationConstants.RANK), String.valueOf(i+1));
				}
				langTr[i] = credTemp;
			}
			returnObj.set(RecordGenerationConstants.LANGUAGESPOKEN, langTr);
			
			List<String> phoneList = config.getObject(RecordGenerationConstants.PHONE).keySet().stream().collect(Collectors.toList());
			Config phoneConfig = config.getConfig(RecordGenerationConstants.PHONE);
			TableRow[] phone = new TableRow[phoneList.size()];
			
			for(int n=0;n<phoneList.size();n++) {
				
				TableRow tempPhoneTr = new TableRow();
				Config cnf = phoneConfig.getConfig(phoneList.get(n));
				List<String> phoneVals = phoneConfig.getObject(phoneList.get(n)).keySet().stream().collect(Collectors.toList());
				phoneVals.remove(RecordGenerationConstants.PHONETYPE);
				tempPhoneTr.set(RecordGenerationConstants.PHONETYPE, cnf.getString(RecordGenerationConstants.PHONETYPE));
				for(int i=0;i<phoneVals.size();i++){
					String value = cnf.getString(phoneVals.get(i));
					if(value.equals(RecordGenerationConstants.NO_RECORD)) {
						tempPhoneTr.set(phoneVals.get(i), "");
					}else {
						String val = String.valueOf(obj.get(cnf.getString(phoneVals.get(i))));
						tempPhoneTr.set(phoneVals.get(i), tableRowValueFormatter(val));
					}
					phone[n] = tempPhoneTr;
				}
				
			}
			returnObj.set(RecordGenerationConstants.PHONE, phone);
			
			crosswalk.set(RecordGenerationConstants.TYPE, RecordGenerationConstants.MDSTAFF_URI);
			crosswalk.set(RecordGenerationConstants.VALUE, String.valueOf(obj.get(crosswalkKey)));
			
			returnObj.set(RecordGenerationConstants.CROSSWALKS, crosswalk);
			
			c.output(returnObj);
		}
	}
	
	
	
	public static String tableRowValueFormatter(String input) {
		return input.equals(RecordGenerationConstants.NULL) ? "" : input;
	}
	
	public static class CredentialSpecificJoin extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{

		
		private PCollection<TableRow> joinInput;
		private String val;
		private Config credConfig;

		public CredentialSpecificJoin(PCollection<TableRow> joinInput, String val, Config credConfig) {
			this.joinInput = joinInput;
			this.val = val;
			this.credConfig = credConfig;
		}
		
		@Override
		public PCollection<TableRow> expand(PCollection<TableRow> input) {
			PCollection<TableRow> output = null;
			
			PCollection<TableRow> joinedValue = input.apply(new PerformJoin(joinInput, credConfig.getString(RecordGenerationConstants.JOINKEY), RecordGenerationConstants.LEFTOUTERJOIN));
			output = joinedValue.apply(ParDo.of(new CreateCredManagedIdentifierFn(val, credConfig)));
			return output;
		}
		
	}
	
	public static class CreateCredManagedIdentifierFn extends DoFn<TableRow, TableRow>{
		private String val;
		private Config credConfig;

		public CreateCredManagedIdentifierFn(String val, Config credConfig) {
			this.val = val;
			this.credConfig = credConfig;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			TableRow returnObj = new TableRow();
			
			if(val.equals(RecordGenerationConstants.SPLCODE)) {
				obj.set(RecordGenerationConstants.MANAGED_IDENTIFIER_TYPE+val, RecordGenerationConstants.SPLNAME);
			}else if(val.equals(RecordGenerationConstants.DEACODE)) {
				obj.set(RecordGenerationConstants.MANAGED_IDENTIFIER_TYPE+val, RecordGenerationConstants.DEANAME);
			}else if(val.equals(RecordGenerationConstants.CDSCODE)) {
				obj.set(RecordGenerationConstants.MANAGED_IDENTIFIER_TYPE+val, RecordGenerationConstants.CDSNAME);
			}
			
			Config identifierConfig = credConfig.getConfig(RecordGenerationConstants.MANAGEDIDENTIFERCONF);
			
			Config managedIdentifierConfig = identifierConfig.getConfig(RecordGenerationConstants.MANAGEDIDENTIFIERVALUES);
			identifierConfig.getObject(RecordGenerationConstants.MANAGEDIDENTIFIERVALUES).keySet().forEach((k)->{
				obj.set(k+val, tableRowValueFormatter(String.valueOf(obj.get(managedIdentifierConfig.getString(k)))));
			});
			
			List<String> removalValues = identifierConfig.getStringList(RecordGenerationConstants.REMOVE);
			
			removalValues.stream().forEach((k)->{
				obj.remove(k);
			});
			c.output(obj);
		}
	}
	
	public static class AddManagedIdentifierFn extends DoFn<TableRow, TableRow>{
		
		private int index;
		private Config managedIdentifierConfig;
		
		public AddManagedIdentifierFn(int index, Config managedIdentifierConfig) {
			
			this.index = index;
			this.managedIdentifierConfig = managedIdentifierConfig;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			TableRow managedIdentifier[] = new TableRow[index];
			
			int i=0;
			
			List<String> creds = managedIdentifierConfig.getStringList(RecordGenerationConstants.CRED);
			List<String> vals = managedIdentifierConfig.getStringList(RecordGenerationConstants.CREDVALS);
			
			for(int j=0;j<creds.size();j++) {
				String code = creds.get(j);
				TableRow temp = new TableRow();
				vals.stream().forEach((k)->{
					temp.set(k, tableRowValueFormatter(String.valueOf(obj.get(k+code))));
					obj.remove(k+code);
				});
				managedIdentifier[i] = temp;
				++i;
			}
			
			List<String> simpleVals = managedIdentifierConfig.getStringList(RecordGenerationConstants.SIMPLEPARAMS);
			Config simpleConfig = managedIdentifierConfig.getConfig(RecordGenerationConstants.SIMPLEPARAMSCONFIG);
			List<String> emptyVals = managedIdentifierConfig.getStringList(RecordGenerationConstants.EMPTYVALS);
			
			for(int j=0;j<simpleVals.size();j++) {
				TableRow temp = new TableRow();
				temp.set(RecordGenerationConstants.MANAGED_IDENTIFIER_TYPE, simpleConfig.getString(simpleVals.get(j)));
				temp.set(RecordGenerationConstants.MANAGED_IDENTIFIER_VALUES, tableRowValueFormatter(String.valueOf(obj.get(simpleVals.get(j)))));
				emptyVals.stream().forEach((k)->{
					temp.set(k, "");
				});
				obj.remove(simpleVals.get(j));
				managedIdentifier[i] = temp;
				++i;
			}
			
			
			obj.set(RecordGenerationConstants.MANAGED_IDENTIFIER, managedIdentifier);
			c.output(obj);
		}
	}
	
	public static class CreateBoardStructFn extends DoFn<TableRow, TableRow>{
		
		private Config boardConfig;

		public CreateBoardStructFn(Config boardConfig) {
			this.boardConfig = boardConfig;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			Config ifNull = boardConfig.getConfig(RecordGenerationConstants.IFNULLPARAMS);
			
			TableRow returnObj = new TableRow();
			TableRow[] education =  new TableRow[1];
			TableRow temp = new TableRow();
			if(String.valueOf(ifNull.getString(RecordGenerationConstants.CHECKEXPR)).equals(RecordGenerationConstants.NULL)) {
				temp.set(ifNull.getString(RecordGenerationConstants.COLNAME), tableRowValueFormatter(String.valueOf(obj.get(ifNull.getString(RecordGenerationConstants.BACKUPVAL)))));
			}else {
				temp.set(ifNull.getString(RecordGenerationConstants.COLNAME), tableRowValueFormatter(String.valueOf(obj.get(ifNull.getString(RecordGenerationConstants.CHECKEXPR)))));
			}
			
			Config params = boardConfig.getConfig(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS);
			
			boardConfig.getObject(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS).keySet().forEach((k)->{
				temp.set(k, tableRowValueFormatter(String.valueOf(obj.get(params.getString(k)))));
			});
			education[0] = temp;
			returnObj.set(RecordGenerationConstants.BOARDCERTIFICATION, education);
			returnObj.set(RecordGenerationConstants.PROVIDERID, tableRowValueFormatter(String.valueOf(obj.get(RecordGenerationConstants.PROVIDERID))));
			
			c.output(returnObj);
		}
	}
	
	
	
}
