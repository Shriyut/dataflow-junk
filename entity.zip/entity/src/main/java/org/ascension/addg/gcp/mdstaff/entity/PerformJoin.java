package org.ascension.addg.gcp.mdstaff.entity;

import java.util.Iterator;

import com.google.api.services.bigquery.model.TableRow;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.join.CoGbkResult;
import org.apache.beam.sdk.transforms.join.CoGroupByKey;
import org.apache.beam.sdk.transforms.join.KeyedPCollectionTuple;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PerformJoin extends PTransform<PCollection<TableRow>, PCollection<TableRow>> {
    public transient PCollection<TableRow> rightData;
    private transient String joinKey;
	private String joinType;

    public PerformJoin(PCollection<TableRow> rightData, String joinKey, String joinType) {
        this.rightData = rightData;
        this.joinKey = joinKey;
        this.joinType = joinType;
    }

    private static final Logger LOG = LoggerFactory.getLogger(PerformJoin.class);

    @Override
    public PCollection<TableRow> expand(PCollection<TableRow> leftData) {
        PCollection<TableRow> joinOutput = null;
        try {

            PCollection<KV<String, TableRow>> leftDataKeyed = leftData.apply(MapElements.via(new ConvertToKV(joinKey)));

            PCollection<KV<String, TableRow>> rightDataKeyed = rightData
                    .apply(MapElements.via(new ConvertToKV(joinKey)));

            final TupleTag<TableRow> t1 = new TupleTag<>();
            final TupleTag<TableRow> t2 = new TupleTag<>();
            PCollection<KV<String, CoGbkResult>> coGbkResultCollection = KeyedPCollectionTuple.of(t1, leftDataKeyed)
                    .and(t2, rightDataKeyed).apply(CoGroupByKey.<String>create());
            joinOutput = coGbkResultCollection.apply(ParDo.of(new DoFn<KV<String, CoGbkResult>, TableRow>() {
                @ProcessElement
                public void processElement(ProcessContext c) {
                    KV<String, CoGbkResult> e = c.element();
                    Iterable<TableRow> pt1Vals = e.getValue().getAll(t1);
                    Iterable<TableRow> pt2Vals = e.getValue().getAll(t2);
					
                    // Iterator<TableRow> a;
                    TableRow rightValue;
                    Iterator<TableRow> cd;
                    if(joinType.equals("LeftOuterJoin")) {
                    if (pt1Vals.iterator().hasNext() && pt2Vals.iterator().hasNext()) {
                        cd = pt1Vals.iterator();

                        while (cd.hasNext()) {
                            rightValue = cd.next();
                            Iterator<TableRow> b = pt2Vals.iterator();

                            while (b.hasNext()) {
                                TableRow leftValue = b.next();
                                leftValue.putAll(rightValue);
                                c.output(leftValue);
                            }
                        }

                    }else if (pt1Vals.iterator().hasNext() && !pt2Vals.iterator().hasNext()) { 
						  cd = pt1Vals.iterator(); 
						  while (cd.hasNext()){ 
						  rightValue = cd.next();
						  c.output(rightValue); 
					  } 
				  }
					 

                }else if(joinType.equals("InnerJoin")) {
                	if (pt1Vals.iterator().hasNext() && pt2Vals.iterator().hasNext()) {
                        cd = pt1Vals.iterator();

                        while (cd.hasNext()) {
                            rightValue = cd.next();
                            Iterator<TableRow> b = pt2Vals.iterator();

                            while (b.hasNext()) {
                                TableRow leftValue = b.next();
                                
                                leftValue.putAll(rightValue);
                                c.output(leftValue);
                            }
                        }

                    }
                }else if(joinType.equals("FullOuterJoin")) {
                	if (pt1Vals.iterator().hasNext() && pt2Vals.iterator().hasNext()) {
                        cd = pt1Vals.iterator();

                        while (cd.hasNext()) {
                            rightValue = cd.next();
                            Iterator<TableRow> b = pt2Vals.iterator();

                            while (b.hasNext()) {
                                TableRow leftValue = b.next();
                                leftValue.putAll(rightValue);
                                c.output(leftValue);
                            }
                        }

                    }else if (pt1Vals.iterator().hasNext() && !pt2Vals.iterator().hasNext()) { 
						  cd = pt1Vals.iterator(); 
						  while (cd.hasNext()){ 
						  rightValue = cd.next();
						  c.output(rightValue); 
					  } 
				  }else if(!pt1Vals.iterator().hasNext() && pt2Vals.iterator().hasNext()) {
					  	  cd = pt2Vals.iterator();
					  	  while(cd.hasNext()) {
					  		  rightValue = cd.next();
					  		  c.output(rightValue);
					  	  }
				  }
                }
                }}));
        } catch (Exception e) {
            LOG.error("Exception caught while joining data", e.getMessage());
            throw new RuntimeException(e);
        }
        return joinOutput;
    }

}
