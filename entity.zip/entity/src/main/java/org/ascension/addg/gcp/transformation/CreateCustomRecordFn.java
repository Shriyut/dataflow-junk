package org.ascension.addg.gcp.transformation;

import org.apache.beam.sdk.transforms.DoFn;

import com.google.api.services.bigquery.model.TableRow;

public class CreateCustomRecordFn extends DoFn<TableRow, TableRow>{

	@ProcessElement
	public void ProcessElement(ProcessContext c) {
		TableRow obj = c.element().clone();
		
		ConvertBQRecord c1 = new ConvertBQRecord();
		
	}
}
