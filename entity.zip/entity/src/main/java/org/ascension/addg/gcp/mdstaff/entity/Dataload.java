package org.ascension.addg.gcp.mdstaff.entity;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.values.PCollection;

import com.google.api.services.bigquery.model.TableRow;

public class Dataload {

	public static void main(String[] args) {
	
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		
		PCollection<TableRow> data = pipeline
                .apply("read bq", BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.appointment_land").usingStandardSql());
		
		
	}
	
}
