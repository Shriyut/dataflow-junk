package org.ascension.addg.gcp.mdstaff.entity;

import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;

public class GenerateEntityRecord extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{
	
	private String entityName;
	private PCollection<TableRow> address;
	private PCollection<TableRow> site;
	private Config config;
	private PCollection<TableRow> facility;
	private Config clinicalExpertiseConfig;
	private PCollection<TableRow> clinical;
	private PCollection<TableRow> credential;
	private PCollection<TableRow> reference;
	private PCollection<TableRow> refSource;
	private PCollection<TableRow> alias;
	private PCollection<TableRow> board;

	//Constructor for location records
	public GenerateEntityRecord(PCollection<TableRow> site, String entityName, Config config) {
		this.entityName = entityName;
		this.site = site;
		this.config = config;
	}
	
	//Constructor for Organization Records
	public GenerateEntityRecord(PCollection<TableRow> facility, PCollection<TableRow> site, String entityName, Config config) {
		this.facility = facility;
		this.entityName = entityName;
		this.site = site;
		this.config = config;
	}
	
	public GenerateEntityRecord(Config config, String entityName, PCollection<TableRow> clinical) {
		this.config = config;
		this.entityName = entityName;
		this.clinical = clinical;
	}
	
	public GenerateEntityRecord(Config config, String entityName) {
		this.config = config;
		this.entityName = entityName;
	}
	
	public GenerateEntityRecord(Config config, PCollection<TableRow> credential, PCollection<TableRow> reference,
			PCollection<TableRow> refSource, PCollection<TableRow> alias, PCollection<TableRow> board, String entityName) {
		this.config = config;
		this.credential = credential;
		this.reference = reference;
		this.refSource = refSource;
		this.alias = alias;
		this.board = board;
		this.entityName = entityName;
	}

	@Override
	public PCollection<TableRow> expand(PCollection<TableRow> input) {
		
		PCollection<TableRow> mergedData = null;
		
		if(entityName.equals(RecordGenerationConstants.LOCATION)) {
			Config addressConfig = config.getConfig(RecordGenerationConstants.ADDRESS_CONFIG);
			PCollection<TableRow> addressTransformed = input.apply("Create address record", new TransformLocationRecords(addressConfig));
			Config siteConfig = config.getConfig(RecordGenerationConstants.SITE_CONFIG);
			PCollection<TableRow> siteTransformed = site.apply("Create site record", new TransformLocationRecords(siteConfig));
			
			mergedData = PCollectionList.of(addressTransformed).and(siteTransformed)
	                .apply(Flatten.<TableRow>pCollections());
			//PCollection<TableRow> distinct = mergedData.apply(Distinct.<TableRow>create());
			
		}else if(entityName.equals(RecordGenerationConstants.HCO)) {
			Config entityConfig = config.getConfig(RecordGenerationConstants.ENTITY_CONFIG);
			Config facilityConfig = config.getConfig(RecordGenerationConstants.FACILITY_CONFIG);
			Config siteConfig = config.getConfig(RecordGenerationConstants.SITE_CONFIG);
			
			PCollection<TableRow> entityTransformed = input.apply("Create entity records", new TransformOrganizationRecord(entityConfig));
			PCollection<TableRow> siteTransformed = site.apply("Create site entity", new TransformOrganizationRecord(siteConfig));
			PCollection<TableRow> facilityTransformed = facility.apply("Create facility record", new TransformOrganizationRecord(facilityConfig));
			
			mergedData = PCollectionList.of(facilityTransformed).and(entityTransformed).and(siteTransformed)
	                .apply(Flatten.<TableRow>pCollections());
			
			
		}else if(entityName.equals(RecordGenerationConstants.CLINICAL_EXPERTISE) || entityName.equals(RecordGenerationConstants.SPECIALTY)) {
			mergedData = input.apply(new TransformEntityCodeRecord(config));
		}else if(entityName.equals(RecordGenerationConstants.MINISTRY)) {
			mergedData = input.apply("Create Ministry record", new TransformMinistryRecord(config));
		}else if(entityName.equals("IND")) {
			//demographic pcollection will be input
			mergedData = input.apply("Create individual record", new TransformIndRecord(config, credential, reference, 
					refSource, alias, board));
		}
		return mergedData;
	}
	
	

}