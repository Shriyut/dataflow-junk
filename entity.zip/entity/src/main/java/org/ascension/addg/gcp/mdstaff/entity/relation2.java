package org.ascension.addg.gcp.mdstaff.entity;

public class relation2 {

}
