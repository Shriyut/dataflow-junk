package org.ascension.addg.gcp.mdstaff.entity;

import java.util.List;

import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TypeDescriptor;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;

public class TransformMinistryRecord extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{

	private Config config;
	public TransformMinistryRecord(Config config) {
		this.config = config;
	}
	@Override
	public PCollection<TableRow> expand(PCollection<TableRow> input) {
		
		List<String> columns = config.getStringList(RecordGenerationConstants.CODE_VALUE_COLUMNS);
		String entityName = config.getString(RecordGenerationConstants.ENTITY_NAME);
		
		PCollection<TableRow> ministry = input.apply("Extract ministry records", ParDo.of(new ExtractEntityCodeValuesFn(columns.get(0), entityName)));
		
		PCollection<TableRow> distinctValues = ministry
				.apply(Distinct.withRepresentativeValueFn((TableRow tr) -> (String) tr.get(entityName))
						.withRepresentativeType(TypeDescriptor.of(String.class)));
		
		PCollection<TableRow> transformedRecord = distinctValues.apply(ParDo.of(new DoFn<TableRow, TableRow>(){
			@ProcessElement
			public void ProcessElement(ProcessContext ctx) {
				TableRow inputObj = ctx.element().clone();
				TableRow returnObj = new TableRow();
				TableRow crosswalk = new TableRow();
				
				Config crosswalkConfig = config.getConfig(RecordGenerationConstants.CROSSWALKS);
				String crosswalkKey = crosswalkConfig.getString(RecordGenerationConstants.KEY);
				
				crosswalk.set(RecordGenerationConstants.TYPE, RecordGenerationConstants.MDSTAFF_URI);
				crosswalk.set(RecordGenerationConstants.VALUE, String.valueOf(inputObj.get(crosswalkKey)));
				
				returnObj.set(entityName, String.valueOf(inputObj.get(entityName)));
				returnObj.set(RecordGenerationConstants.CROSSWALKS, crosswalk);
				
				ctx.output(returnObj);
				}
		}));
		return transformedRecord;
	}
	
}
