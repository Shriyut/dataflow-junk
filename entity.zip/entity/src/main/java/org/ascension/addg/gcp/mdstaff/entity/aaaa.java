package org.ascension.addg.gcp.mdstaff;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.windowing.GlobalWindow;
import org.apache.beam.sdk.values.PCollection;

import org.joda.time.Instant;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class aaaa {

	public static void main(String[] args) {
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		String q = "{\r\n"
				+ "\"query\": \"\"\"SELECT\r\n"
				+ "type,\r\n"
				+ "STRUCT([STRUCT ( crosswalks_type AS type,\r\n"
				+ "crosswalks_value AS value )] AS crosswalks) AS startObject,\r\n"
				+ "STRUCT([STRUCT ( crosswalks_type AS type,\r\n"
				+ "crosswalks_value AS value )] AS crosswalks) AS endObject,\r\n"
				+ "[STRUCT ( crosswalks_type AS type,\r\n"
				+ "crosswalks_value AS value )] AS crosswalks,\r\n"
				+ "STRUCT([STRUCT ( status AS value)] AS Status,\r\n"
				+ "[STRUCT ( begin_date AS value)] AS BeginDate,\r\n"
				+ "[STRUCT ( end_date AS value)] AS EndDate,\r\n"
				+ "[STRUCT ( medical_staff_status AS value)] AS MedicalStaffCategory,\r\n"
				+ "[STRUCT ( on_staff_flag AS value)] AS OnStaffFlag,\r\n"
				+ "[STRUCT ( Archived_Flag AS value)] AS ArchivedFlag,\r\n"
				+ "[STRUCT ( Exclude_Directory_Flag AS value)] AS ExcludeDirectoryFlag,\r\n"
				+ "[STRUCT ( Organizational_Relationship AS value)] AS OrganizationalRelationship,\r\n"
				+ "[STRUCT ( Employee_Class AS value)] AS EmployeeClass,\r\n"
				+ "[STRUCT ( Employee_Class AS value)] AS EmployeeClassDescription,\r\n"
				+ "[STRUCT ( Employment_Status AS value)] AS EmploymentStatus,\r\n"
				+ "[STRUCT ( Job_Code AS value)] AS JobCode,\r\n"
				+ "[STRUCT ( Job_Description AS value)] AS JobDescription,\r\n"
				+ "[STRUCT ( Job_Entry_Date AS value)] AS JobEntryDate,\r\n"
				+ "[STRUCT ( Job_Description AS value)] AS JobIndicator,\r\n"
				+ "[STRUCT ( Position_Number AS value)] AS PositionNumber,\r\n"
				+ "[STRUCT ( Position_Description AS value)] AS PositionDescription,\r\n"
				+ "[STRUCT ( Position_Entry_Date AS value)] AS PositionEntryDate,\r\n"
				+ "[STRUCT ( Business_Unit AS value)] AS BusinessUnit,\r\n"
				+ "[STRUCT ( Business_Unit_Description AS value)] AS BusinessUnitDescription,\r\n"
				+ "[STRUCT ( Department_Identifier AS value)] AS DepartmentIdentifier,\r\n"
				+ "[STRUCT ( Department_Description AS value)] AS DepartmentDescription,\r\n"
				+ "[STRUCT ( Department_Entry_Date AS value)] AS DepartmentEntryDate,\r\n"
				+ "[STRUCT ( Hire_Date AS value)] AS HireDate,\r\n"
				+ "[STRUCT ( Last_Hire_Date AS value)] AS LastHireDate,\r\n"
				+ "[STRUCT ( Termination_Date AS value)] AS TerminationDate,\r\n"
				+ "[STRUCT ( Contract_Identifier AS value)] AS ContractIdentifier,\r\n"
				+ "[STRUCT ( Contract_Group AS value)] AS ContractGroup,\r\n"
				+ "[STRUCT ( Contract_Type AS value)] AS ContractType,\r\n"
				+ "[STRUCT ( Contract_Status AS value)] AS ContractStatus,\r\n"
				+ "[STRUCT ( Network_Order AS value)] AS NetworkOrder,\r\n"
				+ "[STRUCT ( Network_Name AS value)] AS NetworkName,\r\n"
				+ "[STRUCT(STRUCT([STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.address_type\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types ) AS value)] AS AddressType,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.Publish_To_External_Directory_Flag\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types) AS value)] AS PublishToExternalDirectoryFlag,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.Publish_To_External_Directory_Primary_Flag\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types) AS value)] AS PublishToExternalDirectoryPrimaryFlag,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.Practice_Rank\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types) AS value)] AS PracticeRank,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.address_type address_types\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types) AS value)] AS Status,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.address_type address_types\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types) AS value)] AS BeginDate,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "address_types.address_type address_types\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Address_Types) address_types) AS value)] AS EndDate) AS value)] AS AddressTypes,\r\n"
				+ "[STRUCT(STRUCT([STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "Phone.phone_type\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Phone) Phone ) AS value)] AS PhoneType,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "Phone.phone_Number\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Phone) Phone) AS value)] AS Number,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "Phone.phone_Extension\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Phone) Phone) AS value)] AS Extension,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "Phone.phone_Rank\r\n"
				+ "FROM\r\n"
				+ "UNNEST(Phone) Phone) AS value)] AS Rank) AS value)] AS Phone,\r\n"
				+ "[STRUCT ( \"Not Avaliable\" AS value)] AS LocationOfCare,\r\n"
				+ "[STRUCT ( SystemIdentifier_Type AS value)] AS SystemIdentifierType,\r\n"
				+ "[STRUCT ( SystemIdentifier_Value AS value)] AS SystemIdentifierValue,\r\n"
				+ "[STRUCT ( \"Not Avaliable\" AS value)] AS SpecialtyRank,\r\n"
				+ "[STRUCT ( \"Not Avaliable\" AS value)] AS ClinicalExpertiseRank) AS attributes\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.relation_sort_final` LIMIT 1\"\"\"\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "}";
		
		Config conf = ConfigFactory.parseString(q).resolve();
		PCollection<TableRow> in = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery(conf.getString("query")).usingStandardSql());
		PCollection<PubsubMessage> msg = in.apply(ParDo.of(new ConvertFn()));
		msg.apply(PubsubIO.writeMessages().to("projects/asc-ahnat-apdh-sbx/topics/APDH_CANONICAL")); 
		pipeline.run().waitUntilFinish();
	}
	
	public static class PrintValueFn extends DoFn<TableRow, TableRow>{
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			System.out.println(String.valueOf(c.element()));
		}
	}
	
	public static class ConvertFn extends DoFn<TableRow, PubsubMessage>{
		
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			
			
			JSONArray emptyArr = new JSONArray();
			JSONObject emptyObj = new JSONObject();
			emptyObj.put("value", "");
			
			emptyArr.put(emptyObj);
			
			TableRow obj = c.element().clone();
			JSONObject finalObj = new  JSONObject();
			JSONArray finalarr = new JSONArray();
			
			obj.keySet().forEach((k)->{
				
				//System.out.println("key "+k+" value "+obj.get(k)+" classname "+obj.get(k).getClass());
				if(k.equals("attributes")) {
					TableRow in = (TableRow) obj.get(k);
					JSONObject attrObj = new JSONObject();
					
					in.keySet().forEach((key)->{
						//array list -> normal values, tablerow -> systemidentifier
						System.out.println("attributes key"+key+" value "+in.get(key)+" classname "+in.get(key).getClass());
						Object o = in.get(key);
						if(o instanceof ArrayList) {
							ArrayList l = (ArrayList) o;
							System.out.println("arraylistinfo "+String.valueOf(o)+" classname"+l.get(0).getClass());
							TableRow trVal = (TableRow) l.get(0);
							if(String.valueOf(trVal).equals("GenericData{classInfo=[f], {}}")) {
								
								attrObj.put(key, emptyArr);
							}else if(key.equals("SystemIdentifier")) {
								JSONArray sysarr = new JSONArray();
								System.out.println("suysident"+String.valueOf(o));
								ArrayList al = (ArrayList) o;
								
								JSONObject sysobj = new JSONObject(); //parent
								
								
								for(int h =0;h<al.size();h++){
									System.out.println("Stream "+String.valueOf(h)+" "+al.get(h).getClass());
									TableRow tr = (TableRow) al.get(h);
									tr.keySet().forEach((g)->{
										// g is value
										System.out.println("second "+g+String.valueOf(tr.get(g))+" "+tr.get(g).getClass());
										TableRow m = (TableRow) tr.get(g);
										JSONObject childsysobj = new JSONObject();
										m.keySet().forEach((v)->{
											ArrayList ins = (ArrayList) m.get(v);
											System.out.println("insrt "+ins);
											TableRow hjk = (TableRow) ins.get(0);
											System.out.println("hjklop "+hjk);
											String val = String.valueOf(hjk.get("value"));
											System.out.println("valuein "+val+" keysst "+v);
											childsysobj.put(v, createFromString(val));
											System.out.println("childsysobj2 "+childsysobj);
										});
										sysobj.accumulate("value", childsysobj);
										System.out.println("sysobj "+sysobj);
										
									});
								}
								
								if(sysobj.get("value") instanceof JSONArray) {
									JSONArray newarr = sysobj.getJSONArray("value");
									System.out.println("sysobj"+sysobj.get("value").getClass());
									
									for(int l1=0;l1<newarr.length();l1++) {
										JSONObject temp = new JSONObject();
										System.out.println("newaarr "+newarr.getJSONObject(l1));
										temp.put("value", newarr.getJSONObject(l1));
										sysarr.put(temp);
										
									}
									}else {
										
										JSONObject temp = new JSONObject();
										temp.put("value", sysobj.getJSONObject("value"));
										sysarr.put(temp);
									}
								
								System.out.println("sysarr "+sysarr);
								attrObj.put(key, sysarr);
							}else if(key.equals("Phone") || key.equals("AddressTypes")) {
								ArrayList kmn = (ArrayList) o;
								TableRow rtz = (TableRow) kmn.get(0);
								JSONObject amn = new JSONObject();
								JSONObject parentObj = new JSONObject();
								
								JSONArray arr = new JSONArray();
								TableRow trrr = (TableRow) rtz.get("value");
								trrr.keySet().forEach((n)->{
									System.out.println(n+" "+"trrr "+String.valueOf(trrr.get(n))+" classname "+trrr.get(n).getClass());
									ArrayList al = (ArrayList) trrr.get(n);
									TableRow g = new TableRow();
									System.out.println("gggg "+g);
									String val = String.valueOf(g.get("value"));
									JSONArray tmparr = new JSONArray();
									JSONObject obj1 = new JSONObject();
									if(val.equals("null")) {
										obj1.put("value", "");
									}else {
										obj1.put("value", val);
									}
									
									tmparr.put(obj1);
									amn.put(n, tmparr);
								});
								parentObj.put("value", amn);
								arr.put(parentObj);
								attrObj.put(key, arr);
							}else {
							//System.out.println("Arraylistinfo "+key+"val "+String.valueOf(trVal));
								attrObj.put(key, createJSONArray(trVal));
							}
						}else if(o instanceof TableRow) {
							TableRow tr = (TableRow) o;
							//System.out.println("tablerowval"+tr);
							JSONObject tempObj = new JSONObject();
							JSONObject valueObject = new JSONObject();
							tr.keySet().forEach((l)->{
								System.out.println("tablerowval "+String.valueOf(l)+tr.get(l)+" classname "+tr.get(l).getClass());
								ArrayList x = (ArrayList) tr.get(l);
								tempObj.put(l, createJSONArray((TableRow)x.get(0)));
							});
							valueObject.put("value", tempObj);
							attrObj.put(key, valueObject);
						}
					});
					finalObj.put("attributes", attrObj);
				}else if(k.equals("startObject")|| k.equals("endObject")) {
					System.out.println(k+" strt "+obj.get(k).getClass()+" "+String.valueOf(obj.get(k)));
					TableRow tr = (TableRow) obj.get(k);
					JSONObject output = new JSONObject();
					JSONObject val = new JSONObject();
					JSONArray arr = new JSONArray();
					tr.keySet().forEach((kt)->{
						
						if(String.valueOf(kt).equals("crosswalks")) {
							ArrayList al = (ArrayList) tr.get(kt);
							TableRow inside = (TableRow) al.get(0);
							inside.keySet().forEach((io)->{
								val.put(String.valueOf(io), String.valueOf(inside.get(io)));
							});
						}
						arr.put(val);
						output.put("crosswalks", arr);
						
					});
					finalObj.put(k, output);
				}else if(k.equals("crosswalks")) {
					System.out.println("Crosswalks"+obj.get(k).getClass());
					
					ArrayList ca = (ArrayList) obj.get(k);
					System.out.println("arraylistcrswlk "+String.valueOf(obj.get(k))+" classtype "+obj.get(k).getClass());
					/*
					JSONObject ctr = new JSONObject();
					finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
					*/
					finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
				}else {
					finalObj.put(k, String.valueOf(obj.get(k)));
				}
			});
			System.out.println("finalobject "+finalObj);
			
			//finalarray.put(finalObj);
			finalarr.put(finalObj);
			HashMap<String, String> mapData = new HashMap<String, String>();
			byte[] data = String.valueOf(finalarr).getBytes();
			PubsubMessage msg = new PubsubMessage(data, mapData);
			c.output(msg);
	}
		
		
	}
	
	public static JSONArray createJSONArray(TableRow tr) {
		JSONObject temp = new JSONObject();
		
		tr.keySet().forEach((key)->{
			if(tr.get(key) instanceof String) {
				temp.put(key, String.valueOf(tr.get(key)));
			}else if(tr.get(key) instanceof ArrayList) {
				ArrayList j = (ArrayList) tr.get(key);
				temp.put(key, String.valueOf(j.get(0)));
			}
		});
		
		JSONArray returnArray = new JSONArray();
		returnArray.put(temp);
		
		return returnArray;
	}
	
	public static JSONArray createFromString(String input) {
		
		
		JSONObject value = new JSONObject();
		JSONArray arr = new JSONArray();
		value.put("value", input);
		
		arr.put(value);
		return arr;
	}

}
