package org.ascension.addg.gcp.mdstaff;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.beam.repackaged.core.org.apache.commons.lang3.StringUtils;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.windowing.GlobalWindow;
import org.apache.beam.sdk.values.PCollection;

import org.joda.time.Instant;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class a {

	public static void main(String[] args) {
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		String q = "{\r\n"
				+ "\"query\": \"\"\"SELECT\r\n"
				+ "'configuration/entityTypes/HCO' AS type,\r\n"
				+ "recorded_indicator AS record_indicator,\r\n"
				+ "meta_src_system_name AS meta_src_system_name,\r\n"
				+ "'MD Staff' AS SourceSystemName,\r\n"
				+ "STRUCT([STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "demographic.organization_type_code\r\n"
				+ "FROM\r\n"
				+ "UNNEST(DEMOGRAPHIC) DEMOGRAPHIC) AS value)] AS CostCenterCode,\r\n"
				+ "[STRUCT(STRUCT([STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "costcenter.costcentercode\r\n"
				+ "FROM\r\n"
				+ "UNNEST(COSTCENTER) COSTCENTER) AS value)] AS PostalCode,\r\n"
				+ "[STRUCT( (\r\n"
				+ "SELECT\r\n"
				+ "costcenter.business_unit\r\n"
				+ "FROM\r\n"
				+ "UNNEST(COSTCENTER) COSTCENTER) AS value)] AS BusinessUnit,\r\n"
				+ "[STRUCT( (\r\n"
				+ "SELECT\r\n"
				+ "costcenter.department_identifier\r\n"
				+ "FROM\r\n"
				+ "UNNEST(COSTCENTER) COSTCENTER) AS value)] AS DepartmentIdentifier) AS value)] AS CostCenter,\r\n"
				+ "[STRUCT(STRUCT(ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.managedidentifier_type AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS ManagedIdentifierType,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.managedidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS ManagedIdentifierValue,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.issuing_authority AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS IssuingAuthority,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.state AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS State,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.Initial_Issue_Date AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS InitialIssueDate,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.effective_date AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS EffectiveDate,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.renewal_date AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS RenewalDate,\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.expiration_date AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(managedidentifier) AS x) AS ExpirationDate) AS value) ] AS ManagedIdentifier,\r\n"
				+ "[STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='SiteID'))<>0 THEN ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='SiteID')\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT \"\" AS value)\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='SiteID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='SiteID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value),\r\n"
				+ "STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='EntityID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_TYPE AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='EntityID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='EntityID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='EntityID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value),\r\n"
				+ "STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='FacilityID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_TYPE AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='FacilityID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='FacilityID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='FacilityID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value),\r\n"
				+ "STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ParentID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_TYPE AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='ParentID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ParentID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='ParentID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value),\r\n"
				+ "STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ParentEntityID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_TYPE AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='ParentEntityID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ParentEntityID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='ParentEntityID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value)] AS SystemIdentifier,\r\n"
				+ "[STRUCT( status AS value)] AS Status,\r\n"
				+ "[STRUCT( entity_in_use_flag AS value)] AS EntityInUseFlag,\r\n"
				+ "[STRUCT( site_in_use_flag AS value)] AS SiteInUseFlag,\r\n"
				+ "[STRUCT( facility_archived_flag AS value)] AS FacilityArchivedFlag,\r\n"
				+ "[STRUCT(STRUCT([STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "organization_name.organization_name_type\r\n"
				+ "FROM\r\n"
				+ "UNNEST(organization_name) organization_name) AS value)] AS OrganizationNameType,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "organization_name.organization_name\r\n"
				+ "FROM\r\n"
				+ "UNNEST(organization_name) organization_name) AS value)] AS OrganizationName) AS value)] AS OrganizationName,\r\n"
				+ "[STRUCT(STRUCT([STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "email.email_type\r\n"
				+ "FROM\r\n"
				+ "UNNEST(email) email ) AS value)] AS EmailType,\r\n"
				+ "[STRUCT((\r\n"
				+ "SELECT\r\n"
				+ "email.email\r\n"
				+ "FROM\r\n"
				+ "UNNEST(email) email) AS value)] AS Email) AS value)] AS Email,\r\n"
				+ "[STRUCT(patient_centered_medical_home_flag AS value)] AS PatientCenteredMedicalHomeFlag) AS attributes,\r\n"
				+ "crosswalks\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.provider_organization_hco_sort`\"\"\"\r\n"
				+ "\r\n"
				+ "}";
		
		Config conf = ConfigFactory.parseString(q).resolve();
		PCollection<TableRow> in = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery(conf.getString("query")).usingStandardSql());
		PCollection<PubsubMessage> msg = in.apply(ParDo.of(new ConvertFn()));
		//msg.apply(PubsubIO.writeMessages().to("projects/asc-ahnat-apdh-sbx/topics/APDH_CANONICAL")); 
		pipeline.run().waitUntilFinish();
	}
	
	public static class PrintValueFn extends DoFn<TableRow, TableRow>{
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			System.out.println(String.valueOf(c.element()));
		}
	}
	
	public static class ConvertFn extends DoFn<TableRow, PubsubMessage>{
		
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			
			
			JSONArray emptyArr = new JSONArray();
			JSONObject emptyObj = new JSONObject();
			emptyObj.put("value", "");
			
			emptyArr.put(emptyObj);
			
			TableRow obj = c.element().clone();
			JSONObject finalObj = new  JSONObject();
			JSONArray finalarr = new JSONArray();
			
			obj.keySet().forEach((k)->{
				
				//System.out.println("key "+k+" value "+obj.get(k)+" classname "+obj.get(k).getClass());
				if(k.equals("attributes")) {
					TableRow in = (TableRow) obj.get(k);
					JSONObject attrObj = new JSONObject();
					
					in.keySet().forEach((key)->{
						//array list -> normal values, tablerow -> systemidentifier
						System.out.println("attributes key"+key+" value "+in.get(key)+" classname "+in.get(key).getClass());
						Object o = in.get(key);
						if(o instanceof ArrayList) {
							ArrayList l = (ArrayList) o;
							System.out.println("arraylistinfo "+String.valueOf(o)+" classname"+l.get(0).getClass());
							TableRow trVal = (TableRow) l.get(0);
							if(String.valueOf(trVal).equals("GenericData{classInfo=[f], {}}")) {
								
								attrObj.put(key, emptyArr);
							}else if(key.equals("SystemIdentifier") || key.equals("ManagedIdentifier")) {
								JSONArray sysarr = new JSONArray();
								System.out.println("suysident"+String.valueOf(o));
								ArrayList al = (ArrayList) o;
								
								JSONObject sysobj = new JSONObject(); //parent
								
								
								for(int h =0;h<al.size();h++){
									System.out.println("Stream "+String.valueOf(h)+" "+al.get(h).getClass());
									TableRow tr = (TableRow) al.get(h);
									tr.keySet().forEach((g)->{
										// g is value
										System.out.println("second "+g+String.valueOf(tr.get(g))+" "+tr.get(g).getClass());
										TableRow m = (TableRow) tr.get(g);
										JSONObject childsysobj = new JSONObject();
										m.keySet().forEach((v)->{
											ArrayList ins = (ArrayList) m.get(v);
											System.out.println("insrt "+ins);
											TableRow hjk = (TableRow) ins.get(0);
											System.out.println("hjklop "+hjk);
											String val = String.valueOf(hjk.get("value"));
											System.out.println("valuein "+val+" keysst "+v);
											if(val.equals("null")) {
												JSONArray tmp = new JSONArray();
												JSONObject tmpobj = new JSONObject();
												String j = null;
												
												//tmpobj.put("value", null);
												System.out.println("tmpobj "+tmpobj);
												tmp.put(tmpobj);
												//tmpobj.set("f", "l");
												//childsysobj.put(v, tmp);
											}else {
												childsysobj.put(v, createFromString(val));
											}
											System.out.println("childsysobj2 "+childsysobj);
										});
										sysobj.accumulate("value", childsysobj);
										System.out.println("sysobj "+sysobj);
										
									});
								}
								
								//creates reltio format for accumulated value blocks for nested attribute
								if(sysobj.get("value") instanceof JSONArray) {
									JSONArray newarr = sysobj.getJSONArray("value");
									System.out.println("sysobj"+sysobj.get("value").getClass());
									
									for(int l1=0;l1<newarr.length();l1++) {
										JSONObject temp = new JSONObject();
										System.out.println("newaarr "+newarr.getJSONObject(l1));
										temp.put("value", newarr.getJSONObject(l1));
										sysarr.put(temp);
										
									}
									}else {
										
										JSONObject temp = new JSONObject();
										temp.put("value", sysobj.getJSONObject("value"));
										sysarr.put(temp);
									}
								/*
								trVal.keySet().forEach((b)->{
									System.out.println("insidetrkeyset "+ " key "+b+" "+String.valueOf(trVal.get(b))+" classname "+trVal.get(b).getClass());
									//tablerow -> key [list contains tablerow] [tr]
									
									//childsysobj.put(b, createJSONArray(trVal.get(b)));
									
									TableRow insideVal = (TableRow) trVal.get(b);
									List<String> keyNames = new ArrayList<>();
									insideVal.keySet().forEach((p)->{
										System.out.println("insidetrkeyset "+ " key "+p+" "+String.valueOf(insideVal.get(p))+" classname "+insideVal.get(p).getClass());
										ArrayList v = (ArrayList) insideVal.get(p);
										TableRow t = (TableRow) v.get(0);
										
										/*
										t.keySet().forEach((q)->{
											if(t.get(q) instanceof ArrayList) {
												System.out.println("arraylistinsidetablerow "+" key "+q+" "+t.get(q).getClass()+" value "+String.valueOf(t.get(q)));
											}else {
												childsysobj.put(p, createFromString((String) t.get(q)));
												System.out.println("childsysobj "+childsysobj);
												
											}
										});
										
									});
									
									//System.out.println("insidevalsize "+insideVal.size()); 2
									
								});
								*/
								//sysobj.put("value", childsysobj);
								//sysarr.put(sysobj);
								System.out.println("sysarr "+sysarr);
								attrObj.put(key, sysarr);
							}else if(key.equals("Zip") || key.equals("Email")
									|| key.equals("CostCenter") || key.equals("OrganizationName")) {
								ArrayList kmn = (ArrayList) o;
								TableRow rtz = (TableRow) kmn.get(0);
								JSONObject amn = new JSONObject();
								JSONObject parentObj = new JSONObject();
								
								JSONArray arr = new JSONArray();
								TableRow trrr = (TableRow) rtz.get("value");
								trrr.keySet().forEach((n)->{
									System.out.println(n+" "+"trrr "+String.valueOf(trrr.get(n))+" classname "+trrr.get(n).getClass());
									ArrayList al = (ArrayList) trrr.get(n);
									TableRow g = new TableRow();
									System.out.println("gggg "+g);
									String val = String.valueOf(g.get("value"));
									JSONArray tmparr = new JSONArray();
									JSONObject obj1 = new JSONObject();
									if(val.equals("null")) {
										obj1.put("value", "");
									}else {
										obj1.put("value", val);
									}
									
									tmparr.put(obj1);
									amn.put(n, tmparr);
								});
								parentObj.put("value", amn);
								arr.put(parentObj);
								attrObj.put(key, arr);
							}else {
							//System.out.println("Arraylistinfo "+key+"val "+String.valueOf(trVal));
								attrObj.put(key, createJSONArray(trVal));
							}
						}else if(o instanceof TableRow) {
							TableRow tr = (TableRow) o;
							//System.out.println("tablerowval"+tr);
							JSONObject tempObj = new JSONObject();
							JSONObject valueObject = new JSONObject();
							tr.keySet().forEach((l)->{
								System.out.println("tablerowval "+String.valueOf(l)+tr.get(l)+" classname "+tr.get(l).getClass());
								ArrayList x = (ArrayList) tr.get(l);
								tempObj.put(l, createJSONArray((TableRow)x.get(0)));
							});
							valueObject.put("value", tempObj);
							attrObj.put(key, valueObject);
						}
					});
					finalObj.put("attributes", attrObj);
				}else if(k.equals("crosswalks")) {
					System.out.println("Crosswalks"+obj.get(k).getClass());
					
					ArrayList ca = (ArrayList) obj.get(k);
					System.out.println("arraylistcrswlk "+String.valueOf(obj.get(k))+" classtype "+obj.get(k).getClass());
					/*
					JSONObject ctr = new JSONObject();
					finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
					*/
					//finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
					TableRow b = (TableRow) ca.get(0);
					JSONArray tmparr = new JSONArray();
					JSONObject objtr = new JSONObject();
					
					b.keySet().forEach((io)->{
						if(io.contains("type")) {
							objtr.put("type", String.valueOf(b.get(io)));
						}else if(io.contains("value")) {
							objtr.put("value", String.valueOf(b.get(io))+"|hco");
						}
					});
					tmparr.put(objtr);
					finalObj.put(k, tmparr);
				}else {
					finalObj.put(k, String.valueOf(obj.get(k)));
				}
			});
			System.out.println("finalobject "+finalObj);
			
			//finalarray.put(finalObj);
			finalarr.put(finalObj);
			HashMap<String, String> mapData = new HashMap<String, String>();
			byte[] data = String.valueOf(finalarr).getBytes();
			PubsubMessage msg = new PubsubMessage(data, mapData);
			c.output(msg);
	}
		
		
	}
	
	public static JSONArray createJSONArray(TableRow tr) {
		JSONObject temp = new JSONObject();
		
		tr.keySet().forEach((key)->{
			if(tr.get(key) instanceof String) {
				temp.put(key, String.valueOf(tr.get(key)));
			}else if(tr.get(key) instanceof ArrayList) {
				ArrayList j = (ArrayList) tr.get(key);
				temp.put(key, String.valueOf(j.get(0)));
			}
		});
		
		JSONArray returnArray = new JSONArray();
		returnArray.put(temp);
		
		return returnArray;
	}
	
	public static JSONArray createFromString(String input) {
		
		
		JSONObject value = new JSONObject();
		JSONArray arr = new JSONArray();
		value.put("value", input);
		
		arr.put(value);
		return arr;
	}

}
