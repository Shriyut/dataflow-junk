package org.ascension.addg.gcp.mdstaff.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.ascension.addg.gcp.mdstaff.entity.RecordGenerationConstants;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class IndTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation()
				.as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);

		PCollection<TableRow> alias = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.alias_land LIMIT 1000").usingStandardSql());
		
		List<String> aliasVal = new ArrayList<>();
		aliasVal.add("OTHER");
		aliasVal.add("PreviousName");
		PCollection<TableRow> alias_output = alias.apply(ParDo.of(new ExtractAliasFn(aliasVal)));
		
		PCollection<TableRow> reference = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.reference_land LIMIT 1000").usingStandardSql());
		
		PCollection<TableRow> referenceSource = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.referencesource_land LIMIT 1000"));
		
		String conf = "{\r\n"
				+ "\"reference\": [ \"ProviderID\", \"ReferenceID\", \"DegreeEarnedID_Code\", \"Subject\", \"InUse\", \"StartDate\", \"EndDate\", \"ReferenceSourceID\", \"LastUpdated\" ],\r\n"
				+ "\"referenceSource\": [ \"ReferenceSourceID\", \"Code\", \"Name\", \"ReferenceType\", \"Archived\", \"LastUpdated\" ],\r\n"
				+ "}";
		
		Config config = ConfigFactory.parseString(conf).resolve();
	 
		PCollection<TableRow> refPC = reference.apply(ParDo.of(new ExtractEntityFn(config, "reference")));
		PCollection<TableRow> refSourcePC = referenceSource.apply(ParDo.of(new ExtractEntityFn(config, "referenceSource")));
		
		PCollection<TableRow> refJoin = refPC.apply(new PerformJoin(refSourcePC, "ReferenceSourceID", "InnerJoin"));
		PCollection<TableRow> changedRef = refJoin.apply(ParDo.of(new ReferenceFormatFn()));
		
		PCollection<TableRow> credential = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.credential_land").usingStandardSql());

        PCollection<TableRow> spl = credential.apply(ParDo.of(new ExtractLicenseFn("StateProfLicense")));
        PCollection<TableRow> dea = credential.apply(ParDo.of(new ExtractLicenseFn("DEA")));
        PCollection<TableRow> cds = credential.apply(ParDo.of(new ExtractLicenseFn("CDSCSR")));
           
        String indConf = "{\r\n"
        		+ " \"indConfig\": {\r\n"
        		+ "	\"singleValueParameters\": {\r\n"
        		+ "		\"GivenName\": \"FirstName\",\r\n"
        		+ "		\"FamilyName\": \"LastName\",\r\n"
        		+ "		\"MiddleName\": \"MiddleName\",\r\n"
        		+ "		\"FullName\": \"NoRecord\",\r\n"
        		+ "		\"Status\": \"NoRecord\",\r\n"
        		+ "		\"DOB\": \"BirthDate\",\r\n"
        		+ "		\"AdministrativeGenderCode\": \"GenderID_Code\",\r\n"
        		+ "		\"SSN\": \"SSN\",\r\n"
        		+ "		\"NameSuffixCode\": \"SuffixID_Code\",\r\n"
        		+ "		\"FieldofLicensureCode\": \"FieldOfLicensureID_Code\",\r\n"
        		+ "		\"PreferredName\": \"PreferredName\",\r\n"
        		+ "		\"NamePrefixCode\": \"PrefixID_Code\",\r\n"
        		+ "		\"RaceCode\": \"RaceID_Code\",\r\n"
        		+ "		\"EthnicityCode\": \"EthnicityID_Code\",\r\n"
        		+ "		\"DomesticPartnerName\": \"SpouseName\",\r\n"
        		+ "		\"MaritalStatusCode\": \"MaritalStatusID_Code\",\r\n"
        		+ "		\"DeceasedFlag\": \"Deceased\",\r\n"
        		+ "		\"DeathDate\": \"DeceasedDate\",\r\n"
        		+ "		\"ProviderID\": \"ProviderID\",\r\n"
        		+ "		\"NPI\": \"NPI\",\r\n"
        		+ "		\"MedicareNumber\": \"MedicareNumber\",\r\n"
        		+ "		\"MedicaidNumber\": \"MedicaidNumber\",\r\n"
        		+ "		\"TaxID\": \"TaxID\",\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"general_parameters\": [ \"GivenName\", \"FamilyName\", \"MiddleName\", \"FullName\", \"DOB\", \"AdministrativeGenderCode\", \"SSN\", \"NameSuffixCode\", \r\n"
        		+ "							\"RaceCode\", \"EthnicityCode\", \"DomesticPartnerName\", \"MaritalStatusCode\", \"DeceasedFlag\", \"DeathDate\"],\r\n"
        		+ "	\r\n"
        		+ "	\"alias_demo_parameters\": {\r\n"
        		+ "		\"AliasNameTypeCode\": \"AliasTypeID_Code\",\r\n"
        		+ "		\"AliasGivenName\": \"GivenName\",\r\n"
        		+ "		\"AliasFamilyName\": \"FamilyName\",\r\n"
        		+ "		\"AliasMiddleName\": \"NoRecord\",\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"board_parameters\": {\r\n"
        		+ "		\"BoardCertificationCode\": \"SpecialtyBoardID_Code\",\r\n"
        		+ "		\"BoardCertificationStatusCode\": \"CertificationStatusID_Code\",\r\n"
        		+ "		\"BoardCertificationNumber\": \"CertificationNumber\",\r\n"
        		+ "		\"BoardCertificationLifetimeStatus\": \"Lifetime\",\r\n"
        		+ "		\"BoardCertificationInUseFlag\": \"InUse\",\r\n"
        		+ "		\"BoardCertificationInitialDate\": \"InitialCertificationDate\",\r\n"
        		+ "		\"BoardCertificationExpirationDate\": \"ExpirationDate\",\r\n"
        		+ "		\"BoardCertificationExamDate\": \"ExamDate\",\r\n"
        		+ "		\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"board_ifnull_parameter\": {\r\n"
        		+ "		\"BoardCertificationSpecialtyCode\": [ \"SpecialtyID_Code\", \"SpecializationID_Code\" ],\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"credential\": {\r\n"
        		+ "		\"CredentialCode\": [ \"DegreeID_1_Code\", \"DegreeID_2_Code\", \"DegreeID_3_Code\" ],\r\n"
        		+ "		\"CredentialRank\": \"CredentialRank\",\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"LanguageSpoken\": {\r\n"
        		+ "		\"LanguageSpokenCode\": [ \"LanguageID_1_Code\", \"LanguageID_2_Code\", \"LanguageID_3_Code\", \"LanguageID_4_Code\", \"LanguageID_5_Code\" ]\r\n"
        		+ "		\"LanguageSpokenRank\": \"LanguageSpokenRank\",\r\n"
        		+ "	}\r\n"
        		+ " }\r\n"
        		+ "}";
        Config indConfig = ConfigFactory.parseString(indConf).resolve();
        Config newconf = indConfig.getConfig("indConfig");
        
        PCollection<TableRow> demo = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.demographic_land").usingStandardSql());
        
        PCollection<TableRow> board = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.boardcertification_land LIMIT 1000").usingStandardSql());
		
        PCollection<TableRow> updateddemo = demo.apply(ParDo.of(new DemoFn(newconf)));
        /*
        PCollection<TableRow> firstjoin = updateddemo.apply(new PerformJoin(alias_output, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> secondjoin = firstjoin.apply(new PerformJoin(credential, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> thirdjoin = secondjoin.apply(new PerformJoin(reference, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> fourthjoin = thirdjoin.apply(new PerformJoin(board, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> fifthjoin= fourthjoin.apply(new PerformJoin(dea, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> sixthjoin = fifthjoin.apply(new PerformJoin(spl, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> sevethjoin = sixthjoin.apply(new PerformJoin(cds, "ProviderID", "LeftOuterJoin"));
        
        PCollection<TableRow> test = sevethjoin.apply(ParDo.of(new DoFn<TableRow, TableRow>(){
        	@ProcessElement
        	public void ProcessElement(ProcessContext c) {
        		TableRow obj = c.element().clone();
        		
        		TableRow[] managedIdentifier = new TableRow[1];
        		
        		TableRow input = new TableRow();
        		input.set("ManagedIdentifierType", "Medicaid Number");
        		input.set("ManagedIdentifierValue", String.valueOf(obj.get("MedicaidNumber")));
        		input.set("StateProfessionalLicenseTypeCode", "");
        		input.set("IssuingAuthority", "");
        		input.set("Profession", "");
        		input.set("State", "");
        		input.set("InitialIssueDate", "");
        		input.set("EffectiveDate", "");
        		input.set("RenewalDate", "");
        		input.set("ExpirationDate", "");
        		input.set("CredentialInUseFlag", "");
        		managedIdentifier[0] = input;
        		obj.set("ManagedIdentifier", managedIdentifier);
        		
        		c.output(obj);
        	}
        }));
        
        test.apply(ParDo.of(new DoFn<TableRow, Void>(){
        	@ProcessElement
        	public void ProcessElement(ProcessContext c) {
        		System.out.println(String.valueOf(c.element()));
        	}
        }));*/
        PCollection<TableRow> cdsjoin = updateddemo.apply(new CredentialSpecificJoin(cds, 0, "cds"));
        PCollection<TableRow> deajoin = cdsjoin.apply(new CredentialSpecificJoin(dea, 0, "dea"));
        PCollection<TableRow> spljoin = deajoin.apply(new CredentialSpecificJoin(spl, 0, "spl"));
        		//.apply(ParDo.of(new NewIdentifierFn("dea", 0)));
        List<String> nullValues = new ArrayList<>();
        nullValues.add("NPI");
        nullValues.add("MedicareNumber");
        nullValues.add("MedicaidNumber");
        nullValues.add("TaxID");
        List<String> xqc = new ArrayList<>();
        xqc.add("s");
        PCollection<TableRow> identifier = spljoin.apply(ParDo.of(new AddManagedIdentifierFn(7, xqc, nullValues)));
        /*
        PCollection<TableRow> cdsjoin = updateddemo.apply(new CredentialSpecificJoin(cds, 0, "cds"));
        PCollection<TableRow> spljoin = cdsjoin.apply(new CredentialSpecificJoin(spl, 1, "spl"));
        PCollection<TableRow> deajoin = spljoin.apply(new CredentialSpecificJoin(dea, 2, "dea"));
        
        List<String> vals = new ArrayList<>();
        vals.add("dea");
        vals.add("spl");
        vals.add("cds");
        
        List<String> simple = new ArrayList<>();
        simple.add("NPI");
        simple.add("MedicaidNumber");
        simple.add("TaxID");
        simple.add("MedicareNumber");
        PCollection<TableRow> managedIdentity = deajoin.apply(ParDo.of(new AddManagedIdentifierFn(7, vals, simple)));
        		//.apply(ParDo.of(new AddManagedIdentifierFn("cds", 0)));
        */
        
        List<TableFieldSchema> fieldsOrg = new ArrayList<TableFieldSchema>(); 

        fieldsOrg.add(new TableFieldSchema().setName("ProviderID").setType("String").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("Status").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("NameSuffixCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("RaceCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("FieldofLicensureCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("FamilyName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("GivenName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DeceasedFlag").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("MiddleName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DeathDate").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("SSN").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("MaritalStatusCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DOB").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("DomesticPartnerName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("NamePrefixCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("LastUpdated").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("FullName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("EthnicityCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("PreferredName").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("AdministrativeGenderCode").setType("STRING").setMode("NULLABLE"));
        fieldsOrg.add(new TableFieldSchema().setName("SystemIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("SystemIdentifierType").setType("String"),
        				new TableFieldSchema().setName("SystemIdentifierValue").setType("STRING"))));
        fieldsOrg.add(new TableFieldSchema().setName("crosswalks").setType("STRUCT").setFields(
        				Arrays.asList(new TableFieldSchema().setName("type").setType("String"),
        				new TableFieldSchema().setName("value").setType("STRING"))));
        fieldsOrg.add(new TableFieldSchema().setName("ManagedIdentifier").setType("STRUCT").setMode("REPEATED").setFields(
        		Arrays.asList(new TableFieldSchema().setName("ManagedIdentifierType").setType("String"),
        				new TableFieldSchema().setName("ManagedIdentifierValue").setType("String"),
        				new TableFieldSchema().setName("StateProfessionalLicenseTypeCode").setType("STRING"),
        				new TableFieldSchema().setName("Profession").setType("STRING"),
        		new TableFieldSchema().setName("IssuingAuthority").setType("STRING"),
        		new TableFieldSchema().setName("State").setType("STRING"),
        		new TableFieldSchema().setName("InitialIssueDate").setType("STRING"),
        		new TableFieldSchema().setName("EffectiveDate").setType("STRING"),
        		new TableFieldSchema().setName("RenewalDate").setType("STRING"),
        		new TableFieldSchema().setName("CredentialInUseFlag").setType("STRING"),
        		new TableFieldSchema().setName("ExpirationDate").setType("STRING"))));
        fieldsOrg.add(new TableFieldSchema().setName("Phone").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("PhoneType").setType("String"),
        				new TableFieldSchema().setName("Number").setType("String"),
        				new TableFieldSchema().setName("Extension").setType("String"),
        				new TableFieldSchema().setName("Rank").setType("STRING"))));	
        fieldsOrg.add(new TableFieldSchema().setName("Credential").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("CredentialCode").setType("String"),
        				new TableFieldSchema().setName("CredentialRank").setType("STRING"))));					
        fieldsOrg.add(new TableFieldSchema().setName("LanguageSpoken").setType("STRUCT").setMode("REPEATED").setFields(
        				Arrays.asList(new TableFieldSchema().setName("LanguageSpokenCode").setType("String"),
        				new TableFieldSchema().setName("LanguageSpokenRank").setType("STRING"))));	
        
        TableSchema schemaOrg = new TableSchema().setFields(fieldsOrg);
        
        identifier.apply("Writing to BQ",
				BigQueryIO.writeTableRows().to("asc-ahnat-apdh-sbx:apdh_test_dataset.aaaaaaa")
						.withSchema(schemaOrg)
						.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
        
        //PCollection<TableRow> prejoin = updateddemo.apply(new PerformJoin(changedRef, "ProviderID", "LeftOuterJoin"));
        //PCollection<TableRow> firstJoin = updateddemo.apply(new PerformJoin(alias_output, "ProviderID", "LeftOuterJoin"));
        //PCollection<TableRow> secondJoin = firstJoin.apply(new PerformJoin(board, "ProviderID", "LeftOuterJoin"));
        
        //PCollection<TableRow> check = secondJoin.apply(ParDo.of(new UpdateDemoFn(newconf)));
        
		pipeline.run(options).waitUntilFinish();

	}
	
	public static class ExtractLicenseFn extends DoFn<TableRow, TableRow> {
		
		private String licenseType;

		public ExtractLicenseFn(String licenseType) {
			this.licenseType = licenseType;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element();
			
			TableRow output = new TableRow();
			
			if (String.valueOf(obj.get("LicenseTypeID_Code")).equals(licenseType)) {
		          
                output.set("CredentialID", String.valueOf(obj.get("CredentialID")));
                output.set("ProviderID", String.valueOf(obj.get("ProviderID")));
                output.set("Issued", String.valueOf(obj.get("Issued")));
                output.set("Renewed", String.valueOf(obj.get("Renewed")));
                output.set("Expired", String.valueOf(obj.get("Expired")));
                output.set("LicenseNumber", String.valueOf(obj.get("LicenseNumber")));
                output.set("LicenseTypeID_Code", String.valueOf(obj.get("LicenseTypeID_Code")));
                output.set("LicenseSubType_Code", String.valueOf(obj.get("LicenseSubType_Code")));
                output.set("LicensureBoardID_Code", String.valueOf(obj.get("LicensureBoardID_Code")));
                output.set("State", String.valueOf(obj.get("State")));
                output.set("StateProfessionID", String.valueOf(obj.get("StateProfessionID")));
                output.set("Status", String.valueOf(obj.get("Status")));
                output.set("InUse", String.valueOf(obj.get("InUse")));
                output.set("LastUpdated", String.valueOf(obj.get("LastUpdated")));
                c.output(output);
            }
		}
	}
	
	public static class ExtractAliasFn extends DoFn<TableRow, TableRow>{
		
		private List<String> values;

		public ExtractAliasFn(List<String> values) {
			this.values  = values;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element();
			
			TableRow output = new TableRow();
			
			if(values.contains(String.valueOf(obj.get("AliasTypeID_Code")))) {
				output.set("ProviderID", String.valueOf(obj.get("ProviderID")));
				output.set("AliasID", String.valueOf(obj.get("AliasID")));
				output.set("AliasTypeID_Code", String.valueOf(obj.get("AliasTypeID_Code")));
				output.set("GivenName", String.valueOf(obj.get("GivenName")));
				output.set("FamilyName", String.valueOf(obj.get("FamilyName")));
				c.output(output);
			}
			
		}
	}
	
	public static class ExtractEntityFn extends DoFn<TableRow, TableRow>{
		
		private Config config;
		private String entityName;
		public ExtractEntityFn(Config config, String entityName) {
			this.config = config;
			this.entityName = entityName;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			List<String> attributes = config.getStringList(entityName);
			TableRow obj = c.element();
			TableRow output = new TableRow();
			
			attributes.stream().forEach((k)->{
				output.set(k, String.valueOf(obj.get(k)));
			});
			System.out.println(String.valueOf(output));
			c.output(output);
		}
	}
	
	public static class ReferenceFormatFn extends DoFn<TableRow, TableRow>{
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			System.out.println("refinput"+String.valueOf(obj));
			TableRow finalOutput = new TableRow();
			TableRow[] education = new TableRow[1];
			
			TableRow temp = new TableRow();
			temp.set("EducationInstitution", String.valueOf(obj.get("Name")));
			temp.set("EducationTypeCode", String.valueOf(obj.get("ReferenceType")));
			temp.set("ReferenceSourceArchivedFlag", String.valueOf(obj.get("Archived")));
			temp.set("ReferenceInUseFlag", String.valueOf(obj.get("InUse")));
			temp.set("SubjectOfStudy", String.valueOf(obj.get("Subject")));
			temp.set("AcademicDegreeCode", String.valueOf(obj.get("DegreeEarnedID_Code")));
			temp.set("AcademicDegreeStartDate", String.valueOf(obj.get("StartDate")));
			temp.set("AcademicDegreeEndDate", String.valueOf(obj.get("EndDate")));
			
			education[0] = temp;
			finalOutput.set("Education", education);
			
			finalOutput.set("ProviderID", String.valueOf(obj.get("ProviderID")));
			System.out.println(String.valueOf(finalOutput));
			c.output(finalOutput);
		}
	}
	
	public static class DemoFn extends DoFn<TableRow, TableRow>{
		
		
		//used for demographic -> change name
		private Config config;
		private PCollection<TableRow> dea;
		public DemoFn(Config config) {
			this.config = config;
			
		}
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			
			TableRow obj = c.element().clone();
			TableRow returnObj = new TableRow();
			
			List<String> attrList = (List<String>) config.getObject(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS).keySet().stream().collect(Collectors.toList());
			Config values = config.getConfig(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS);
			
			attrList.stream().forEach((attr)->{
				String recordName = values.getString(attr);
				if(recordName.equals(RecordGenerationConstants.NO_RECORD)) {
					returnObj.set(attr, "");
				}else {
					returnObj.set(attr, String.valueOf(obj.get(recordName)));
				}
			});
			
			TableRow[] systemIdentifier = new TableRow[1];
			TableRow sysIdentityInput = new TableRow();
			sysIdentityInput.set("SystemIdentifierType", "ProviderID");
			sysIdentityInput.set("SystemIdentifierValue", String.valueOf(obj.get("ProviderID")));
			systemIdentifier[0] = sysIdentityInput;
			
			returnObj.set("SystemIdentifier", systemIdentifier);
			
			TableRow[] phone = new TableRow[2];
			TableRow phone1 = new TableRow();
			phone1.set("PhoneType", "Mobile");
			phone1.set("Number", String.valueOf(obj.get("CellPhone")));
			phone1.set("Extension", "");
			phone1.set("Rank", "");
			
			TableRow phone2 = new TableRow();
			phone2.set("PhoneType", "Pager");
			phone2.set("Number", String.valueOf(obj.get("Pager")));
			phone2.set("Extension", "");
			phone2.set("Rank", "");
			
			phone[0] = phone1;
			phone[1] = phone2;
			
			returnObj.set("Phone", phone);
			
			TableRow crosswalks = new TableRow();
			crosswalks.set("type", "configuration/sources/MDStaff");
			crosswalks.set("value", String.valueOf(obj.get("ProviderID")));
			
			returnObj.set("crosswalks", crosswalks);
			
			Config credential = config.getConfig("credential");
			List<String> credentialCode = credential.getStringList("CredentialCode");
			TableRow[] credentialTr = new TableRow[credentialCode.size()];
			for(int i=0;i<credentialCode.size();i++) {
				TableRow cred = new TableRow();
				if(String.valueOf(obj.get(credentialCode.get(i))).equals("null")) {
					cred.set("CredentialCode", String.valueOf(obj.get(credentialCode.get(i))));
					cred.set("CredentialRank", "");
				}else {
					cred.set("CredentialCode", String.valueOf(obj.get(credentialCode.get(i))));
					cred.set("CredentialRank", String.valueOf(i+1));
				}
				credentialTr[i] = cred;
			}
			
			returnObj.set("Credential", credentialTr);
			
			Config lang = config.getConfig("LanguageSpoken");
			List<String> langCode = lang.getStringList("LanguageSpokenCode");
			TableRow[] langTr = new TableRow[langCode.size()];
			
			for(int i=0;i<langCode.size();i++) {
				TableRow langs = new TableRow();
				if(String.valueOf(obj.get(langCode.get(i))).equals("null")) {
					langs.set("LanguageSpokenCode", String.valueOf(obj.get(langCode.get(i))));
					langs.set("LanguageSpokenRank", "");
				}else {
					langs.set("LanguageSpokenCode", String.valueOf(obj.get(langCode.get(i))));
					langs.set("LanguageSpokenRank", String.valueOf(i+1));
				}
				langTr[i] = langs;
			}
			
			returnObj.set("LanguageSpoken", langTr);
			
			//TableRow[] managedIdentifier = new TableRow[6];
			
			System.out.println(String.valueOf(returnObj));
			c.output(returnObj);
		}
	}
	
	public static class UpdateDemoFn extends DoFn<TableRow, TableRow>{
		
		//writes alias entry
		private Config config;

		public UpdateDemoFn(Config config) {
			this.config = config;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			Config param = config.getConfig("alias_demo_parameters");
			
			List<String> asIsValues = config.getStringList("general_parameters");
			
			TableRow obj = c.element().clone();
			//System.out.println(String.valueOf(obj));
			//TableRow returnObj = new TableRow();
			TableRow returnObj = obj;
			//returnObj.remove();
			
			asIsValues.stream().forEach((k)->{
				returnObj.set(k, String.valueOf(obj.get(k)));
			});
			
			List<String> attrList = (List<String>) config.getObject("alias_demo_parameters").keySet().stream().collect(Collectors.toList());
			Config values = config.getConfig("alias_demo_parameters");
			
			TableRow alias = new TableRow();
			attrList.stream().forEach((attr)->{
				String recordName = values.getString(attr);
				if(recordName.equals(RecordGenerationConstants.NO_RECORD)) {
					alias.set(attr, "");
				}else {
					alias.set(attr, String.valueOf(obj.get(recordName)));
				}
			});		
			returnObj.set("Alias", alias);
			
			
			List<String> attrList1 = (List<String>) config.getObject("board_parameters").keySet().stream().collect(Collectors.toList());
			Config values1 = config.getConfig("board_parameters");
			
			TableRow board = new TableRow();
			attrList1.stream().forEach((attr)->{
				String recordName = values1.getString(attr);
				if(recordName.equals(RecordGenerationConstants.NO_RECORD)) {
					board.set(attr, "");
				}else {
					board.set(attr, String.valueOf(obj.get(recordName)));
				}
			});
			
			List<String> attrList2 = (List<String>) config.getObject("board_ifnull_parameter").keySet().stream().collect(Collectors.toList());
			Config values2 = config.getConfig("board_ifnull_parameter");
			
			attrList2.stream().forEach((attr)->{
				List<String> val = values2.getStringList(attr);
				if(String.valueOf(obj.get(val.get(0))).equals("null")) {
					board.set(attr, String.valueOf(obj.get(val.get(0))));
				}else {
					board.set(attr, String.valueOf(obj.get(val.get(1))));
				}
				
			});
			
			returnObj.set("BoardCertification", board);
			System.out.println(String.valueOf(returnObj));
			c.output(returnObj);
		}
	}
	
	public static class LoadEducationFn extends DoFn<TableRow, TableRow>{
		
		private PCollectionView<TableRow> reference;

		public LoadEducationFn(PCollectionView<TableRow> reference) {
			this.reference = reference;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow newObj = c.sideInput(reference);
			Object edu = newObj.get("Education");
			
			TableRow returnObj = c.element().clone();
			returnObj.set("Education", edu);
			
			System.out.println("test"+String.valueOf(returnObj));
			c.output(returnObj);
		}
	}
	
	public static class CredentialSpecificJoin extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{

		//code specifies the entry in managedidentifier tablerow[]
		/// val will contain the name dea/cdl/spc
		private PCollection<TableRow> joinInput;
		private int code;
		private String val;

		public CredentialSpecificJoin(PCollection<TableRow> joinInput, int code, String val) {
			this.joinInput = joinInput;
			this.code = code;
			this.val = val;
		}
		
		@Override
		public PCollection<TableRow> expand(PCollection<TableRow> input) {
			PCollection<TableRow> output = null;
			
			PCollection<TableRow> joinedValue = input.apply(new PerformJoin(joinInput, "ProviderID", "LeftOuterJoin"));
			output = joinedValue.apply(ParDo.of(new TestFn(val)));
			return output;
		}
		
	}
	
	public static class AddManagedIdentifierFn extends DoFn<TableRow, TableRow>{
		
		
		private int index;
		private List<String> values;
		private List<String> nullValues;
		
		public AddManagedIdentifierFn(int index, List<String> values, List<String> nullValues) {
			
			this.index = index;
			this.values = values;
			this.nullValues = nullValues;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			TableRow managedIdentifier[] = new TableRow[index];
			int i=0;
			/*
			for(int j=0;j<values.size();j++) {
				if(obj.containsKey(values.get(j))) {
					managedIdentifier[i] = (TableRow) obj.get(values.get(j));
					obj.remove(values.get(j));
					++i;
				}
			}
			*/
			TableRow spl = new TableRow();
			spl.set("ManagedIdentifierType", "State Professional License");
			spl.set("ManagedIdentifierValue", String.valueOf(obj.get("ManagedIdentifierValuespl")));
			spl.set("StateProfessionalLicenseTypeCode", String.valueOf(obj.get("StateProfessionalLicenseTypeCodespl")));
			spl.set("IssuingAuthority", String.valueOf(obj.get("IssuingAuthorityspl")));
			spl.set("Profession", String.valueOf(obj.get("Professionspl")));
			spl.set("State", String.valueOf(obj.get("Statespl")));
			spl.set("InitialIssueDate", String.valueOf(obj.get("InitialIssueDatespl")));
			spl.set("EffectiveDate", "");
			spl.set("RenewalDate", String.valueOf(obj.get("RenewalDatespl")));
			spl.set("ExpirationDate", String.valueOf(obj.get("ExpirationDatespl")));
			spl.set("CredentialInUseFlag", String.valueOf(obj.get("CredentialInUseFlagspl")));
			
			managedIdentifier[i] = spl;
			++i;
			
			TableRow dea = new TableRow();
			dea.set("ManagedIdentifierType", "Drug Enforcement Agency Number");
			dea.set("ManagedIdentifierValue", String.valueOf(obj.get("ManagedIdentifierValuesdea")));
			dea.set("StateProfessionalLicenseTypeCode", String.valueOf(obj.get("StateProfessionalLicenseTypeCodedea")));
			dea.set("IssuingAuthority", String.valueOf(obj.get("IssuingAuthoritydea")));
			dea.set("Profession", String.valueOf(obj.get("Professiondea")));
			dea.set("State", String.valueOf(obj.get("Statedea")));
			dea.set("InitialIssueDate", String.valueOf(obj.get("InitialIssueDatedea")));
			dea.set("EffectiveDate", "");
			dea.set("RenewalDate", String.valueOf(obj.get("RenewalDatedea")));
			dea.set("ExpirationDate", String.valueOf(obj.get("ExpirationDatedea")));
			dea.set("CredentialInUseFlag", String.valueOf(obj.get("CredentialInUseFlagdea")));
			
			managedIdentifier[i] = dea;
			++i;
			
			TableRow cds = new TableRow();
			cds.set("ManagedIdentifierType", "Controlled Dangerous Substance License Number");
			cds.set("ManagedIdentifierValue", String.valueOf(obj.get("ManagedIdentifierValuescds")));
			cds.set("StateProfessionalLicenseTypeCode", String.valueOf(obj.get("StateProfessionalLicenseTypeCodecds")));
			cds.set("IssuingAuthority", String.valueOf(obj.get("IssuingAuthoritycds")));
			cds.set("Profession", String.valueOf(obj.get("Professioncds")));
			cds.set("State", String.valueOf(obj.get("Statecds")));
			cds.set("InitialIssueDate", String.valueOf(obj.get("InitialIssueDatecds")));
			cds.set("EffectiveDate", "");
			cds.set("RenewalDate", String.valueOf(obj.get("RenewalDatecds")));
			cds.set("ExpirationDate", String.valueOf(obj.get("ExpirationDatecds")));
			cds.set("CredentialInUseFlag", String.valueOf(obj.get("CredentialInUseFlagcds")));
			
			managedIdentifier[i] = cds;
			++i;
			
			for(int j=0;j<nullValues.size();j++) {
				TableRow input = new TableRow();
				if(nullValues.get(j).equals("NPI")) {
					input.set("ManagedIdentifierType", "National Provider Identifier");
					input.set("ManagedIdentifierValue", String.valueOf(obj.get("NPI")));
				}else if(nullValues.get(j).equals("MedicareNumber")) {
					input.set("ManagedIdentifierType", "Provider Transaction Access Number");
					input.set("ManagedIdentifierValue", String.valueOf(obj.get("MedicareNumber")));
				}else if(nullValues.get(j).equals("MedicaidNumber")) {
					input.set("ManagedIdentifierType", "Medicaid Number");
					input.set("ManagedIdentifierValue", String.valueOf(obj.get("MedicaidNumber")));
				}else if(nullValues.get(j).equals("TaxID")) {
					input.set("ManagedIdentifierType", "Taxpayer Identification Number");
					input.set("ManagedIdentifierValue", String.valueOf(obj.get("TaxID")));
				}
				input.set("StateProfessionalLicenseTypeCode", "");
				input.set("IssuingAuthority", "");
				input.set("Profession", "");
				input.set("State", "");
				input.set("InitialIssueDate", "");
				input.set("EffectiveDate", "");
				input.set("RenewalDate", "");
				input.set("ExpirationDate", "");
				input.set("CredentialInUseFlag", "");
				managedIdentifier[i] = input;
				++i;
			}
			
			obj.set("ManagedIdentifier", managedIdentifier);
			
			obj.remove("ManagedIdentifierTypespl");
			obj.remove("ManagedIdentifierValuespl");
			obj.remove("StateProfessionalLicenseTypeCodespl");
			obj.remove("IssuingAuthorityspl");
			obj.remove("Statespl");
			obj.remove("InitialIssueDatespl");
			obj.remove("Professionspl");
			obj.remove("RenewalDatespl");
			obj.remove("ExpirationDatespl");
			obj.remove("CredentialInUseFlagspl");
			
			obj.remove("ManagedIdentifierTypedea");
			obj.remove("ManagedIdentifierValuedea");
			obj.remove("StateProfessionalLicenseTypeCodedea");
			obj.remove("IssuingAuthoritydea");
			obj.remove("Statedea");
			obj.remove("InitialIssueDatedea");
			obj.remove("Professiondea");
			obj.remove("RenewalDatedea");
			obj.remove("ExpirationDatedea");
			obj.remove("CredentialInUseFlagdea");
			
			obj.remove("ManagedIdentifierTypecds");
			obj.remove("ManagedIdentifierValuecds");
			obj.remove("StateProfessionalLicenseTypeCodecds");
			obj.remove("IssuingAuthoritycds");
			obj.remove("Statecds");
			obj.remove("InitialIssueDatecds");
			obj.remove("Professioncds");
			obj.remove("RenewalDatecds");
			obj.remove("ExpirationDatecds");
			obj.remove("CredentialInUseFlagcds");
			
			obj.remove("TaxID");
			obj.remove("MedicaidNumber");
			obj.remove("MedicareNumber");
			obj.remove("NPI");
			obj.remove("EffectiveDatedea");
			obj.remove("EffectiveDatecds");
			obj.remove("EffectiveDatespl");
			
			System.out.println(String.valueOf(obj));
			c.output(obj);
		}
	}
	
	public static class TestFn extends DoFn<TableRow, TableRow>{
		private String val;

		public TestFn(String val) {
			this.val = val;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			TableRow identifier = new TableRow();
			
			if(val.equals("spl")) {
				obj.set("ManagedIdentifierType"+val, "State Professional License");
			}else if(val.equals("dea")) {
				obj.set("ManagedIdentifierType"+val, "Drug Enforcement Agency Number");
			}else if(val.equals("cds")) {
				obj.set("ManagedIdentifierType"+val, "Controlled Dangerous Substance License Number");
			}
			
			obj.set("ManagedIdentifierValue"+val, String.valueOf(obj.get("LicenseNumber")));
			obj.set("StateProfessionalLicenseTypeCode"+val, String.valueOf(obj.get("LicenseSubType_Code")));
			obj.set("IssuingAuthority"+val, String.valueOf(obj.get("LicensureBoardID_Code")));
			obj.set("State"+val, String.valueOf(obj.get("State")));
			obj.set("InitialIssueDate"+val, String.valueOf(obj.get("Issued")));
			obj.set("EffectiveDate"+val, "");
			obj.set("RenewalDate"+val, String.valueOf(obj.get("Renewed")));
			obj.set("ExpirationDate"+val, String.valueOf(obj.get("Expired")));
			obj.set("CredentialInUseFlag"+val, String.valueOf(obj.get("InUse")));
			obj.set("Profession"+val, String.valueOf(obj.get("StateProfessionID")));
			
			obj.remove("LicenseNumber");
			obj.remove("LicenseSubType_Code");
			obj.remove("LicensureBoardID_Code");
			obj.remove("State");
			obj.remove("Issued");
			obj.remove("Renewed");
			obj.remove("Expired");
			obj.remove("InUse");
			obj.remove("LicenseTypeID_Code");
			obj.remove("CredentialID");
			obj.remove("StateProfessionID");
			obj.remove("Status");
			
			//obj.set(val, identifier);
			System.out.println(String.valueOf(obj));
			c.output(obj);
	}
	}
	
	public static class NewIdentifierFn extends DoFn<TableRow, TableRow>{
		private String code;
		private int index;

		public NewIdentifierFn(String code, int index) {
			this.code = code;
			this.index = index;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element().clone();
			TableRow[] managedIdentifier = new TableRow[1];
			int i=0;
			if(obj.containsKey(code)) {
				
				managedIdentifier[index] = (TableRow) obj.get(code);
			}
			
			obj.set("ManagedIdentifier", managedIdentifier);
			obj.remove(code);
			
			c.output(obj);
		}
	}
}
