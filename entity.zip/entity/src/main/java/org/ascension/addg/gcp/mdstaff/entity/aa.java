package org.ascension.addg.gcp.mdstaff;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.windowing.GlobalWindow;
import org.apache.beam.sdk.values.PCollection;

import org.joda.time.Instant;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class aa {

	public static void main(String[] args) {
		
		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		String q = "{\r\n"
				+ "\"query\": \"\"\"\r\n"
				+ "WITH\r\n"
				+ "temp_unnest1 AS (\r\n"
				+ "SELECT\r\n"
				+ "CASE\r\n"
				+ "WHEN crosswalks.crosswalks_value='null' THEN NULL\r\n"
				+ "ELSE\r\n"
				+ "crosswalks.crosswalks_value\r\n"
				+ "END\r\n"
				+ "AS crosswalks_value,\r\n"
				+ "managedidentifier.*,\r\n"
				+ "LANGUAGE.*,\r\n"
				+ "credential.*,\r\n"
				+ "phone.*\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.clinical_practitioner_hcp_sort`,\r\n"
				+ "UNNEST(managedidentifier) managedidentifier\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos1\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(language_spoken)\r\n"
				+ "LANGUAGE\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos2\r\n"
				+ "ON\r\n"
				+ "pos1=pos2\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(credential) credential\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos3\r\n"
				+ "ON\r\n"
				+ "pos1=pos3\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(email) email\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos4\r\n"
				+ "ON\r\n"
				+ "pos1=pos4\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(phone) phone\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos5\r\n"
				+ "ON\r\n"
				+ "pos1=pos5 ),\r\n"
				+ "temp_unnest2 AS (\r\n"
				+ "SELECT\r\n"
				+ "CASE\r\n"
				+ "WHEN crosswalks.crosswalks_value='null' THEN NULL\r\n"
				+ "ELSE\r\n"
				+ "crosswalks.crosswalks_value\r\n"
				+ "END\r\n"
				+ "AS crosswalks_value,\r\n"
				+ "managedidentifier.*,\r\n"
				+ "alias.*,\r\n"
				+ "education.*,\r\n"
				+ "email.*,\r\n"
				+ "BoardCertification.*\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.clinical_practitioner_hcp_sort`,\r\n"
				+ "UNNEST(managedidentifier) managedidentifier\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos1\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(education) Education\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos2\r\n"
				+ "ON\r\n"
				+ "pos1=pos2\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(alias) alias\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos3\r\n"
				+ "ON\r\n"
				+ "pos1=pos3\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(email) email\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos4\r\n"
				+ "ON\r\n"
				+ "pos1=pos4\r\n"
				+ "LEFT OUTER JOIN\r\n"
				+ "UNNEST(Board_Certification) BoardCertification\r\n"
				+ "WITH\r\n"
				+ "OFFSET\r\n"
				+ "pos5\r\n"
				+ "ON\r\n"
				+ "pos1=pos5),\r\n"
				+ "bridge_unnest1 AS (\r\n"
				+ "SELECT\r\n"
				+ "crosswalks_value AS key_1,\r\n"
				+ "ARRAY_AGG(STRUCT(STRUCT([STRUCT(managedidentifier_type AS value) ] AS ManagedIdentifierType,\r\n"
				+ "[STRUCT (managedidentifier_value AS value) ]AS ManagedIdentifierValue,\r\n"
				+ "[STRUCT (state_profession_type_code AS value)] AS StateProfessionTypeCode,\r\n"
				+ "[STRUCT (issuing_authority AS value) ]AS IssuingAuthority,\r\n"
				+ "[STRUCT (identifier_status AS value)] AS IdentifierStatus,\r\n"
				+ "[STRUCT (Initial_Issue_Date AS value)] AS InitialIssueDate,\r\n"
				+ "[STRUCT (effective_date AS value)] AS EffectiveDate,\r\n"
				+ "[STRUCT (renewal_date AS value)] AS RenewalDate,\r\n"
				+ "[STRUCT (expiration_date AS value)] AS ExpirationDate,\r\n"
				+ "[STRUCT (state AS value)] AS State,\r\n"
				+ "[STRUCT (credential_in_use_flag AS value)] AS CredentialInUseFlag) AS value)) AS ManagedIdentifier,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( language_spoken_code AS value)] AS LanguageSpokenCode,\r\n"
				+ "[STRUCT( language_spoken_rank AS value)] AS LanguageSpokenRank) AS value )) AS LanguageSpoken,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( credential_code AS value)] AS CredentialCode,\r\n"
				+ "[STRUCT( credential_rank AS value)] AS CredentialRank) AS value )) AS Credential,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( type AS value)] AS PhoneType,\r\n"
				+ "[STRUCT( number AS value)] AS Number,\r\n"
				+ "[STRUCT( Extension AS value)] AS Extension,\r\n"
				+ "[STRUCT( rank AS value)] AS Rank) AS value )) AS Phone\r\n"
				+ "FROM\r\n"
				+ "temp_unnest1\r\n"
				+ "GROUP BY\r\n"
				+ "crosswalks_value ),\r\n"
				+ "bridge_unnest2 AS (\r\n"
				+ "SELECT\r\n"
				+ "crosswalks_value AS key_2,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( type AS value)] AS EmailType,\r\n"
				+ "[STRUCT( email AS value)] AS Email) AS value )) AS Email,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( type AS value)] AS EmailType,\r\n"
				+ "[STRUCT( alias_given_name AS value)] AS AliasGivenName,\r\n"
				+ "[STRUCT( alias_family_name AS value)] AS AliasFamilyName,\r\n"
				+ "[STRUCT( alias_middle_name AS value)] AS AliasMiddleName) AS value )) AS Alias,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( Board_Certification_Code AS value)] AS BoardCertificationCode,\r\n"
				+ "[STRUCT( Board_Certification_Specialty_Code AS value)] AS BoardCertificationSpecialtyCode,\r\n"
				+ "[STRUCT( Board_Certification_Status_Code AS value)] AS BoardCertificationStatusCode,\r\n"
				+ "[STRUCT( Board_Certification_Number AS value)] AS BoardCertificationNumber,\r\n"
				+ "[STRUCT( Board_Certification_Lifetime_Status AS value)] AS BoardCertificationLifetimeStatus,\r\n"
				+ "[STRUCT( Board_Certification_In_Use_Flag AS value)] AS BoardCertificationInUseFlag,\r\n"
				+ "[STRUCT( Board_Certification_Initial_Date AS value)] AS BoardCertificationInitialDate,\r\n"
				+ "[STRUCT( Board_Certification_Expiration_Date AS value)] AS BoardCertificationExpirationDate,\r\n"
				+ "[STRUCT( Board_Certification_Exam_Date AS value)] AS BoardCertificationExamDate) AS value )) AS BoardCertification,\r\n"
				+ "ARRAY_AGG (STRUCT(STRUCT ([STRUCT( Education_Institution AS value)] AS EducationInstitution,\r\n"
				+ "[STRUCT( Education_Type_Code AS value)] AS EducationTypeCode,\r\n"
				+ "[STRUCT( Reference_Source_Archived_Flag AS value)] AS ReferenceSourceArchivedFlag,\r\n"
				+ "[STRUCT( Reference_In_Use_Flag AS value)] AS ReferenceInUseFlag,\r\n"
				+ "[STRUCT( Subject_Of_Study AS value)] AS SubjectOfStudy,\r\n"
				+ "[STRUCT( Academic_Degree_Code AS value)] AS AcademicDegreeCode,\r\n"
				+ "[STRUCT( Academic_Degree_Start_Date AS value)] AS AcademicDegreeStartDate,\r\n"
				+ "[STRUCT( Academic_Degree_End_Date AS value)] AS AcademicDegreeEndDate) AS value )) AS Education\r\n"
				+ "FROM\r\n"
				+ "temp_unnest2\r\n"
				+ "\r\n"
				+ "GROUP BY\r\n"
				+ "crosswalks_value),\r\n"
				+ "main_elements AS (\r\n"
				+ "SELECT\r\n"
				+ "recorded_indicator,\r\n"
				+ "meta_src_system_name,\r\n"
				+ "[STRUCT( given_name AS value)] AS GivenName,\r\n"
				+ "[STRUCT( family_name AS value)] AS FamilyName,\r\n"
				+ "[STRUCT( maiden_name AS value)] AS MaidenName,\r\n"
				+ "[STRUCT( middle_name AS value)] AS MiddleName,\r\n"
				+ "[STRUCT( full_name AS value)] AS FullName,\r\n"
				+ "[STRUCT( dob AS value)] AS DOB,\r\n"
				+ "[STRUCT( preferred_name AS value)] AS PreferredName,\r\n"
				+ "[STRUCT( administrative_gender_code AS value)] AS AdministrativeGenderCode,\r\n"
				+ "[STRUCT( ssn AS value)] AS SSN,\r\n"
				+ "[STRUCT( name_suffix_code AS value)] AS NameSuffixCode,\r\n"
				+ "[STRUCT( field_of_licensure_code AS value)] AS FieldofLicensureCode,\r\n"
				+ "[STRUCT(name_prefix_code AS value)] AS NamePrefixCode,\r\n"
				+ "[STRUCT( race_code AS value)] AS RaceCode,\r\n"
				+ "[STRUCT( ethnicity_code AS value)] AS EthnicityCode,\r\n"
				+ "[STRUCT( domestic_partner_name AS value)] AS DomesticPartnerName,\r\n"
				+ "[STRUCT(Marital_status_code AS value)] AS MaritalStatusCode,\r\n"
				+ "[STRUCT( Deceased_flag AS value)] AS DeceasedFlag,\r\n"
				+ "[STRUCT( Death_date AS value)] AS DeathDate,\r\n"
				+ "[STRUCT( Test_Record AS value)] AS TestRecordFlag,\r\n"
				+ "[STRUCT( Status_Code AS value)] AS StatusCode,\r\n"
				+ "[STRUCT(STRUCT (CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ProviderID'))<>0 THEN ARRAY( SELECT AS STRUCT x.systemidentifier_TYPE AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ProviderID')\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT \"\" AS value)\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierType,\r\n"
				+ "CASE\r\n"
				+ "WHEN ARRAY_LENGTH(ARRAY( SELECT AS STRUCT x.systemidentifier_value AS value FROM UNNEST(systemidentifier) AS x WHERE X.systemidentifier_TYPE='ProviderID'))=0 THEN ARRAY( SELECT AS STRUCT \"\" AS value)\r\n"
				+ "ELSE\r\n"
				+ "ARRAY(\r\n"
				+ "SELECT\r\n"
				+ "AS STRUCT x.systemidentifier_value AS value\r\n"
				+ "FROM\r\n"
				+ "UNNEST(systemidentifier) AS x\r\n"
				+ "WHERE\r\n"
				+ "X.systemidentifier_TYPE='ProviderID')\r\n"
				+ "END\r\n"
				+ "AS SystemIdentifierValue) AS value)] AS SystemIdentifier,\r\n"
				+ "crosswalks,\r\n"
				+ "crosswalks.crosswalks_value AS root_key\r\n"
				+ "FROM\r\n"
				+ "`asc-ahnat-apdh-sbx.apdh_test_dataset.clinical_practitioner_hcp_sort`)\r\n"
				+ "SELECT\r\n"
				+ "'configuration/entityTypes/HCP' AS type,\r\n"
				+ "recorded_indicator AS record_indicator,\r\n"
				+ "meta_src_system_name AS meta_src_system_name,\r\n"
				+ "'MD Staff' AS SourceSystemName,\r\n"
				+ "STRUCT(GivenName,\r\n"
				+ "FamilyName,\r\n"
				+ "MaidenName,\r\n"
				+ "MiddleName,\r\n"
				+ "FullName,\r\n"
				+ "DOB,\r\n"
				+ "AdministrativeGenderCode,\r\n"
				+ "SSN,\r\n"
				+ "NameSuffixCode,\r\n"
				+ "FieldofLicensureCode,\r\n"
				+ "ManagedIdentifier,\r\n"
				+ "SystemIdentifier,\r\n"
				+ "Credential,\r\n"
				+ "PreferredName,\r\n"
				+ "Alias,\r\n"
				+ "LanguageSpoken,\r\n"
				+ "NamePrefixCode,\r\n"
				+ "RaceCode,\r\n"
				+ "EthnicityCode,\r\n"
				+ "DomesticPartnerName,\r\n"
				+ "MaritalStatusCode,\r\n"
				+ "DeceasedFlag,\r\n"
				+ "DeathDate,\r\n"
				+ "TestRecordFlag,\r\n"
				+ "Email,\r\n"
				+ "Phone,\r\n"
				+ "education,\r\n"
				+ "BoardCertification) AS attributes,\r\n"
				+ "crosswalks\r\n"
				+ "FROM\r\n"
				+ "main_elements \r\n"
				+ "JOIN\r\n"
				+ "bridge_unnest1\r\n"
				+ "ON\r\n"
				+ "bridge_unnest1.key_1=main_elements.root_key\r\n"
				+ "JOIN\r\n"
				+ "bridge_unnest2\r\n"
				+ "ON\r\n"
				+ "bridge_unnest2.key_2=main_elements.root_key LIMIT 3\"\"\"\r\n"
				+ "}";
		
		Config conf = ConfigFactory.parseString(q).resolve();
		PCollection<TableRow> in = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery(conf.getString("query")).usingStandardSql());
		PCollection<PubsubMessage> msg = in.apply(ParDo.of(new ConvertFn()));
		msg.apply(PubsubIO.writeMessages().to("projects/asc-ahnat-apdh-sbx/topics/APDH_CANONICAL")); 
		pipeline.run().waitUntilFinish();
	}
	
	public static class PrintValueFn extends DoFn<TableRow, TableRow>{
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			System.out.println(String.valueOf(c.element()));
		}
	}
	
	public static class ConvertFn extends DoFn<TableRow, PubsubMessage>{
		
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			
			
			JSONArray emptyArr = new JSONArray();
			JSONObject emptyObj = new JSONObject();
			emptyObj.put("value", "");
			
			emptyArr.put(emptyObj);
			
			TableRow obj = c.element().clone();
			JSONObject finalObj = new  JSONObject();
			JSONArray finalarr = new JSONArray();
			
			obj.keySet().forEach((k)->{
				
				//System.out.println("key "+k+" value "+obj.get(k)+" classname "+obj.get(k).getClass());
				if(k.equals("attributes")) {
					TableRow in = (TableRow) obj.get(k);
					JSONObject attrObj = new JSONObject();
					
					in.keySet().forEach((key)->{
						//array list -> normal values, tablerow -> systemidentifier
						System.out.println("attributes key"+key+" value "+in.get(key)+" classname "+in.get(key).getClass());
						Object o = in.get(key);
						if(o instanceof ArrayList) {
							ArrayList l = (ArrayList) o;
							
							System.out.println("arraylistinfo "+String.valueOf(o)+" classname"+l.get(0).getClass());
							
							TableRow trVal = (TableRow) l.get(0);
							if(String.valueOf(trVal).equals("1GenericData{classInfo=[f], {}}")) {
								
								attrObj.put(key, emptyArr);
							}else if(key.equals("SystemIdentifier") || key.equals("ManagedIdentifier")
									|| key.equals("Credential") || key.equals("LanguageSpoken")) {
								JSONArray sysarr = new JSONArray();
								System.out.println("suysident"+String.valueOf(o));
								ArrayList al = (ArrayList) o;
								
								JSONObject sysobj = new JSONObject(); //parent
								
								
								for(int h =0;h<al.size();h++){
									System.out.println("Stream "+String.valueOf(h)+" "+al.get(h).getClass());
									TableRow tr = (TableRow) al.get(h);
									tr.keySet().forEach((g)->{
										// g is value
										System.out.println("second "+g+String.valueOf(tr.get(g))+" "+tr.get(g).getClass());
										TableRow m = (TableRow) tr.get(g);
										JSONObject childsysobj = new JSONObject();
										m.keySet().forEach((v)->{
											ArrayList ins = (ArrayList) m.get(v);
											System.out.println("insrt "+ins);
											TableRow hjk = (TableRow) ins.get(0);
											System.out.println("hjklop "+hjk);
											String val = String.valueOf(hjk.get("value"));
											System.out.println("valuein "+val+" keysst "+v);
											if(val.equals("null")) {
												JSONArray tmp = new JSONArray();
												JSONObject tmpobj = new JSONObject();
												String j = null;
												
												//tmpobj.put("value", null);
												System.out.println("tmpobj "+tmpobj);
												tmp.put(tmpobj);
												//tmpobj.set("f", "l");
												//childsysobj.put(v, tmp);
											}else {
												childsysobj.put(v, createFromString(val));
											}
											System.out.println("childsysobj2 "+childsysobj);
										});
										sysobj.accumulate("value", childsysobj);
										System.out.println("sysobj "+sysobj);
										
									});
								}
								
								if(sysobj.get("value") instanceof JSONArray) {
									JSONArray newarr = sysobj.getJSONArray("value");
									System.out.println("sysobj"+sysobj.get("value").getClass());
									
									for(int l1=0;l1<newarr.length();l1++) {
										JSONObject temp = new JSONObject();
										System.out.println("newaarr "+newarr.getJSONObject(l1));
										temp.put("value", newarr.getJSONObject(l1));
										sysarr.put(temp);
										
									}
									}else {
										
										JSONObject temp = new JSONObject();
										temp.put("value", sysobj.getJSONObject("value"));
										sysarr.put(temp);
									}
								/*
								trVal.keySet().forEach((b)->{
									System.out.println("insidetrkeyset "+ " key "+b+" "+String.valueOf(trVal.get(b))+" classname "+trVal.get(b).getClass());
									//tablerow -> key [list contains tablerow] [tr]
									
									//childsysobj.put(b, createJSONArray(trVal.get(b)));
									
									TableRow insideVal = (TableRow) trVal.get(b);
									List<String> keyNames = new ArrayList<>();
									insideVal.keySet().forEach((p)->{
										System.out.println("insidetrkeyset "+ " key "+p+" "+String.valueOf(insideVal.get(p))+" classname "+insideVal.get(p).getClass());
										ArrayList v = (ArrayList) insideVal.get(p);
										TableRow t = (TableRow) v.get(0);
										
										/*
										t.keySet().forEach((q)->{
											if(t.get(q) instanceof ArrayList) {
												System.out.println("arraylistinsidetablerow "+" key "+q+" "+t.get(q).getClass()+" value "+String.valueOf(t.get(q)));
											}else {
												childsysobj.put(p, createFromString((String) t.get(q)));
												System.out.println("childsysobj "+childsysobj);
												
											}
										});
										
									});
									
									//System.out.println("insidevalsize "+insideVal.size()); 2
									
								});
								*/
								//sysobj.put("value", childsysobj);
								//sysarr.put(sysobj);
								System.out.println("sysarr "+sysarr);
								attrObj.put(key, sysarr);
							}else if(key.equals("Zip") || key.equals("Email")
									|| key.equals("CostCenter") || key.equals("Phone")) {
								ArrayList kmn = (ArrayList) o;
								TableRow rtz = (TableRow) kmn.get(0);
								JSONObject amn = new JSONObject();
								JSONObject parentObj = new JSONObject();
								
								JSONArray arr = new JSONArray();
								TableRow trrr = (TableRow) rtz.get("value");
								trrr.keySet().forEach((n)->{
									System.out.println(n+" "+"trrr "+String.valueOf(trrr.get(n))+" classname "+trrr.get(n).getClass());
									ArrayList al = (ArrayList) trrr.get(n);
									TableRow g = new TableRow();
									System.out.println("gggg "+g);
									String val = String.valueOf(g.get("value"));
									JSONArray tmparr = new JSONArray();
									JSONObject obj1 = new JSONObject();
									if(val.equals("null")) {
										obj1.put("value", "");
									}else {
										obj1.put("value", val);
									}
									
									tmparr.put(obj1);
									amn.put(n, tmparr);
								});
								parentObj.put("value", amn);
								arr.put(parentObj);
								attrObj.put(key, arr);
							}else if(key.equals("BoardCertification") || key.equals("Education")) {
								if(key.equals("BoardCertification")) {
									System.out.println("board " + String.valueOf(o)+ "classname" +o.getClass());
								}else if(key.equals("Education")) {
									System.out.println("education " + String.valueOf(o)+ "classname" +o.getClass());
								}
							}
							else {
							//System.out.println("Arraylistinfo "+key+"val "+String.valueOf(trVal));
								attrObj.put(key, createJSONArray(trVal));
							}
							
						}else if(o instanceof TableRow) {
							TableRow tr = (TableRow) o;
							//System.out.println("tablerowval"+tr);
							JSONObject tempObj = new JSONObject();
							JSONObject valueObject = new JSONObject();
							tr.keySet().forEach((l)->{
								System.out.println("tablerowval "+String.valueOf(l)+tr.get(l)+" classname "+tr.get(l).getClass());
								ArrayList x = (ArrayList) tr.get(l);
								tempObj.put(l, createJSONArray((TableRow)x.get(0)));
							});
							valueObject.put("value", tempObj);
							attrObj.put(key, valueObject);
						}
						
					});
					
					finalObj.put("attributes", attrObj);
				}else if(k.equals("crosswalks")) {
					System.out.println("Crosswalks"+obj.get(k).getClass()+" "+String.valueOf(obj.get(k)));
					//crosswalk is tablerow for hcp
					//ArrayList ca = (ArrayList) obj.get(k);
					//System.out.println("arraylistcrswlk "+String.valueOf(obj.get(k))+" classtype "+obj.get(k).getClass());
					/*
					JSONObject ctr = new JSONObject();
					finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
					*/
					//finalObj.put(k, createJSONArray((TableRow)ca.get(0)));
					if(obj.get(k) instanceof TableRow) {
						TableRow tryw = (TableRow) obj.get(k);
						tryw.keySet().forEach((kt)->{
							
						});
					}
				}else {
					finalObj.put(k, String.valueOf(obj.get(k)));
				}
			});
			System.out.println("finalobject "+finalObj);
			
			//finalarray.put(finalObj);
			finalarr.put(finalObj);
			HashMap<String, String> mapData = new HashMap<String, String>();
			byte[] data = String.valueOf(finalarr).getBytes();
			PubsubMessage msg = new PubsubMessage(data, mapData);
			c.output(msg);
	}
		
		
	}
	
	public static JSONArray createJSONArray(TableRow tr) {
		JSONObject temp = new JSONObject();
		
		tr.keySet().forEach((key)->{
			if(tr.get(key) instanceof String) {
				temp.put(key, String.valueOf(tr.get(key)));
			}else if(tr.get(key) instanceof ArrayList) {
				ArrayList j = (ArrayList) tr.get(key);
				temp.put(key, String.valueOf(j.get(0)));
			}
		});
		
		JSONArray returnArray = new JSONArray();
		returnArray.put(temp);
		
		return returnArray;
	}
	
	public static JSONArray createFromString(String input) {
		
		
		JSONObject value = new JSONObject();
		JSONArray arr = new JSONArray();
		value.put("value", input);
		
		arr.put(value);
		return arr;
	}

}
