package org.ascension.addg.gcp.mdstaff.entity;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.FlatMapElements;
import org.apache.beam.sdk.transforms.Partition;
import org.apache.beam.sdk.transforms.Partition.PartitionFn;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.commons.collections4.map.LinkedMap;
import org.apache.commons.collections4.map.MultiKeyMap;

import com.google.api.services.bigquery.model.TableRow;


public class PartitionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation()
				.as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		
		PCollection<TableRow> org = pipeline
				.apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.credential_land"));
		
		PCollectionList<TableRow> credList = org.apply(Partition.of(3, new PartitionCredential()));
		
		/*
		PCollection<String> lines = pipeline.apply(Create.of("x"));
		PCollection<String> words = lines.apply(FlatMapElements.via(
			     new InferableFunction<String, List<String>>() {
			       public List<String> apply(String line) throws Exception {
			         return Arrays.asList(line.split(" "));
			       }
			     });
			     */
		pipeline.run().waitUntilFinish();
	}
	
	public static class PartitionCredential implements PartitionFn<TableRow>{

		@Override
		public int partitionFor(TableRow elem, int numPartitions) {
			String credVal = String.valueOf(elem.get("LicenseTypeID_Code"));
			
			if(credVal.equals("StateProfLicense")) {
				return 0;
			}else if(credVal.equals("DEA")) {
				return 1;
			}else {
				return 2;
			}
			
		}
		
	}
	/*
	public static class CombineTableRowToMap extends Combine.CombineFn<TableRow, MultiKeyMap, MultiKeyMap> {

        public MultiKeyMap createAccumulator() {
            return MultiKeyMap.decorate(new LinkedMap());
        }
        public MultiKeyMap addInput(MultiKeyMap accum, TableRow input) {
            Object value = input.get("value");
            Object strValue;
            try {
                if (value instanceof TableRow || value instanceof LinkedHashMap) {
                    strValue = Transport.getJsonFactory().toString(value);
                } else {
                    strValue = value;
                }
                if (input.keySet().size() > 2) {
                    accum.put(input.get("key1"), input.get("key2"), strValue);
                } else {
                    accum.put(input.get("key"), null, strValue);
                }
            }catch (Exception e){
                LOG.error("Caught Exception {}" + e.toString() );
                throw new RuntimeException(e);
            }

            return  accum;

        }
        public MultiKeyMap mergeAccumulators(Iterable<MultiKeyMap> accums) {
            MultiKeyMap merged = createAccumulator();
            for (MultiKeyMap accum : accums) {
                merged.putAll(accum);

            }
            return merged;
        }
        public MultiKeyMap extractOutput(MultiKeyMap accum) {
            return accum;
        }
    }
    */ 

}
