package org.ascension.addg.gcp.mdstaff.entity;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;

public class TransformLocationRecords extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{
	
	
	private static final long serialVersionUID = 1L;
	private Config config;

	public TransformLocationRecords(Config config) {
		this.config = config;
	}
	
	private static final Logger LOG = LoggerFactory.getLogger(TransformLocationRecords.class);

	@Override
	public PCollection<TableRow> expand(PCollection<TableRow> input) {
		
		PCollection<TableRow> transformedRecord = input.apply(ParDo.of(new DoFn<TableRow, TableRow>(){
			@ProcessElement
			public void ProcessElement(ProcessContext ctx) {
				TableRow inputObj = ctx.element().clone();
				TableRow returnObj = new TableRow();
				
				List<String> attrList = (List<String>) config.getObject(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS).keySet().stream().collect(Collectors.toList());
				Config values = config.getConfig(RecordGenerationConstants.SINGLE_VALUE_PARAMETERS);
				List<String> zipList = (List<String>) config.getObject(RecordGenerationConstants.ZIP).keySet().stream().collect(Collectors.toList());
				Config zipValues = config.getConfig(RecordGenerationConstants.ZIP);
				Config crosswalkConfig = config.getConfig(RecordGenerationConstants.CROSSWALKS);
				String crosswalkKey = crosswalkConfig.getString(RecordGenerationConstants.KEY);
				List<String> identifierValuesList = (List<String>) config.getObject(RecordGenerationConstants.SYSTEM_IDENTIFIER).keySet().stream().collect(Collectors.toList());
				TableRow[] systemIdentifier = new TableRow[identifierValuesList.size()];
				TableRow crosswalk = new TableRow();
				TableRow zipEntry = new TableRow();
				
				attrList.stream().forEach((attr)->{
					String recordName = values.getString(attr);
					LOG.info("Record Name ", recordName);
					if(!recordName.equals(RecordGenerationConstants.NO_RECORD)) {
						returnObj.set(attr, String.valueOf(inputObj.get(recordName)));
					}else {
						returnObj.set(attr, "");
					}
				});
				
				crosswalk.set(RecordGenerationConstants.TYPE, RecordGenerationConstants.MDSTAFF_URI);
				crosswalk.set(RecordGenerationConstants.VALUE, String.valueOf(inputObj.get(crosswalkKey)));
				returnObj.set(RecordGenerationConstants.CROSSWALKS, crosswalk);
				
				//conifg.getConfig(RecordGenerationConstants.SYSTEM_IDENTIFIER).getString(identifierValuesList.get(i))
				//identifierValuesList.get(i)
				for(int i=0;i<identifierValuesList.size();i++) {
					TableRow identity = new TableRow();
					identity.set(RecordGenerationConstants.SYSTEM_IDENTIFIER_TYPE, config.getConfig(RecordGenerationConstants.SYSTEM_IDENTIFIER).getString(identifierValuesList.get(i)));
					identity.set(RecordGenerationConstants.SYSTEM_IDENTIFIER_VALUE, String.valueOf(inputObj.get(identifierValuesList.get(i))));
					systemIdentifier[i] = identity;
				}
				
				returnObj.set(RecordGenerationConstants.SYSTEM_IDENTIFIER, systemIdentifier);
				
				zipList.stream().forEach((zip)->{
					
					String recordName = zipValues.getString(zip);
					
					if(!recordName.equals(RecordGenerationConstants.NO_RECORD)) {
						zipEntry.set(zip, String.valueOf(inputObj.get(recordName)));
					}else {
						zipEntry.set(zip, "");
					}
				});
				returnObj.set(RecordGenerationConstants.ZIP, zipEntry);
				ctx.output(returnObj);
			}
		}));
		return transformedRecord;
	}
	
	

}