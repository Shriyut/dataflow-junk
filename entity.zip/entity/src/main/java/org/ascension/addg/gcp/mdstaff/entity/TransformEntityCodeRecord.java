package org.ascension.addg.gcp.mdstaff.entity;

import java.util.List;

import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.TypeDescriptor;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;

public class TransformEntityCodeRecord extends PTransform<PCollection<TableRow>, PCollection<TableRow>>{

	
	private static final long serialVersionUID = 1L;
	private Config config;

	public TransformEntityCodeRecord(Config config) {
		this.config = config;
	}
	
	@Override
	public PCollection<TableRow> expand(PCollection<TableRow> input) {
		
		List<String> codeColumns = config.getStringList(RecordGenerationConstants.CODE_VALUE_COLUMNS);
		String entityName = config.getString(RecordGenerationConstants.ENTITY_NAME);
		
		PCollection<TableRow> clinicalCode_Column1 = input.apply("Extract clinical expertise code1", ParDo.of(new ExtractEntityCodeValuesFn(codeColumns.get(0), entityName)));
		PCollection<TableRow> clinicalCode2 = input.apply("Extract clinical expertise code2", ParDo.of(new ExtractEntityCodeValuesFn(codeColumns.get(1), entityName)));
		PCollection<TableRow> clinicalCode3 = input.apply("Extract clinical expertise code3", ParDo.of(new ExtractEntityCodeValuesFn(codeColumns.get(2), entityName)));
		PCollection<TableRow> clinicalCode4 = input.apply("Extract clinical expertise code4", ParDo.of(new ExtractEntityCodeValuesFn(codeColumns.get(3), entityName)));
		
		
		PCollection<TableRow> unionAll = PCollectionList.of(clinicalCode_Column1).and(clinicalCode2)
				.and(clinicalCode3).and(clinicalCode4)
				.apply(Flatten.<TableRow>pCollections());
		
		PCollection<TableRow> distinctValues = unionAll
				.apply(Distinct.withRepresentativeValueFn((TableRow tableRow) -> (String) tableRow.get(entityName))
						.withRepresentativeType(TypeDescriptor.of(String.class)));
		
		PCollection<TableRow> transformedRecord = distinctValues.apply(ParDo.of(new DoFn<TableRow, TableRow>(){
			@ProcessElement
			public void ProcessElement(ProcessContext ctx) {
				
				TableRow inputObj = ctx.element().clone();
				String provider_id = String.valueOf(inputObj.get("ProviderID"));
				TableRow returnObj = new TableRow();
				TableRow crosswalk = new TableRow();
				Config crosswalkConfig = config.getConfig(RecordGenerationConstants.CROSSWALKS);
				String crosswalkKey = crosswalkConfig.getString(RecordGenerationConstants.KEY);
				
				crosswalk.set(RecordGenerationConstants.TYPE, RecordGenerationConstants.MDSTAFF_URI);
				crosswalk.set(RecordGenerationConstants.VALUE, provider_id+"||"+String.valueOf(inputObj.get(crosswalkKey)));
				
				returnObj.set(entityName, String.valueOf(inputObj.get(entityName)));
				returnObj.set(RecordGenerationConstants.CROSSWALKS, crosswalk);
				
				ctx.output(returnObj);
			}
		}));
		return transformedRecord;
	}
	
	

}
