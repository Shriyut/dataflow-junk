package org.ascension.addg.gcp.mdstaff.entity;

import org.apache.beam.sdk.transforms.DoFn;

import com.google.api.services.bigquery.model.TableRow;

public class ExtractEntityCodeValuesFn extends DoFn<TableRow, TableRow>{

	private static final long serialVersionUID = 1L;
	private String key;
	private String columnName;

	public ExtractEntityCodeValuesFn(String key, String columnName) {
		this.key = key;
		this.columnName = columnName;
	}
	@ProcessElement
	public void ProcessElement(ProcessContext ctx) {
		TableRow obj = ctx.element().clone();
		TableRow transformedValue = new TableRow();
		if (obj.get(key) != null) {
			String columnValue = String.valueOf(obj.get(key));
			transformedValue.set(columnName, columnValue);
			String provider = String.valueOf(obj.get("ProviderID"));
			transformedValue.set("ProviderID", provider);
			ctx.output(transformedValue);
		}
	}
}
