package org.ascension.addg.gcp.mdstaff.entity;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class Realtionship {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String conf = "{"
				+ "\"educationStructConfig\": {\r\n"
				+ "			\"EducationInstitution\": \"Name\",\r\n"
				+ "			\"EducationTypeCode\": \"ReferenceType\",\r\n"
				+ "			\"ReferenceSourceArchivedFlag\": \"Archived\",\r\n"
				+ "			\"ReferenceInUseFlag\": \"InUse\",\r\n"
				+ "			\"SubjectOfStudy\": \"Subject\",\r\n"
				+ "			\"AcademicDegreeCode\": \"DegreeEarnedID_Code\",\r\n"
				+ "			\"AcademicDegreeStartDate\": \"StartDate\",\r\n"
				+ "			\"AcademicDegreeEndDate\": \"EndDate\"\r\n"
				+ "		}"
				+ "}";
		
		Config cnf = ConfigFactory.parseString(conf).resolve();
		
		Config edu = cnf.getConfig("educationStructConfig");
		cnf.getObject("educationStructConfig").keySet().forEach((k)->{
			System.out.println(";;;;"+k+"{{{{{"+edu.getString(k));
		});
	}

}
