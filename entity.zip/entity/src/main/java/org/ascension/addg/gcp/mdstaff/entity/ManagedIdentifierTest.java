package org.ascension.addg.gcp.mdstaff.entity;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.PCollection;
import org.ascension.addg.gcp.mdstaff.entity.IndTest.DemoFn;
import org.ascension.addg.gcp.mdstaff.entity.IndTest.ExtractLicenseFn;

import com.google.api.services.bigquery.model.TableRow;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class ManagedIdentifierTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DataflowPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation()
				.as(DataflowPipelineOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		
		String indConf = "{\r\n"
        		+ " \"indConfig\": {\r\n"
        		+ "	\"singleValueParameters\": {\r\n"
        		+ "		\"GivenName\": \"FirstName\",\r\n"
        		+ "		\"FamilyName\": \"LastName\",\r\n"
        		+ "		\"MiddleName\": \"MiddleName\",\r\n"
        		+ "		\"FullName\": \"NoRecord\",\r\n"
        		+ "		\"Status\": \"NoRecord\",\r\n"
        		+ "		\"DOB\": \"BirthDate\",\r\n"
        		+ "		\"AdministrativeGenderCode\": \"GenderID_Code\",\r\n"
        		+ "		\"SSN\": \"SSN\",\r\n"
        		+ "		\"NameSuffixCode\": \"SuffixID_Code\",\r\n"
        		+ "		\"FieldofLicensureCode\": \"FieldOfLicensureID_Code\",\r\n"
        		+ "		\"PreferredName\": \"PreferredName\",\r\n"
        		+ "		\"NamePrefixCode\": \"PrefixID_Code\",\r\n"
        		+ "		\"RaceCode\": \"RaceID_Code\",\r\n"
        		+ "		\"EthnicityCode\": \"EthnicityID_Code\",\r\n"
        		+ "		\"DomesticPartnerName\": \"SpouseName\",\r\n"
        		+ "		\"MaritalStatusCode\": \"MaritalStatusID_Code\",\r\n"
        		+ "		\"DeceasedFlag\": \"Deceased\",\r\n"
        		+ "		\"DeathDate\": \"DeceasedDate\",\r\n"
        		+ "		\"ProviderID\": \"ProviderID\",\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"general_parameters\": [ \"GivenName\", \"FamilyName\", \"MiddleName\", \"FullName\", \"DOB\", \"AdministrativeGenderCode\", \"SSN\", \"NameSuffixCode\", \r\n"
        		+ "							\"RaceCode\", \"EthnicityCode\", \"DomesticPartnerName\", \"MaritalStatusCode\", \"DeceasedFlag\", \"DeathDate\"],\r\n"
        		+ "	\r\n"
        		+ "	\"alias_demo_parameters\": {\r\n"
        		+ "		\"AliasNameTypeCode\": \"AliasTypeID_Code\",\r\n"
        		+ "		\"AliasGivenName\": \"GivenName\",\r\n"
        		+ "		\"AliasFamilyName\": \"FamilyName\",\r\n"
        		+ "		\"AliasMiddleName\": \"NoRecord\",\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"board_parameters\": {\r\n"
        		+ "		\"BoardCertificationCode\": \"SpecialtyBoardID_Code\",\r\n"
        		+ "		\"BoardCertificationStatusCode\": \"CertificationStatusID_Code\",\r\n"
        		+ "		\"BoardCertificationNumber\": \"CertificationNumber\",\r\n"
        		+ "		\"BoardCertificationLifetimeStatus\": \"Lifetime\",\r\n"
        		+ "		\"BoardCertificationInUseFlag\": \"InUse\",\r\n"
        		+ "		\"BoardCertificationInitialDate\": \"InitialCertificationDate\",\r\n"
        		+ "		\"BoardCertificationExpirationDate\": \"ExpirationDate\",\r\n"
        		+ "		\"BoardCertificationExamDate\": \"ExamDate\",\r\n"
        		+ "		\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"board_ifnull_parameter\": {\r\n"
        		+ "		\"BoardCertificationSpecialtyCode\": [ \"SpecialtyID_Code\", \"SpecializationID_Code\" ],\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"credential\": {\r\n"
        		+ "		\"CredentialCode\": [ \"DegreeID_1_Code\", \"DegreeID_2_Code\", \"DegreeID_3_Code\" ],\r\n"
        		+ "		\"CredentialRank\": \"CredentialRank\",\r\n"
        		+ "	}\r\n"
        		+ "	\r\n"
        		+ "	\"LanguageSpoken\": {\r\n"
        		+ "		\"LanguageSpokenCode\": [ \"LanguageID_1_Code\", \"LanguageID_2_Code\", \"LanguageID_3_Code\", \"LanguageID_4_Code\", \"LanguageID_5_Code\" ]\r\n"
        		+ "		\"LanguageSpokenRank\": \"LanguageSpokenRank\",\r\n"
        		+ "	}\r\n"
        		+ " }\r\n"
        		+ "}";
        Config indConfig = ConfigFactory.parseString(indConf).resolve();
        Config newconf = indConfig.getConfig("indConfig");
        
		PCollection<TableRow> credential = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.credential_land").usingStandardSql());

        PCollection<TableRow> spl = credential.apply(ParDo.of(new ExtractNewLicenseFn("StateProfLicense", "spl")));
        PCollection<TableRow> dea = credential.apply(ParDo.of(new ExtractNewLicenseFn("DEA", "dea")));
        PCollection<TableRow> cds = credential.apply(ParDo.of(new ExtractNewLicenseFn("CDSCSR", "cds")));
        
        PCollection<TableRow> demo = pipeline
                .apply(BigQueryIO.readTableRows().fromQuery("SELECT * FROM mdstaff_ingest.demographic_land").usingStandardSql());
        
        PCollection<TableRow> updateddemo = demo.apply(ParDo.of(new DemoFn(newconf)));
        
        PCollection<TableRow> firstjoin = updateddemo.apply(new PerformJoin(spl, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> secondjoin = firstjoin.apply(new PerformJoin(dea, "ProviderID", "LeftOuterJoin"));
        PCollection<TableRow> thrdjoin= secondjoin.apply(new PerformJoin(cds, "ProviderID", "LeftOuterJoin"));
        
        PCollection<String> check = thrdjoin.apply(ParDo.of(new DoFn<TableRow, String>(){
        	@ProcessElement
        	public void ProcessElement(ProcessContext c) {
        		System.out.println(String.valueOf(c.element()));
        		String s = String.valueOf(c.element())+"\n"+"$$"+"\n";
        		c.output(s);
        	}
        }));
        
        check.apply(TextIO.write().to("gs://mdstaff-test-files/aaaa").withoutSharding().withSuffix(".json"));
        pipeline.run(options).waitUntilFinish();
	}
	
	public static class ExtractNewLicenseFn extends DoFn<TableRow, TableRow> {
		
		private String licenseType;
		private String code;

		public ExtractNewLicenseFn(String licenseType, String code) {
			this.licenseType = licenseType;
			this.code = code;
		}
		
		@ProcessElement
		public void ProcessElement(ProcessContext c) {
			TableRow obj = c.element();
			
			TableRow output = new TableRow();
			
			if (String.valueOf(obj.get("LicenseTypeID_Code")).equals(licenseType)) {
		          
                output.set("CredentialID"+code, String.valueOf(obj.get("CredentialID")));
                output.set("ProviderID", String.valueOf(obj.get("ProviderID")));
                output.set("Issued"+code, String.valueOf(obj.get("Issued")));
                output.set("Renewed"+code, String.valueOf(obj.get("Renewed")));
                output.set("Expired"+code, String.valueOf(obj.get("Expired")));
                output.set("LicenseNumber"+code, String.valueOf(obj.get("LicenseNumber")));
                output.set("LicenseTypeID_Code"+code, String.valueOf(obj.get("LicenseTypeID_Code")));
                output.set("LicenseSubType_Code"+code, String.valueOf(obj.get("LicenseSubType_Code")));
                output.set("LicensureBoardID_Code"+code, String.valueOf(obj.get("LicensureBoardID_Code")));
                output.set("State"+code, String.valueOf(obj.get("State")));
                output.set("StateProfessionID"+code, String.valueOf(obj.get("StateProfessionID")));
                output.set("Status"+code, String.valueOf(obj.get("Status")));
                output.set("InUse"+code, String.valueOf(obj.get("InUse")));
                output.set("LastUpdated"+code, String.valueOf(obj.get("LastUpdated")));
                c.output(output);
            }
		}
	}

}
