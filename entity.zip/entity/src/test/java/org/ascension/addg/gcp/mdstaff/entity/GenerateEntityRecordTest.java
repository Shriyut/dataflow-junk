package org.ascension.addg.gcp.mdstaff.entity;


import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.junit.Rule;
import org.junit.Test;

import com.google.api.services.bigquery.model.TableRow;
import com.google.common.collect.ImmutableList;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class GenerateEntityRecordTest {
	
	@Rule
    public final transient TestPipeline testPipeline = TestPipeline.create();
	
	String conf = "{\r\n"
			+ "	\"locationConfig\": {\r\n"
			+ "		\"addressConfig\": {\r\n"
			+ "			\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"Country\": \"CountryID_Code\",\r\n"
			+ "				\"City\": \"City\",\r\n"
			+ "				\"AddressLine1\": \"Address\",\r\n"
			+ "				\"AddressLine2\": \"Address2\",\r\n"
			+ "				\"StateProvince\": \"State\",\r\n"
			+ "				\"SubAdministrativeArea\": \"CountyID_Code\",\r\n"
			+ "				\"PublishToExternalDirectoryFlag\": \"PubAddrExtDir\",\r\n"
			+ "				\"PublishToExternalDirectoryPrimaryFlag\": \"PubAddrExtPrim\",\r\n"
			+ "				\"AddressInUse\": \"InUse\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"AddressID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Zip\": {\r\n"
			+ "				\"PostalCode\": \"Zip\",\r\n"
			+ "				\"Zip5\": \"NoRecord\",\r\n"
			+ "				\"Zip4\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"ProviderID\": \"ProviderID\",\r\n"
			+ "				\"AddressID\": \"AddressID\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"siteConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"AddressLine1\": \"Address1\",\r\n"
			+ "				\"AddressLine2\": \"Address2\",\r\n"
			+ "				\"City\": \"City\",\r\n"
			+ "				\"SubAdministrativeArea\": \"CountyID_Code\",\r\n"
			+ "				\"StateProvince\": \"StateProvince\",\r\n"
			+ "				\"Country\": \"NoRecord\",\r\n"
			+ "				\"PublishToExternalDirectoryFlag\": \"NoRecord\",\r\n"
			+ "				\"PublishToExternalDirectoryPrimaryFlag\": \"NoRecord\",\r\n"
			+ "				\"AddressInUse\": \"InUse\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"SiteID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Zip\": {\r\n"
			+ "				\"PostalCode\": \"PostalCode\",\r\n"
			+ "				\"Zip5\": \"NoRecord\",\r\n"
			+ "				\"Zip4\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"SiteID\": \"SiteID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "	\r\n"
			+ "	}\r\n"
			+ "\r\n"
			+ "\r\n"
			+ "}";
	
	Config config = ConfigFactory.parseString(conf).resolve();
	
	@Test(expected = AssertionError.class)
	public void LocationTest() {
		ImmutableList<TableRow> addrInput = ImmutableList.of(new TableRow().set("Address1", "testVal1")
				.set("City", "t")
				.set("Zip", "test")
				.set("Zip5", "NoRecord")
				.set("Zip4", "NoRecord")
				.set("PublishToExternalDirectoryFlag", "test")
				.set("PublishToExternalDirectoryPrimaryFlag", "test")
				.set("ProviderID", "provider")
				.set("AddressID", "addr"));
		PCollection<TableRow> addrCollection = testPipeline.apply("Create address tablerow", Create.<TableRow>of(addrInput));
		
		ImmutableList<TableRow> siteInput = ImmutableList.of(new TableRow().set("AddressLine1", "testVal1")
				.set("PostalCode", "test")
				.set("Zip5", "NoRecord")
				.set("Zip4", "NoRecord")
				.set("PublishToExternalDirectoryFlag", "test")
				.set("PublishToExternalDirectoryPrimaryFlag", "test")
				.set("SiteID", "site")
				.set("EntityID", "entity"));
		PCollection<TableRow> siteCollection = testPipeline.apply("Create site tablerow", Create.<TableRow>of(siteInput));
		
		Config locationConfig = config.getConfig("locationConfig");
		
		PCollection<TableRow> location = addrCollection.apply("Convert records", new GenerateEntityRecord(siteCollection, "Location", locationConfig));
		
		ImmutableList<TableRow> result = ImmutableList.of(new TableRow().set("x", "y"));
		TableRow finalOutput = new TableRow();
		
		TableRow output = new TableRow();
		output.set("AddressLine1", null);
		output.set("AddressLine2", null);
		output.set("StateProvince", null);
		output.set("Country", null);
		output.set("City", "");
		output.set("SubAdministrativeArea", "");
		output.set("PublishToExternalDirectoryFlag", "");
		output.set("PublishToExternalDirectoryPrimaryFlag", "");
		output.set("AddressInUse", "");
		
		TableRow[] systemIdentifier = new TableRow[2];
		
		TableRow entityIdentifier = new TableRow();
		entityIdentifier.set("SystemIdentifierType", "ProviderID");
		entityIdentifier.set("SystemIdentifierValue", "");
		systemIdentifier[0] = entityIdentifier;
		TableRow addressIdentifier = new TableRow();
		addressIdentifier.set("SystemIdentifierType", "AddressID");
		addressIdentifier.set("SystemIdentifierValue", "");
		systemIdentifier[1] = addressIdentifier;
		
		output.set("SystemIdentifier", systemIdentifier);
		
		TableRow crosswalk = new TableRow();
		crosswalk.set("type", "configuration/sources/MDStaff");
		crosswalk.set("value", "addr");
		
		output.set("crosswalks", crosswalk);
		
		TableRow zip = new TableRow();
		zip.set("PostalCode", "test");
		zip.set("Zip5", "");
		zip.set("Zip4", "");
		
		output.set("Zip", zip);
		
		
		
		PAssert.that(location).containsInAnyOrder(output);
		
		testPipeline.run().waitUntilFinish();
	}
	
	@Test(expected = AssertionError.class)
	public void hcoTest() {
		Config hcoConfig = config.getConfig("hcoConfig");
		Config entityConfig = hcoConfig.getConfig("entityConfig");
		Config facilityConfig = hcoConfig.getConfig("facilityConfig");
		Config siteConfig = hcoConfig.getConfig("SiteConfig");
		
		ImmutableList<TableRow> orgInput = ImmutableList.of(new TableRow().set("Name", "testVal1")
				.set("Entity", "testEntity")
				.set("InUse", "test")
				.set("EntityID", "null")
				.set("NPI", "NPI")
				.set("MedicareNumber", "123")
				.set("MedicaidNumber", "456")
				.set("TaxIDNumber", "789")
				.set("ParentEntityID", "null")
				.set("EmailType", "")
				.set("Email", ""));
		PCollection<TableRow> orgCollection = testPipeline.apply("Create address tablerow", Create.<TableRow>of(orgInput));
		
		ImmutableList<TableRow> siteInput = ImmutableList.of(new TableRow().set("Name", "testVal1")
				.set("Entity", "testEntity")
				.set("InUse", "test")
				.set("EntityID", "null")
				.set("NPI", "NPI")
				.set("MedicareNumber", "123")
				.set("MedicaidNumber", "456")
				.set("TaxIDNumber", "789")
				.set("ParentEntityID", "null")
				.set("EmailType", "")
				.set("Email", ""));
		PCollection<TableRow> siteCollection = testPipeline.apply("Create address tablerow", Create.<TableRow>of(orgInput));
	
		ImmutableList<TableRow> facilityInput = ImmutableList.of(new TableRow().set("Name", "testVal1")
				.set("Entity", "testEntity")
				.set("InUse", "test")
				.set("EntityID", "null")
				.set("NPI", "NPI")
				.set("MedicareNumber", "123")
				.set("MedicaidNumber", "456")
				.set("TaxIDNumber", "789")
				.set("ParentEntityID", "null")
				.set("EmailType", "")
				.set("Email", ""));
		PCollection<TableRow> facilityCollection = testPipeline.apply("Create address tablerow", Create.<TableRow>of(orgInput));
	
		PCollection<TableRow> mergedData = PCollectionList.of(facilityCollection).and(orgCollection).and(siteCollection)
                .apply(Flatten.<TableRow>pCollections());
		
		TableRow output = new TableRow();
		output.set("input", "output");
		
		PAssert.that(mergedData).containsInAnyOrder(output);
		
		testPipeline.run().waitUntilFinish();
	}

}
