package org.ascension.addg.gcp.mdstaff.entity;

import com.google.api.services.bigquery.model.TableRow;
import com.google.common.collect.ImmutableList;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TransformOrganizationRecordTest {
	String conf = "{\r\n"
			+ "	\"locationConfig\": {\r\n"
			+ "		\"addressConfig\": {\r\n"
			+ "			\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"Country\": \"CountryID_Code\",\r\n"
			+ "				\"City\": \"City\",\r\n"
			+ "				\"AddressLine1\": \"Address\",\r\n"
			+ "				\"AddressLine2\": \"Address2\",\r\n"
			+ "				\"StateProvince\": \"State\",\r\n"
			+ "				\"SubAdministrativeArea\": \"CountyID_Code\",\r\n"
			+ "				\"PublishToExternalDirectoryFlag\": \"PubAddrExtDir\",\r\n"
			+ "				\"PublishToExternalDirectoryPrimaryFlag\": \"PubAddrExtPrim\",\r\n"
			+ "				\"AddressInUse\": \"InUse\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"AddressID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Zip\": {\r\n"
			+ "				\"PostalCode\": \"Zip\",\r\n"
			+ "				\"Zip5\": \"NoRecord\",\r\n"
			+ "				\"Zip4\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"ProviderID\": \"ProviderID\",\r\n"
			+ "				\"AddressID\": \"AddressID\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"siteConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"AddressLine1\": \"Address1\",\r\n"
			+ "				\"AddressLine2\": \"Address2\",\r\n"
			+ "				\"City\": \"City\",\r\n"
			+ "				\"SubAdministrativeArea\": \"CountyID_Code\",\r\n"
			+ "				\"StateProvince\": \"StateProvince\",\r\n"
			+ "				\"Country\": \"NoRecord\",\r\n"
			+ "				\"PublishToExternalDirectoryFlag\": \"NoRecord\",\r\n"
			+ "				\"PublishToExternalDirectoryPrimaryFlag\": \"NoRecord\",\r\n"
			+ "				\"AddressInUse\": \"InUse\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"SiteID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Zip\": {\r\n"
			+ "				\"PostalCode\": \"PostalCode\",\r\n"
			+ "				\"Zip5\": \"NoRecord\",\r\n"
			+ "				\"Zip4\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"SiteID\": \"SiteID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "	\r\n"
			+ "	}\r\n"
			+ "	\r\n"
			+ "	\"hcoConfig\": {\r\n"
			+ "		\"entityConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"OrganizationName\": \"Name\",\r\n"
			+ "				\"OrganizationTypeCode\": \"Entity\",\r\n"
			+ "				\"OrganizationCode\": \"NoRecord\",\r\n"
			+ "				\"Status\": \"NoRecord\",\r\n"
			+ "				\"EntityInUseFlag\": \"InUse\",\r\n"
			+ "				\"SiteInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"FacilityArchivedFlag\": \"NoRecord\",\r\n"
			+ "				\"DoingBusinessAs\": \"NoRecord\",\r\n"
			+ "				\"PatientCenteredMedicalHomeFlag\": \"NoRecord\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"managedIdentifier\": {\r\n"
			+ "				\"nationalIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"National Provider Identifier\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"NPI\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "				\"medicareIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Provider Transaction Access Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicareNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "				\"medicaidIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Medicaid Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicaidNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "				\"taxPayerIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Taxpayer Identification Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"TaxIDNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"ParentEntityID\": \"ParentEntityID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Email\": {\r\n"
			+ "				\"EmailType\": \"NoRecord\",\r\n"
			+ "				\"Email\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"siteConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"OrganizationName\": \"Name\",\r\n"
			+ "				\"OrganizationTypeCode\": \"SiteType_Code\",\r\n"
			+ "				\"OrganizationCode\": \"NoRecord\",\r\n"
			+ "				\"Status\": \"NoRecord\",\r\n"
			+ "				\"EntityInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"SiteInUseFlag\": \"InUse\",\r\n"
			+ "				\"FacilityArchivedFlag\": \"NoRecord\",\r\n"
			+ "				\"DoingBusinessAs\": \"NoRecord\",\r\n"
			+ "				\"PatientCenteredMedicalHomeFlag\": \"PCMHID_Code\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"SiteID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"managedIdentifier\": {\r\n"
			+ "				\"nationalIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"National Provider Identifier\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"NPI\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "				\"medicareIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Provider Transaction Access Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicareNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "				\"medicaidIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Medicaid Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicaidNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "				\"taxPayerIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Taxpayer Identification Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"TaxIDNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"SiteID\": \"SiteID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Email\": {\r\n"
			+ "				\"EmailType\": \"NoRecord\",\r\n"
			+ "				\"Email\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"facilityConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"OrganizationName\": \"Comments\",\r\n"
			+ "				\"OrganizationTypeCode\": \"Facility\",\r\n"
			+ "				\"OrganizationCode\": \"Code\",\r\n"
			+ "				\"Status\": \"NoRecord\",\r\n"
			+ "				\"EntityInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"SiteInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"FacilityArchivedFlag\": \"Archived\",\r\n"
			+ "				\"DoingBusinessAs\": \"NoRecord\",\r\n"
			+ "				\"PatientCenteredMedicalHomeFlag\": \"NoRecord\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"managedIdentifier\": {\r\n"
			+ "				\"identifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"NoRecord\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"NoRecord\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "					}\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"FacilityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"FacilityID\": \"FacilityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Email\": {\r\n"
			+ "				\"EmailType\": \"NoRecord\",\r\n"
			+ "				\"Email\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "		\r\n"
			+ "		}\r\n"
			+ "	\r\n"
			+ "	\r\n"
			+ "	}\r\n"
			+ "\r\n"
			+ "\r\n"
			+ "}";
	
	Config config = ConfigFactory.parseString(conf).resolve();
	
	@Rule
    public final transient TestPipeline testPipeline = TestPipeline.create();
	
	@Test
	public void transformTest() {
		Config hcoConfig = config.getConfig("hcoConfig");
		Config entityConfig = hcoConfig.getConfig("entityConfig");
		
		ImmutableList<TableRow> orgInput = ImmutableList.of(new TableRow().set("Name", "testVal1")
				.set("Entity", "testEntity")
				.set("InUse", "test")
				.set("EntityID", "null")
				.set("NPI", "NPI")
				.set("MedicareNumber", "123")
				.set("MedicaidNumber", "456")
				.set("TaxIDNumber", "789")
				.set("ParentEntityID", "null")
				.set("EmailType", "")
				.set("Email", ""));
		PCollection<TableRow> orgCollection = testPipeline.apply("Create address tablerow", Create.<TableRow>of(orgInput));
	
		PCollection<TableRow> transformedRecord = orgCollection.apply(new TransformOrganizationRecord(entityConfig));
		
		TableRow checkValue = new TableRow();
		checkValue.set("Status", "");
		checkValue.set("SiteInUseFlag", "");
		checkValue.set("OrganizationName", "testVal1");
		checkValue.set("EntityInUseFlag", "test");
		checkValue.set("DoingBusinessAs", "");
		checkValue.set("FacilityArchivedFlag", "");
		checkValue.set("OrganizationTypeCode", "testEntity");
		checkValue.set("OrganizationCode", "");
		checkValue.set("PatientCenteredMedicalHomeFlag", "");
		
		TableRow crosswalk = new TableRow();
		crosswalk.set("type", "configuration/sources/MDStaff");
		crosswalk.set("value", "null");
		
		checkValue.set("crosswalks", crosswalk);
		
		TableRow siteIdentifier = new TableRow();
		siteIdentifier.set("SystemIdentifierType", "ParentEntityID");
		siteIdentifier.set("SystemIdentifierValue", "null");
		
		TableRow entityIdentifier = new TableRow();
		entityIdentifier.set("SystemIdentifierType", "EntityID");
		entityIdentifier.set("SystemIdentifierValue", "null");
		
		TableRow[] systemIdentifier = new TableRow[2];
		systemIdentifier[1] = siteIdentifier;
		systemIdentifier[0] = entityIdentifier;
		
		checkValue.set("SystemIdentifier", systemIdentifier);
		
		TableRow email = new TableRow();
		email.set("EmailType", "");
		email.set("Email", "");
		checkValue.set("Email", email);
		
		
		
		TableRow[] managedIdentifier = new TableRow[4];
		TableRow providerIdentifier = new TableRow();
		providerIdentifier.set("ManagedIdentifierType", "National Provider Identifier");
		providerIdentifier.set("ManagedIdentifierValue", "NPI");
		providerIdentifier.set("IssuingAuthority", "");
		providerIdentifier.set("State", "");
		providerIdentifier.set("InitialIssueDate", "");
		providerIdentifier.set("EffectiveDate", "");
		providerIdentifier.set("RenewalDate", "");
		providerIdentifier.set("ExpirationDate", "");
		
		
		
		TableRow transactionIdentifier = new TableRow();
		transactionIdentifier.set("ManagedIdentifierType", "Provider Transaction Access Number");
		transactionIdentifier.set("ManagedIdentifierValue", "123");
		transactionIdentifier.set("IssuingAuthority", "");
		transactionIdentifier.set("State", "");
		transactionIdentifier.set("InitialIssueDate", "");
		transactionIdentifier.set("EffectiveDate", "");
		transactionIdentifier.set("RenewalDate", "");
		transactionIdentifier.set("ExpirationDate", "");
		
		
		
		TableRow medicaidIdentifier = new TableRow();
		medicaidIdentifier.set("ManagedIdentifierType", "Medicaid Number");
		medicaidIdentifier.set("ManagedIdentifierValue", "456");
		medicaidIdentifier.set("IssuingAuthority", "");
		medicaidIdentifier.set("State", "");
		medicaidIdentifier.set("InitialIssueDate", "");
		medicaidIdentifier.set("EffectiveDate", "");
		medicaidIdentifier.set("RenewalDate", "");
		medicaidIdentifier.set("ExpirationDate", "");
		
		
		
		TableRow taxPayerIdentifier = new TableRow();
		taxPayerIdentifier.set("ManagedIdentifierType", "Taxpayer Identification Number");
		taxPayerIdentifier.set("ManagedIdentifierValue", "789");
		taxPayerIdentifier.set("IssuingAuthority", "");
		taxPayerIdentifier.set("State", "");
		taxPayerIdentifier.set("InitialIssueDate", "");
		taxPayerIdentifier.set("EffectiveDate", "");
		taxPayerIdentifier.set("RenewalDate", "");
		taxPayerIdentifier.set("ExpirationDate", "");
		
		
		managedIdentifier[2] = providerIdentifier;
		managedIdentifier[0] = transactionIdentifier;
		managedIdentifier[3] = medicaidIdentifier;
		managedIdentifier[1] = taxPayerIdentifier;
		checkValue.set("ManagedIdentifier", managedIdentifier);
		
		PAssert.that(transformedRecord).containsInAnyOrder(checkValue);
		
		testPipeline.run().waitUntilFinish();
	}
}
