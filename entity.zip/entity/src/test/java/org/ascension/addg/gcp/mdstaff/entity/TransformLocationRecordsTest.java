package org.ascension.addg.gcp.mdstaff.entity;

import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

import com.google.api.services.bigquery.model.TableRow;
import com.google.common.collect.ImmutableList;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class TransformLocationRecordsTest {
	String conf = "{\r\n"
			+ "	\"locationConfig\": {\r\n"
			+ "		\"addressConfig\": {\r\n"
			+ "			\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"Country\": \"CountryID_Code\",\r\n"
			+ "				\"City\": \"City\",\r\n"
			+ "				\"AddressLine1\": \"Address\",\r\n"
			+ "				\"AddressLine2\": \"Address2\",\r\n"
			+ "				\"StateProvince\": \"State\",\r\n"
			+ "				\"SubAdministrativeArea\": \"CountyID_Code\",\r\n"
			+ "				\"PublishToExternalDirectoryFlag\": \"PubAddrExtDir\",\r\n"
			+ "				\"PublishToExternalDirectoryPrimaryFlag\": \"PubAddrExtPrim\",\r\n"
			+ "				\"AddressInUse\": \"InUse\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"AddressID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Zip\": {\r\n"
			+ "				\"PostalCode\": \"Zip\",\r\n"
			+ "				\"Zip5\": \"NoRecord\",\r\n"
			+ "				\"Zip4\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"ProviderID\": \"ProviderID\",\r\n"
			+ "				\"AddressID\": \"AddressID\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"siteConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"AddressLine1\": \"Address1\",\r\n"
			+ "				\"AddressLine2\": \"Address2\",\r\n"
			+ "				\"City\": \"City\",\r\n"
			+ "				\"SubAdministrativeArea\": \"CountyID_Code\",\r\n"
			+ "				\"StateProvince\": \"StateProvince\",\r\n"
			+ "				\"Country\": \"NoRecord\",\r\n"
			+ "				\"PublishToExternalDirectoryFlag\": \"NoRecord\",\r\n"
			+ "				\"PublishToExternalDirectoryPrimaryFlag\": \"NoRecord\",\r\n"
			+ "				\"AddressInUse\": \"InUse\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"SiteID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Zip\": {\r\n"
			+ "				\"PostalCode\": \"PostalCode\",\r\n"
			+ "				\"Zip5\": \"NoRecord\",\r\n"
			+ "				\"Zip4\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"SiteID\": \"SiteID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "	\r\n"
			+ "	}\r\n"
			+ "	\r\n"
			+ "	\"hcoConfig\": {\r\n"
			+ "		\"entityConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"OrganizationName\": \"Name\",\r\n"
			+ "				\"OrganizationTypeCode\": \"Entity\",\r\n"
			+ "				\"OrganizationCode\": \"NoRecord\",\r\n"
			+ "				\"Status\": \"NoRecord\",\r\n"
			+ "				\"EntityInUseFlag\": \"InUse\",\r\n"
			+ "				\"SiteInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"FacilityArchivedFlag\": \"NoRecord\",\r\n"
			+ "				\"DoingBusinessAs\": \"NoRecord\",\r\n"
			+ "				\"PatientCenteredMedicalHomeFlag\": \"NoRecord\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"managedIdentifier\": {\r\n"
			+ "				\"nationalIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"National Provider Identifier\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"NPI\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "				\"medicareIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Provider Transaction Access Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicareNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "				\"medicaidIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Medicaid Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicaidNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "				\"taxPayerIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Taxpayer Identification Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"TaxIDNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				}\r\n"
			+ "				\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"ParentEntityID\": \"ParentEntityID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Email\": {\r\n"
			+ "				\"EmailType\": \"NoRecord\",\r\n"
			+ "				\"Email\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"siteConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"OrganizationName\": \"Name\",\r\n"
			+ "				\"OrganizationTypeCode\": \"SiteType_Code\",\r\n"
			+ "				\"OrganizationCode\": \"NoRecord\",\r\n"
			+ "				\"Status\": \"NoRecord\",\r\n"
			+ "				\"EntityInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"SiteInUseFlag\": \"InUse\",\r\n"
			+ "				\"FacilityArchivedFlag\": \"NoRecord\",\r\n"
			+ "				\"DoingBusinessAs\": \"NoRecord\",\r\n"
			+ "				\"PatientCenteredMedicalHomeFlag\": \"PCMHID_Code\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"SiteID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"managedIdentifier\": {\r\n"
			+ "				\"nationalIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"National Provider Identifier\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"NPI\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "				\"medicareIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Provider Transaction Access Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicareNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "				\"medicaidIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Medicaid Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"MedicaidNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "				\"taxPayerIdentifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"Taxpayer Identification Number\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"TaxIDNumber\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "				},\r\n"
			+ "				\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"SiteID\": \"SiteID\",\r\n"
			+ "				\"EntityID\": \"EntityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Email\": {\r\n"
			+ "				\"EmailType\": \"NoRecord\",\r\n"
			+ "				\"Email\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "		}\r\n"
			+ "		\r\n"
			+ "		\"facilityConfig\": {\r\n"
			+ "			\"singleValueParameters\": {\r\n"
			+ "				\"OrganizationName\": \"Comments\",\r\n"
			+ "				\"OrganizationTypeCode\": \"Facility\",\r\n"
			+ "				\"OrganizationCode\": \"Code\",\r\n"
			+ "				\"Status\": \"NoRecord\",\r\n"
			+ "				\"EntityInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"SiteInUseFlag\": \"NoRecord\",\r\n"
			+ "				\"FacilityArchivedFlag\": \"Archived\",\r\n"
			+ "				\"DoingBusinessAs\": \"NoRecord\",\r\n"
			+ "				\"PatientCenteredMedicalHomeFlag\": \"NoRecord\",\r\n"
			+ "			\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"managedIdentifier\": {\r\n"
			+ "				\"identifier\": {\r\n"
			+ "					\"ManagedIdentifierType\": \"NoRecord\",\r\n"
			+ "					\"ManagedIdentifierValue\": \"NoRecord\",\r\n"
			+ "					\"IssuingAuthority\": \"NoRecord\",\r\n"
			+ "					\"State\": \"NoRecord\",\r\n"
			+ "					\"InitialIssueDate\": \"NoRecord\",\r\n"
			+ "					\"EffectiveDate\": \"NoRecord\",\r\n"
			+ "					\"RenewalDate\": \"NoRecord\",\r\n"
			+ "					\"ExpirationDate\": \"NoRecord\",\r\n"
			+ "					}\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"crosswalks\": {\r\n"
			+ "				\"key\": \"FacilityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"SystemIdentifier\": {\r\n"
			+ "				\"FacilityID\": \"FacilityID\",\r\n"
			+ "			}\r\n"
			+ "			\r\n"
			+ "			\"Email\": {\r\n"
			+ "				\"EmailType\": \"NoRecord\",\r\n"
			+ "				\"Email\": \"NoRecord\",\r\n"
			+ "			}\r\n"
			+ "		\r\n"
			+ "		}\r\n"
			+ "	\r\n"
			+ "	\r\n"
			+ "	}\r\n"
			+ "\r\n"
			+ "\r\n"
			+ "}";
	
	Config config = ConfigFactory.parseString(conf).resolve();
	
	@Rule
    public final transient TestPipeline testPipeline = TestPipeline.create();
	
	
	@Test
	public void transformTest() {
		ImmutableList<TableRow> addrInput = ImmutableList.of(new TableRow().set("Address", "testVal1")
				.set("Address2", "testVal2")
				.set("State", "FL")
				.set("InUse", "uwu")
				.set("CountryID_Code", "code")
				.set("City", "t")
				.set("Zip", "test")
				.set("Zip5", "NoRecord")
				.set("Zip4", "NoRecord")
				.set("CountyID_Code", "ct")
				.set("PubAddrExtDir", "test")
				.set("PubAddrExtPrim", "test")
				.set("ProviderID", "provider")
				.set("AddressID", "addr"));
		PCollection<TableRow> addrCollection = testPipeline.apply("Create address tablerow", Create.<TableRow>of(addrInput));
	
		Config locationConfig = config.getConfig("locationConfig");
		Config addressConfig = locationConfig.getConfig("addressConfig");
		
		PCollection<TableRow> transformedValue = addrCollection.apply(new TransformLocationRecords(addressConfig));
		
		TableRow checkValue = new TableRow();
		checkValue.set("AddressLine2", "testVal2");
		checkValue.set("AddressLine1", "testVal1");
		checkValue.set("StateProvince", "FL");
		checkValue.set("PublishToExternalDirectoryFlag", "test");
		checkValue.set("SubAdministrativeArea", "ct");
		checkValue.set("Country", "code");
		checkValue.set("City", "t");
		checkValue.set("AddressInUse", "uwu");
		checkValue.set("PublishToExternalDirectoryPrimaryFlag", "test");
		
		TableRow crosswalk = new TableRow();
		crosswalk.set("type", "configuration/sources/MDStaff");
		crosswalk.set("value", "addr");
		checkValue.set("crosswalks", crosswalk);
		
		TableRow providerIdentifier = new TableRow();
		providerIdentifier.set("SystemIdentifierType", "ProviderID");
		providerIdentifier.set("SystemIdentifierValue", "provider");
		
		TableRow addressIdentifier = new TableRow();
		addressIdentifier.set("SystemIdentifierType", "AddressID");
		addressIdentifier.set("SystemIdentifierValue", "addr");
		
		TableRow[] arr = new TableRow[2];
		
		arr[1] = addressIdentifier;
		arr[0] = providerIdentifier;
		
		checkValue.set("SystemIdentifier", arr);
		
		
		
		TableRow zip = new TableRow();
		zip.set("Zip4", "");
		zip.set("PostalCode", "test");
		zip.set("Zip5", "");
		
		
		checkValue.set("Zip", zip);
		
		PAssert.that(transformedValue).containsInAnyOrder(checkValue);
		
		testPipeline.run().waitUntilFinish();
		
	}
}
